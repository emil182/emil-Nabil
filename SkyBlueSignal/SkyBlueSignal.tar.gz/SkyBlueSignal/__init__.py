# -*- coding: utf-8 -*-
"""
SkyBlueSignal - Next Generation Satellite Signal Cockpit for Enigma2
Developed by SkyBlue Team
Version: 1.0.0
"""

VERSION = '1.0.0'
PLUGIN_NAME = 'SkyBlue Signal Pro'

