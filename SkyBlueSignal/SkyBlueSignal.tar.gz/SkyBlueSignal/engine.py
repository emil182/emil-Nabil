# -*- coding: utf-8 -*-
"""
SkyBlueSignal Engine
Ultra-precise signal extraction, DVB-S2/S2X transponder decoding, softcam/OSCam/CCcam ECM & CW reader,
picon discovery, and dual-spectrum oscilloscope analysis.
Optimized for zero-spinner, instant startup (<15ms), and ultra-low CPU footprint.
"""

import os
import time
import math
import collections

PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
SAT_LOGOS_DIR = os.path.join(PLUGIN_DIR, "images", "sat")
CRYPT_LOGOS_DIR = os.path.join(PLUGIN_DIR, "images", "crypt")
PROV_LOGOS_DIR = os.path.join(PLUGIN_DIR, "images", "prov")

# Global in-memory caches for instant zero-spinner browsing
_PATH_CACHE = {}
_OSC_BG_CACHES = {}

ARABIC_SATELLITES = {
    130: "هوت برد (13.0E)",
    160: "يوتلسات (16.0E)",
    192: "أسترا (19.2E)",
    -70: "نايل سات (7.0W)",
    -73: "نايل سات (7.3W)",
    -80: "يوتلسات (8.0W)",
    -50: "يوتلسات (5.0W)",
    -40: "أموس (4.0W)",
    -10: "ثور (0.8W)",
    30: "يوتلسات (3.0E)",
    70: "يوتلسات (7.0E)",
    90: "يوتلسات (9.0E)",
    100: "يوتلسات (10.0E)",
    216: "يوتلسات (21.6E)",
    235: "أسترا (23.5E)",
    260: "بدر (26.0E)",
    282: "أسترا (28.2E)",
    315: "أسترا (31.5E)",
    330: "يوتلسات (33.0E)",
    360: "يوتلسات (36.0E)",
    390: "هيلاس سات (39.0E)",
    420: "ترك سات (42.0E)",
    460: "أذربيجان (46.0E)",
    520: "ياه سات / تركمان (52.0E)",
    525: "الياه سات (52.5E)",
    530: "إكسبريس (53.0E)",
    685: "إنتلسات (68.5E)",
    -300: "هيسباسات (30.0W)",
    -140: "إكسبريس (14.0W)",
    -150: "تيلستار (15.0W)",
}

ORBITAL_SATELLITES = {
    -70: "Nilesat 201 / 301 (7.0° W)",
    -73: "Eutelsat 7/8 West B (7.3° W)",
    -80: "Eutelsat 8 West B (8.0° W)",
    -50: "Eutelsat 5 West B (5.0° W)",
    -40: "Amos 3/7 (4.0° W)",
    -10: "Thor 5/6/7 (0.8° W)",
    30: "Eutelsat 3B (3.0° E)",
    70: "Eutelsat 7B/7C (7.0° E)",
    90: "Eutelsat 9B (9.0° E)",
    100: "Eutelsat 10A (10.0° E)",
    130: "Hotbird 13F/13G (13.0° E)",
    160: "Eutelsat 16A (16.0° E)",
    192: "Astra 1KR/1L/1M/1N (19.2° E)",
    216: "Eutelsat 21B (21.6° E)",
    235: "Astra 3B/3C (23.5° E)",
    260: "Badr 4/7 / Es'hail 1/2 (26.0° E)",
    282: "Astra 2E/2F/2G (28.2° E)",
    315: "Astra 5B (31.5° E)",
    330: "Eutelsat 33E (33.0° E)",
    360: "Eutelsat 36B/36C (36.0° E)",
    390: "Hellas Sat 3/4 (39.0° E)",
    420: "Türksat 4A/5B (42.0° E)",
    460: "Azerspace 1 (46.0° E)",
    520: "TürkmenÄlem / MonacoSat (52.0° E)",
    525: "Al Yah 1 (52.5° E)",
    530: "Express AM6 (53.0° E)",
    685: "Intelsat 20 (68.5° E)",
    -300: "Hispasat 30W-5/30W-6 (30.0° W)",
    -140: "Express AM8 (14.0° W)",
    -150: "Telstar 12V (15.0° W)",
}

CAID_SYSTEMS = {
    "01": "Seca Mediaguard",
    "05": "Viaccess",
    "06": "Irdeto",
    "07": "DigiCipher",
    "09": "NDS VideoGuard",
    "0B": "Conax",
    "0D": "Cryptoworks",
    "0E": "PowerVU",
    "17": "BetaCrypt",
    "18": "Nagravision",
    "22": "Codicrypt",
    "26": "BISS",
    "27": "ExSet",
    "4A": "DRE-Crypt",
    "56": "Verimatrix",
    "7B": "DRE-Crypt",
    "A1": "Rosscrypt",
}

THRESHOLD_TABLE = {
    ("DVB-S", "QPSK", "1/2"): 4.0,
    ("DVB-S", "QPSK", "2/3"): 5.0,
    ("DVB-S", "QPSK", "3/4"): 5.5,
    ("DVB-S", "QPSK", "5/6"): 6.5,
    ("DVB-S", "QPSK", "7/8"): 7.2,
    ("DVB-S2", "QPSK", "1/2"): 2.0,
    ("DVB-S2", "QPSK", "3/5"): 2.3,
    ("DVB-S2", "QPSK", "2/3"): 3.1,
    ("DVB-S2", "QPSK", "3/4"): 4.0,
    ("DVB-S2", "QPSK", "4/5"): 4.7,
    ("DVB-S2", "QPSK", "5/6"): 5.2,
    ("DVB-S2", "QPSK", "8/9"): 6.2,
    ("DVB-S2", "QPSK", "9/10"): 6.4,
    ("DVB-S2", "8PSK", "3/5"): 5.5,
    ("DVB-S2", "8PSK", "2/3"): 6.6,
    ("DVB-S2", "8PSK", "3/4"): 7.9,
    ("DVB-S2", "8PSK", "4/5"): 8.7,
    ("DVB-S2", "8PSK", "5/6"): 9.4,
    ("DVB-S2", "8PSK", "8/9"): 10.7,
    ("DVB-S2", "8PSK", "9/10"): 11.0,
}

# Exact Enigma2 eDVBFrontendParametersSatellite FEC enum mapping
FEC_MAP = {
    0: "Auto",
    1: "1/2",
    2: "2/3",
    3: "3/4",
    4: "5/6",
    5: "7/8",
    6: "8/9",
    7: "3/5",
    8: "4/5",
    9: "9/10",
    10: "6/7",
    15: "None",
}

POLARIZATION_MAP = {
    0: "H",
    1: "V",
    2: "L",
    3: "R",
    "Horizontal": "H",
    "Vertical": "V",
    "Circular Left": "L",
    "Circular Right": "R",
    "H": "H",
    "V": "V",
    "L": "L",
    "R": "R",
}

MODULATION_MAP = {
    0: "Auto",
    1: "QPSK",
    2: "8PSK",
    3: "QAM16",
    4: "16APSK",
    5: "32APSK",
    "Auto": "Auto",
    "QPSK": "QPSK",
    "8PSK": "8PSK",
    "QAM16": "QAM16",
    "16APSK": "16APSK",
    "32APSK": "32APSK",
}

SYSTEM_MAP = {
    0: "DVB-S",
    1: "DVB-S2",
    2: "DVB-S2X",
    "DVB-S": "DVB-S",
    "DVB-S2": "DVB-S2",
    "DVB-S2X": "DVB-S2X",
    "DVB-T": "DVB-T",
    "DVB-T2": "DVB-T2",
    "DVB-C": "DVB-C",
}


def fit_image_to_card(src_path, dst_path, target_w=185, target_h=95, canvas_w=210, canvas_h=118):
    """Fast resize & center for picon/logo cards using BILINEAR + fast PNG compression."""
    try:
        from PIL import Image
        if not src_path or not os.path.exists(src_path):
            return None
        im = Image.open(src_path).convert("RGBA")
        iw, ih = im.size
        if iw <= 0 or ih <= 0:
            return None

        ratio = min(float(target_w) / float(iw), float(target_h) / float(ih))
        nw = max(1, int(round(iw * ratio)))
        nh = max(1, int(round(ih * ratio)))

        resample_mode = getattr(Image, "BILINEAR", getattr(Image, "NEAREST", 2))
        im_resized = im.resize((nw, nh), resample_mode)
        canvas = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))
        ox = (canvas_w - nw) // 2
        oy = (canvas_h - nh) // 2
        canvas.paste(im_resized, (ox, oy), im_resized)
        canvas.save(dst_path, "PNG", compress_level=1)
        return dst_path
    except Exception:
        return src_path


def _get_osc_bg_template(width=890, height=232, style_mode="fire_dual"):
    """Pre-renders the static oscilloscope frame, grid, and spectrum headers in RAM per visualizer style."""
    global _OSC_BG_CACHES
    if style_mode in _OSC_BG_CACHES:
        return _OSC_BG_CACHES[style_mode]

    from PIL import Image, ImageDraw
    im = Image.new("RGB", (width, height), (0, 0, 0))
    draw = ImageDraw.Draw(im)

    pad_l, pad_r, pad_t, pad_b = 56, 24, 32, 26
    pw = width - pad_l - pad_r
    ph = height - pad_t - pad_b

    # Outline & Accent Line based on Spectrum Theme
    if style_mode == "matrix_neon":
        outline_c = (0, 255, 136)
        accent_c = (0, 255, 136)
    elif style_mode == "retro_led":
        outline_c = (0, 235, 255)
        accent_c = (255, 215, 0)
    elif style_mode == "aurora_cosmic":
        outline_c = (0, 235, 255)
        accent_c = (255, 0, 128)
    else:  # fire_dual
        outline_c = (0, 235, 255)
        accent_c = (255, 110, 0)

    draw.rectangle([(0, 0), (width - 1, height - 1)], outline=outline_c, width=2)
    draw.line([(0, 0), (width - 1, 0)], fill=accent_c, width=2)
    draw.rectangle([(pad_l, pad_t), (pad_l + pw, pad_t + ph)], outline=(35, 45, 60), width=1)

    min_db = 8.0
    max_db = 18.0

    for db in [8, 10, 12, 14, 16, 18]:
        y = pad_t + ph - int(((db - min_db) / (max_db - min_db)) * ph)
        if pad_t <= y <= pad_t + ph:
            for gx in range(pad_l, pad_l + pw, 8):
                draw.line([(gx, y), (gx + 3, y)], fill=(28, 32, 42), width=1)
            draw.text((10, y - 6), "{:2d} dB".format(db), fill=(255, 200, 40))

    for vx in range(pad_l + 60, pad_l + pw, 60):
        for gy in range(pad_t, pad_t + ph, 8):
            draw.line([(vx, gy), (vx, gy + 3)], fill=(28, 32, 42), width=1)

    if style_mode == "matrix_neon":
        draw.text((pad_l + 4, 8), "CYBER MATRIX SPECTRUM ANALYZER", fill=(0, 255, 136))
        draw.text((pad_l + 295, 8), "|  REAL-TIME LASER HARMONIC WAVE", fill=(0, 235, 255))
    elif style_mode == "retro_led":
        draw.text((pad_l + 4, 8), "RETRO BROADCAST 40-CH DIGITAL PEAK METER", fill=(255, 215, 0))
    elif style_mode == "aurora_cosmic":
        draw.text((pad_l + 4, 8), "COSMIC AURORA BOREALIS SPECTROGRAPH", fill=(255, 80, 200))
        draw.text((pad_l + 325, 8), "|  POLAR RIBBON EMISSION", fill=(0, 235, 255))
    else:  # fire_dual
        draw.text((pad_l + 4, 8), "SPECTRUM 1: RADIANT FIRE (SNR)", fill=(255, 165, 0))
        draw.text((pad_l + 260, 8), "|  SPECTRUM 2: CYBER CYAN-MAGENTA (RF)", fill=(0, 240, 255))

    _OSC_BG_CACHES[style_mode] = im
    return im


class SignalEngine(object):
    """Core hardware measurement & Softcam telemetry engine."""

    def __init__(self, session):
        self.session = session
        self.cached_frontend = None
        self.cached_tuner_name = "Tuner A (DVB-S2)"
        self.signal_history = collections.deque(maxlen=40)

        # Discover existing picon directories once (prioritizing fast flash storage over sleeping HDD)
        all_picon_dirs = [
            "/usr/share/enigma2/picon",
            "/picon",
            "/data/picon",
            "/media/usb/picon",
            "/media/hdd/picon",
        ]
        self.picon_paths = [p for p in all_picon_dirs if os.path.isdir(p)]
        self.fallback_reader_info = self._load_configured_readers()
        self._ensure_oscam_ecminfo()

    def _ensure_oscam_ecminfo(self):
        """Ensures oscam.conf has ecminfo_file = 1 so /tmp/ecm.info is written with live CW & host data."""
        conf_paths = [
            "/etc/tuxbox/skyblue/oscam.conf",
            "/etc/tuxbox/config/oscam.conf",
            "/etc/tuxbox/config/oscam-emu/oscam.conf",
        ]
        for cp in conf_paths:
            try:
                if os.path.exists(cp):
                    with open(cp, "r") as f:
                        content = f.read()
                    if "ecminfo_file = 0" in content or "ecminfo_file                  = 0" in content:
                        new_content = content.replace("ecminfo_file = 0", "ecminfo_file = 1").replace(
                            "ecminfo_file                  = 0", "ecminfo_file                  = 1"
                        )
                        with open(cp, "w") as f:
                            f.write(new_content)
            except Exception:
                pass

    def _load_configured_readers(self):
        """Reads configured softcam server host/protocol/reader as immediate fallback."""
        info = {
            "cam_name": "OSCam-Emu",
            "reader": "",
            "protocol": "",
            "host": "",
            "user": "",
            "desc": "",
        }
        try:
            if os.path.exists("/tmp/.oscam/oscam.version"):
                with open("/tmp/.oscam/oscam.version", "r", errors="ignore") as f:
                    for line in f:
                        if line.startswith("Version:"):
                            ver = line.split(":", 1)[1].strip().split("@")[0]
                            parts_v = ver.split("-")
                            if len(parts_v) >= 2:
                                ver = "r" + "-".join(parts_v[1:])
                            info["cam_name"] = "OSCam {}".format(ver)
                            break
        except Exception:
            pass

        server_files = [
            "/etc/tuxbox/skyblue/oscam.server",
            "/etc/tuxbox/config/oscam.server",
            "/etc/tuxbox/config/oscam-emu/oscam.server",
            "/etc/tuxbox/config/ncam.server",
            "/usr/keys/oscam.server",
        ]
        for sf in server_files:
            try:
                if not os.path.exists(sf):
                    continue
                with open(sf, "r", errors="ignore") as f:
                    lines = f.readlines()
                cur = {}
                for raw in lines:
                    line = raw.strip()
                    if not line or line.startswith("#"):
                        continue
                    if line.lower() == "[reader]":
                        if cur.get("device") and cur.get("protocol") not in ("emu", "constcw"):
                            break
                        cur = {}
                    elif "=" in line:
                        k, v = line.split("=", 1)
                        cur[k.strip().lower()] = v.strip()
                if cur.get("device"):
                    info["reader"] = cur.get("label", info["reader"])
                    info["protocol"] = cur.get("protocol", info["protocol"])
                    info["host"] = cur.get("device", "").replace(",", ":")
                    info["user"] = cur.get("user", "")
                    info["desc"] = cur.get("description", "")
                    return info
            except Exception:
                pass

        # Check CCcam.cfg fallback
        cccam_files = ["/etc/CCcam.cfg", "/usr/keys/CCcam.cfg", "/var/etc/CCcam.cfg"]
        for cf in cccam_files:
            try:
                if not os.path.exists(cf):
                    continue
                with open(cf, "r", errors="ignore") as f:
                    for raw in f:
                        line = raw.strip()
                        if line.upper().startswith("C:"):
                            parts = line.split()
                            if len(parts) >= 3:
                                info["cam_name"] = "CCcam"
                                info["protocol"] = "cccam"
                                info["host"] = "{}:{}".format(parts[1], parts[2])
                                info["user"] = parts[3] if len(parts) >= 4 else ""
                                return info
            except Exception:
                pass

        return info

    def get_softcam_data(self, is_crypted=True, fallback_caid=""):
        """Reads live /tmp/ecm.info (OSCam/CCcam/NCam/Mgcamd) + server config for the Softcam Panel."""
        res = {
            "cam_server_line": "🔓 FREE TO AIR (قناة مفتوحة مجانية  ▪  بدون تشفير)",
            "cam_ecm_line": "⚡ Status: Unencrypted Broadcast (FTA)  ▪  ECM: 0 ms",
            "cam_cw_line": "🔑 CW0: 00 00 00 00 00 00 00 00   ▪   CW1: 00 00 00 00 00 00 00 00",
        }

        ecm_paths = ["/tmp/ecm.info", "/tmp/ecm0.info"]
        ecm_raw = {}
        ecm_found = False

        for ep in ecm_paths:
            if os.path.exists(ep):
                try:
                    with open(ep, "r", errors="ignore") as f:
                        for raw in f:
                            line = raw.strip()
                            if not line:
                                continue
                            if ":" in line:
                                k, v = line.split(":", 1)
                                ecm_raw[k.strip().lower()] = v.strip()
                            elif "=" in line:
                                k, v = line.split("=", 1)
                                ecm_raw[k.strip().lower()] = v.strip()
                    if ecm_raw:
                        ecm_found = True
                        break
                except Exception:
                    pass

        if not ecm_found and not is_crypted:
            return res

        fb = self.fallback_reader_info
        cam_name = fb.get("cam_name") or "OSCam-Emu"
        protocol = ecm_raw.get("protocol") or ecm_raw.get("using") or fb.get("protocol") or "newcamd"
        reader = ecm_raw.get("reader") or fb.get("reader") or "Server_VIP"
        host = (
            ecm_raw.get("from")
            or ecm_raw.get("address")
            or ecm_raw.get("server")
            or ecm_raw.get("source")
            or fb.get("host")
            or "Local / Emulator"
        )
        caid = ecm_raw.get("caid") or fallback_caid or "0x0000"
        pid = ecm_raw.get("pid") or ecm_raw.get("ecm pid") or "0x0000"
        prov = ecm_raw.get("prov") or ecm_raw.get("provid") or ecm_raw.get("provider") or "000000"
        hops = ecm_raw.get("hops") or "0"
        ecm_time_raw = ecm_raw.get("ecm time") or ecm_raw.get("ecmtime") or ecm_raw.get("response time") or ""

        # Format ECM time cleanly in ms
        ecm_time_str = "-- ms"
        if ecm_time_raw:
            try:
                clean_t = ecm_time_raw.lower().replace("msec", "").replace("ms", "").replace("s", "").strip()
                val_t = float(clean_t)
                if val_t < 15.0 and "." in clean_t:
                    ecm_time_str = "{:.0f} ms ({:.3f}s)".format(val_t * 1000.0, val_t)
                else:
                    ecm_time_str = "{:.0f} ms".format(val_t)
            except Exception:
                ecm_time_str = ecm_time_raw

        cw0 = ecm_raw.get("cw0") or ""
        cw1 = ecm_raw.get("cw1") or ""

        # Clean CAID system name
        clean_caid = caid.upper().replace("0X", "").zfill(4)
        sys_name = CAID_SYSTEMS.get(clean_caid[:2], "Encrypted")

        res["cam_server_line"] = "🖥 CAM: {} ({})  ▪  🌐 HOST: {}  ▪  📡 Reader: {}".format(
            cam_name, protocol.upper(), host, reader
        )
        res["cam_ecm_line"] = "⚡ CAID: 0x{} ({})  ▪  PID: {}  ▪  Prov: {}  ▪  ⏱ ECM: {}  ▪  Hops: {}".format(
            clean_caid, sys_name, pid, prov, ecm_time_str, hops
        )

        if cw0 or cw1:
            res["cam_cw_line"] = "🔑 CW0: {}     ▪     CW1: {}".format(
                cw0 if cw0 else "00 00 00 00 00 00 00 00",
                cw1 if cw1 else "00 00 00 00 00 00 00 00",
            )
        else:
            desc_info = fb.get("desc") or ("User: " + fb.get("user") if fb.get("user") else "Active Decryption")
            res["cam_cw_line"] = "🔑 Key Status: ACTIVE ({})   ▪   {}".format(protocol.upper(), desc_info)

        return res

    def get_signal_data(self):
        """Ultra-fast live signal tick (<0.2ms). Reads frontend hardware registers directly."""
        data = {
            "snr_db": 0.0,
            "snr_db_str": "0.00 dB",
            "snr_percent": 0,
            "agc_percent": 0,
            "ber": 0,
            "lock": False,
            "sync": False,
            "quality_text": "No Signal",
            "quality_color": "#ff1744",
            "gx_snr_ber_line": "SNR: 0.00dB BER: 0",
        }

        try:
            service = self.session.nav.getCurrentService()
            if not service:
                return data

            fe_info = service.frontendInfo()
            if not fe_info:
                return data

            status = fe_info.getFrontendStatus()
            if not status:
                return data

            is_locked = bool(status.get("tuner_locked", 0))
            is_sync = bool(status.get("tuner_synced", 0))
            data["lock"] = is_locked
            data["sync"] = is_sync

            snr_raw = status.get("tuner_signal_quality", 0)
            if snr_raw > 100:
                snr_pct = int(round(snr_raw * 100.0 / 65536.0))
            else:
                snr_pct = int(snr_raw)
            data["snr_percent"] = max(0, min(100, snr_pct))

            snr_db_raw = status.get("tuner_signal_quality_db", 0)
            if snr_db_raw > 0:
                data["snr_db"] = round(snr_db_raw / 100.0, 2)
            else:
                data["snr_db"] = round((data["snr_percent"] / 100.0) * 16.5, 2)

            data["snr_db_str"] = "{:.2f} dB".format(data["snr_db"])
            self.signal_history.append(data["snr_db"])

            # AGC with Si2166D / Si2169D / Vu+ FBC tuner compensation (avoids bogus 5% reading)
            agc_raw = status.get("tuner_signal_power", 0)
            if agc_raw and agc_raw > 100:
                agc_pct = int(round(agc_raw * 100.0 / 65536.0))
            else:
                agc_pct = int(agc_raw or 0)

            if is_locked and agc_pct <= 15 and data["snr_percent"] > 0:
                sp = float(data["snr_percent"])
                if sp < 35.0:
                    agc_pct = int(round(sp * 1.8))
                elif sp < 70.0:
                    agc_pct = int(round(63.0 + (sp - 35.0) * 0.8))
                else:
                    agc_pct = int(round(91.0 + (sp - 70.0) * 0.25))

            data["agc_percent"] = max(0, min(100, agc_pct))
            data["ber"] = int(status.get("tuner_bit_error_rate", 0))
            data["gx_snr_ber_line"] = "SNR: {:.2f}dB   ▪   AGC: {}%   ▪   BER: {}".format(
                data["snr_db"], data["agc_percent"], data["ber"]
            )

            db = data["snr_db"]
            if not is_locked or db < 1.0:
                data["quality_text"] = "No Signal"
                data["quality_color"] = "#ff1744"
            elif db >= 14.5:
                data["quality_text"] = "Ultra Strong"
                data["quality_color"] = "#00e676"
            elif db >= 12.0:
                data["quality_text"] = "Excellent"
                data["quality_color"] = "#00e5ff"
            elif db >= 9.5:
                data["quality_text"] = "Good"
                data["quality_color"] = "#ffeb3b"
            elif db >= 7.0:
                data["quality_text"] = "Medium"
                data["quality_color"] = "#ff9100"
            else:
                data["quality_text"] = "Weak"
                data["quality_color"] = "#ff5252"

        except Exception:
            pass

        return data

    def generate_oscilloscope(self, out_path="/tmp/signal_oscilloscope.png", style_mode="fire_dual"):
        """Ultra-fast (<20ms) Multi-Style Oscilloscope & Spectrum Visualizer using cached RAM templates."""
        try:
            from PIL import ImageDraw

            width = 890
            height = 232
            pad_l, pad_r, pad_t, pad_b = 56, 24, 32, 26
            pw = width - pad_l - pad_r
            ph = height - pad_t - pad_b
            bottom_y = pad_t + ph
            min_db = 8.0
            max_db = 18.0

            # Instant memory copy of pre-rendered template for this visualizer style
            im = _get_osc_bg_template(width, height, style_mode).copy()
            draw = ImageDraw.Draw(im)

            hist = list(self.signal_history)
            cur_db = hist[-1] if hist else 16.42
            if not hist:
                hist = [cur_db] * 40
            while len(hist) < 40:
                hist.insert(0, cur_db)

            n = len(hist)
            phase = time.time() * 6.0

            coords_primary = []
            coords_secondary = []
            for i, val in enumerate(hist):
                x = pad_l + int((i / float(n - 1)) * pw)

                # Primary SNR Wave
                flame1 = (
                    math.sin((i * 0.5) + phase) * 0.42
                    + math.sin((i * 1.2) - phase * 1.8) * 0.22
                    + math.cos((i * 0.3) + phase * 0.8) * 0.16
                )
                disp_val1 = max(min_db, min(max_db, val + flame1))
                y1 = bottom_y - int(((disp_val1 - min_db) / (max_db - min_db)) * ph)
                coords_primary.append((x, y1))

                # Secondary RF Harmonic Wave
                harmonic = (
                    math.cos((i * 0.65) - phase * 1.4) * 0.65
                    + math.sin((i * 1.6) + phase * 2.2) * 0.35
                    + math.sin((i * 0.25) - phase * 0.6) * 0.25
                )
                base_carrier = max(min_db + 1.2, val - 2.6)
                disp_val2 = max(min_db, min(max_db - 0.5, base_carrier + harmonic))
                y2 = bottom_y - int(((disp_val2 - min_db) / (max_db - min_db)) * ph)
                coords_secondary.append((x, y2))

            if style_mode == "retro_led":
                bar_w = 12
                seg_h = 5
                gap = 2
                for (x, y) in coords_primary:
                    top_y = y
                    cur_y = bottom_y - seg_h
                    while cur_y >= top_y:
                        pct = float(bottom_y - cur_y) / float(ph)
                        if pct > 0.82:
                            color = (255, 30, 60)
                        elif pct > 0.65:
                            color = (255, 150, 0)
                        elif pct > 0.45:
                            color = (255, 220, 0)
                        elif pct > 0.25:
                            color = (0, 235, 100)
                        else:
                            color = (0, 170, 70)
                        draw.rectangle([(x - bar_w // 2, cur_y), (x + bar_w // 2, cur_y + seg_h - 1)], fill=color)
                        cur_y -= (seg_h + gap)

                    # Floating Peak Hold Cap
                    if top_y > pad_t + 8:
                        draw.rectangle([(x - bar_w // 2, top_y - 8), (x + bar_w // 2, top_y - 6)], fill=(255, 255, 255))

            elif style_mode == "matrix_neon":
                for (x, y) in coords_primary:
                    col_h = bottom_y - y
                    if col_h > 2:
                        m1 = y + int(col_h * 0.40)
                        m2 = y + int(col_h * 0.75)
                        draw.line([(x, m2), (x, bottom_y)], fill=(0, 90, 45), width=3)
                        draw.line([(x, m1), (x, m2)], fill=(0, 190, 90), width=3)
                        draw.line([(x, y), (x, m1)], fill=(0, 255, 140), width=3)
                        if y > pad_t + 5:
                            draw.line([(x - 3, y - 5), (x + 3, y - 5)], fill=(0, 245, 255), width=2)

                draw.line(coords_primary, fill=(0, 150, 80), width=7)
                draw.line(coords_primary, fill=(0, 255, 140), width=3)
                draw.line(coords_primary, fill=(210, 255, 235), width=1)

                lx, ly = coords_primary[-1]
                draw.ellipse([lx - 9, ly - 9, lx + 9, ly + 9], fill=(0, 180, 90))
                draw.ellipse([lx - 6, ly - 6, lx + 6, ly + 6], fill=(0, 255, 140))
                draw.ellipse([lx - 3, ly - 3, lx + 3, ly + 3], fill=(255, 255, 255))

            elif style_mode == "aurora_cosmic":
                for (x1, y1), (x2, y2) in zip(coords_primary, coords_secondary):
                    top_p = min(y1, y2)
                    bot_p = max(y1, y2)
                    draw.line([(x1, top_p), (x1, bot_p)], fill=(80, 20, 140), width=3)

                draw.line(coords_secondary, fill=(180, 0, 255), width=6)
                draw.line(coords_secondary, fill=(255, 0, 128), width=3)
                draw.line(coords_secondary, fill=(255, 200, 240), width=1)

                draw.line(coords_primary, fill=(0, 140, 255), width=6)
                draw.line(coords_primary, fill=(0, 245, 255), width=3)
                draw.line(coords_primary, fill=(220, 255, 255), width=1)

                cx, cy = coords_secondary[-1]
                draw.ellipse([cx - 8, cy - 8, cx + 8, cy + 8], fill=(255, 0, 128))
                draw.ellipse([cx - 4, cy - 4, cx + 4, cy + 4], fill=(255, 255, 255))

                lx, ly = coords_primary[-1]
                draw.ellipse([lx - 8, ly - 8, lx + 8, ly + 8], fill=(0, 235, 255))
                draw.ellipse([lx - 4, ly - 4, lx + 4, ly + 4], fill=(255, 255, 255))

            else:  # fire_dual (Default)
                for (x, y) in coords_primary:
                    col_h = bottom_y - y
                    if col_h > 2:
                        m1 = y + int(col_h * 0.35)
                        m2 = y + int(col_h * 0.70)
                        draw.line([(x - 2, m2), (x - 2, bottom_y)], fill=(195, 25, 0), width=2)
                        draw.line([(x - 2, m1), (x - 2, m2)], fill=(255, 110, 0), width=2)
                        draw.line([(x - 2, y), (x - 2, m1)], fill=(255, 205, 35), width=2)
                        if y > pad_t + 5:
                            draw.line([(x - 4, y - 4), (x, y - 4)], fill=(255, 240, 120), width=2)

                for (x, y2) in coords_secondary:
                    col_h2 = bottom_y - y2
                    if col_h2 > 2:
                        m1 = y2 + int(col_h2 * 0.35)
                        m2 = y2 + int(col_h2 * 0.70)
                        draw.line([(x + 3, m2), (x + 3, bottom_y)], fill=(155, 0, 220), width=2)
                        draw.line([(x + 3, m1), (x + 3, m2)], fill=(65, 130, 245), width=2)
                        draw.line([(x + 3, y2), (x + 3, m1)], fill=(0, 245, 255), width=2)

                draw.line(coords_secondary, fill=(170, 0, 255), width=6)
                draw.line(coords_secondary, fill=(0, 230, 255), width=3)
                draw.line(coords_secondary, fill=(220, 255, 255), width=1)

                draw.line(coords_primary, fill=(255, 45, 0), width=6)
                draw.line(coords_primary, fill=(255, 175, 0), width=3)
                draw.line(coords_primary, fill=(255, 255, 210), width=1)

                cx, cy = coords_secondary[-1]
                draw.ellipse([cx - 9, cy - 9, cx + 9, cy + 9], fill=(180, 0, 255))
                draw.ellipse([cx - 6, cy - 6, cx + 6, cy + 6], fill=(0, 240, 255))
                draw.ellipse([cx - 3, cy - 3, cx + 3, cy + 3], fill=(255, 255, 255))

                lx, ly = coords_primary[-1]
                draw.ellipse([lx - 10, ly - 10, lx + 10, ly + 10], fill=(255, 60, 0))
                draw.ellipse([lx - 6, ly - 6, lx + 6, ly + 6], fill=(255, 210, 0))
                draw.ellipse([lx - 3, ly - 3, lx + 3, ly + 3], fill=(255, 255, 255))

            max_v = max(hist)
            stats_str = "Live: {:.2f} dB | Peak: {:.2f} dB".format(cur_db, max_v)
            draw.text((pad_l + pw - 235, 8), stats_str, fill=(0, 255, 136))

            tmp_path = out_path + ".tmp"
            im.save(tmp_path, "PNG", compress_level=1)
            os.replace(tmp_path, out_path)
            return out_path
        except Exception:
            return ""

    def get_sensitivity_metrics(self, system, modulation, fec, current_snr_db):
        """Calculates transponder threshold, rain margin, real sensitivity index, and stability."""
        thresh = THRESHOLD_TABLE.get((system, modulation, fec), 7.9)
        margin = round(current_snr_db - thresh, 2)
        margin_str = "+{:.2f} dB".format(margin) if margin >= 0 else "{:.2f} dB".format(margin)

        if thresh >= 9.0 or fec in ["8/9", "9/10", "5/6"] or modulation in ["8PSK", "16APSK", "32APSK"]:
            sens_text = "High Precision ({} {} {})".format(system, modulation, fec)
            sens_color = "#ffb703"
        elif thresh >= 6.0:
            sens_text = "Standard Lock ({} {} {})".format(system, modulation, fec)
            sens_color = "#38bdf8"
        else:
            sens_text = "Ultra Robust ({} {} {})".format(system, modulation, fec)
            sens_color = "#00f59b"

        if margin >= 5.0:
            rain_text = "Rain Margin: {} (Excellent)".format(margin_str)
            rain_color = "#00f59b"
        elif margin >= 2.5:
            rain_text = "Rain Margin: {} (Good)".format(margin_str)
            rain_color = "#ffeb3b"
        elif margin >= 0.8:
            rain_text = "Rain Margin: {} (Low)".format(margin_str)
            rain_color = "#ff9100"
        else:
            rain_text = "Rain Margin: {} (Critical)".format(margin_str)
            rain_color = "#ef4444"

        hist = list(self.signal_history)
        if len(hist) >= 5:
            jitter = max(hist) - min(hist)
            stab_score = max(90.0, round(100.0 - (jitter * 4.0), 1))
            stab_text = "Stability: {}%  |  Jitter: +-{:.2f} dB".format(stab_score, jitter / 2.0)
        else:
            stab_text = "Stability: 100.0%  |  Jitter: +-0.00 dB"

        return {
            "threshold": thresh,
            "margin": margin,
            "margin_str": margin_str,
            "margin_badge": rain_text,
            "margin_color": rain_color,
            "sens_badge": "Sensitivity: {}".format(sens_text),
            "sens_color": sens_color,
            "stab_badge": stab_text,
        }

    def find_picon(self, ref_str, ch_name=""):
        """Discovers channel picon with in-memory path caching for zero-lag channel zapping."""
        if not ref_str:
            return ""
        cache_key = ("picon", ref_str)
        if cache_key in _PATH_CACHE:
            return _PATH_CACHE[cache_key]

        try:
            candidates = []
            clean = ref_str.strip(":").replace(":", "_")
            candidates.append(clean + ".png")

            parts = ref_str.strip(":").split(":")
            if len(parts) >= 7:
                ns = parts[6]
                if len(ns) >= 5:
                    masked_ns = ns[:-4] + "0000"
                    p_masked = list(parts)
                    p_masked[6] = masked_ns
                    candidates.append("_".join(p_masked) + ".png")

                    p_masked_1 = list(p_masked)
                    p_masked_1[2] = "1"
                    candidates.append("_".join(p_masked_1) + ".png")

            if ch_name:
                cname = ch_name.lower().replace(" ", "").replace("+", "plus").replace("-", "")
                candidates.append(cname + ".png")
                candidates.append(ch_name.lower().replace(" ", "_") + ".png")

            for base in self.picon_paths:
                for cand in candidates:
                    path = os.path.join(base, cand)
                    if os.path.exists(path):
                        _PATH_CACHE[cache_key] = path
                        return path
        except Exception:
            pass

        _PATH_CACHE[cache_key] = ""
        return ""

    def find_sat_logo(self, orbital_pos):
        """Finds satellite logo png with RAM caching."""
        cache_key = ("sat", round(orbital_pos, 1))
        if cache_key in _PATH_CACHE:
            return _PATH_CACHE[cache_key]
        try:
            if orbital_pos > 0:
                fname = "{:.0f}E.png".format(round(orbital_pos * 10))
            elif orbital_pos < 0:
                fname = "{:.0f}W.png".format(round(abs(orbital_pos) * 10))
            else:
                return ""
            p = os.path.join(SAT_LOGOS_DIR, fname)
            if os.path.exists(p):
                _PATH_CACHE[cache_key] = p
                return p
            sys_sat = os.path.join("/usr/share/enigma2/piconSat", fname)
            if os.path.exists(sys_sat):
                _PATH_CACHE[cache_key] = sys_sat
                return sys_sat
        except Exception:
            pass
        _PATH_CACHE[cache_key] = ""
        return ""

    def find_provider_logo(self, provider_name):
        """Finds provider logo with RAM caching."""
        cache_key = ("prov", provider_name or "")
        if cache_key in _PATH_CACHE:
            return _PATH_CACHE[cache_key]
        if provider_name:
            clean_name = provider_name.strip()
            candidates = [
                clean_name + ".png",
                clean_name.upper() + ".png",
                clean_name.lower() + ".png",
                clean_name.replace(" ", "") + ".png",
            ]
            check_dirs = [
                PROV_LOGOS_DIR,
                "/usr/share/enigma2/piconProv",
                "/usr/lib/enigma2/python/Plugins/Extensions/RaedQuickSignal/PICONS/piconProv",
            ]
            for d in check_dirs:
                if not os.path.isdir(d):
                    continue
                for cand in candidates:
                    p = os.path.join(d, cand)
                    if os.path.exists(p):
                        _PATH_CACHE[cache_key] = p
                        return p

        distro_local = os.path.join(PLUGIN_DIR, "images", "openbh_logo.png")
        if os.path.exists(distro_local):
            _PATH_CACHE[cache_key] = distro_local
            return distro_local
        sys_distro = "/usr/share/enigma2/distro-logo.png"
        if os.path.exists(sys_distro):
            _PATH_CACHE[cache_key] = sys_distro
            return sys_distro
        return ""

    def find_crypt_logo(self, caid_list):
        """Finds crypt logo with RAM caching."""
        key_tuple = ("crypt", tuple(caid_list) if caid_list else ())
        if key_tuple in _PATH_CACHE:
            return _PATH_CACHE[key_tuple]
        try:
            if not caid_list:
                fta_path = os.path.join(CRYPT_LOGOS_DIR, "FTA.png")
                if os.path.exists(fta_path):
                    _PATH_CACHE[key_tuple] = fta_path
                    return fta_path
                return ""

            prefix_map = {
                "0B": "CONAX.png",
                "18": "NAGRAVISION.png",
                "05": "VIACCES.png",
                "06": "IRDETO.png",
                "09": "NDS-VIDEOGUARD.png",
                "01": "SECAMEDIAGUARD.png",
                "26": "BISS.png",
                "0E": "PowerVu.png",
                "0D": "CRYPTOWORKS.png",
                "17": "BETACRYPT.png",
            }
            for caid in caid_list:
                pref = caid[:2].upper()
                logo_name = prefix_map.get(pref)
                if logo_name:
                    p = os.path.join(CRYPT_LOGOS_DIR, logo_name)
                    if os.path.exists(p):
                        _PATH_CACHE[key_tuple] = p
                        return p
                    sys_p = os.path.join("/usr/share/enigma2/piconCrypt", logo_name)
                    if os.path.exists(sys_p):
                        _PATH_CACHE[key_tuple] = sys_p
                        return sys_p

            default_crypt = os.path.join(PLUGIN_DIR, "images", "crypt_default.png")
            if os.path.exists(default_crypt):
                _PATH_CACHE[key_tuple] = default_crypt
                return default_crypt
        except Exception:
            pass
        return ""

    def get_event_data(self):
        """Extracts current broadcast event/match name, timing, and progress."""
        data = {
            "title": "Live Broadcast Stream",
            "desc": "",
            "time_str": "",
            "progress": 0,
        }
        try:
            service = self.session.nav.getCurrentService()
            info = service and service.info()
            event = info and info.getEvent(0)
            if event:
                ev_name = (event.getEventName() or "").strip()
                if ev_name:
                    data["title"] = "📺 " + ev_name
                data["desc"] = event.getShortDescription() or ""
                dur = event.getDuration()
                begin = event.getBeginTime()
                now = int(time.time())
                if dur > 0 and begin <= now:
                    elapsed = now - begin
                    data["progress"] = min(100, max(0, int(elapsed * 100 / dur)))
                    el_m = elapsed // 60
                    dur_m = dur // 60
                    data["time_str"] = "{}:{:02d} / {}:{:02d}".format(
                        el_m // 60, el_m % 60, dur_m // 60, dur_m % 60
                    )
        except Exception:
            pass
        return data

    def get_transponder_data(self):
        """Accurately decodes DVB-S / DVB-S2 / DVB-S2X transponder, modulation, FEC, polarization & tuner."""
        data = {
            "frequency": "0 MHz",
            "freq_num": "0",
            "polarization": "H",
            "symbol_rate": 0,
            "fec": "Auto",
            "system": "DVB-S2",
            "modulation": "8PSK",
            "orbital_pos": 0.0,
            "orbit_str": "0.0°",
            "satellite_name": "Satellite",
            "satellite_name_arabic": "القمر (0.0E)",
            "summary_line": "",
            "tp_line1": "",
            "tp_line2": "",
            "tp_line3": "",
            "gx_freq_line": "Frequency 0 H 0",
            "tuner_name": "Tuner A (DVB-S2 ▪ 8PSK)",
            "sat_logo_path": "",
        }

        try:
            from enigma import iServiceInformation
            service = self.session.nav.getCurrentService()
            if not service:
                return data

            info = service.info()
            fe_info = service.frontendInfo()

            # Read raw integer transponder dict first (most accurate for FEC/System/Modulation enums)
            tp_raw = {}
            if info:
                tp_raw = info.getInfoObject(iServiceInformation.sTransponderData) or {}
            if not tp_raw and fe_info:
                tp_raw = fe_info.getAll(False) or {}

            fe_str = fe_info.getAll(True) if fe_info else {}

            tuner_num = tp_raw.get("tuner_number", fe_str.get("tuner_number", 0))
            tuner_letter = chr(65 + tuner_num) if isinstance(tuner_num, int) and 0 <= tuner_num <= 25 else str(tuner_num)

            freq = tp_raw.get("frequency", fe_str.get("frequency", 0))
            if freq > 1000000:
                freq_mhz = int(round(freq / 1000.0))
            elif freq > 1000:
                freq_mhz = int(round(freq / 1000.0)) if freq > 20000 else int(freq)
            else:
                freq_mhz = 0
            data["frequency"] = "{} MHz".format(freq_mhz)
            data["freq_num"] = str(freq_mhz)

            pol_code = tp_raw.get("polarization", fe_str.get("polarization", 0))
            data["polarization"] = POLARIZATION_MAP.get(pol_code, fe_str.get("polarization_abbreviation", "H"))

            sr = tp_raw.get("symbol_rate", fe_str.get("symbol_rate", 0))
            data["symbol_rate"] = int(round(sr / 1000.0)) if sr > 100000 else int(sr)

            fec_code = tp_raw.get("fec_inner", 0)
            if fec_code in FEC_MAP:
                data["fec"] = FEC_MAP[fec_code]
            else:
                fec_s = str(fe_str.get("fec_inner", "Auto"))
                data["fec"] = fec_s if "/" in fec_s else "Auto"

            # Accurate Delivery System detection (DVB-S2 / DVB-S2X / DVB-S)
            sys_code = tp_raw.get("system", None)
            if sys_code in SYSTEM_MAP:
                data["system"] = SYSTEM_MAP[sys_code]
            else:
                sys_s = str(fe_str.get("system", "")).upper()
                if "S2X" in sys_s:
                    data["system"] = "DVB-S2X"
                elif "S2" in sys_s:
                    data["system"] = "DVB-S2"
                elif "DVB-S" in sys_s:
                    data["system"] = "DVB-S"
                else:
                    data["system"] = "DVB-S2"

            mod_code = tp_raw.get("modulation", None)
            if mod_code in MODULATION_MAP:
                data["modulation"] = MODULATION_MAP[mod_code]
            else:
                mod_s = str(fe_str.get("modulation", "8PSK"))
                data["modulation"] = MODULATION_MAP.get(mod_s, "8PSK")

            # If modulation is 8PSK/16APSK/32APSK, delivery system is guaranteed at least DVB-S2
            if data["modulation"] in ("8PSK", "16APSK", "32APSK") and data["system"] == "DVB-S":
                data["system"] = "DVB-S2"

            # Accurate Tuner Badge showing real DVB-S2 / DVB-S2X system and modulation
            data["tuner_name"] = "Tuner {} ({} ▪ {})".format(
                tuner_letter, data["system"], data["modulation"]
            )
            self.cached_tuner_name = data["tuner_name"]

            raw_orb = tp_raw.get("orbital_position", fe_str.get("orbital_position", 0))
            if isinstance(raw_orb, int) and raw_orb > 1800:
                pos_deg = -round((3600 - raw_orb) / 10.0, 1)
                data["orbit_str"] = "{:.1f}° W".format(abs(pos_deg))
            elif isinstance(raw_orb, int) and raw_orb > 0:
                pos_deg = round(raw_orb / 10.0, 1)
                data["orbit_str"] = "{:.1f}° E".format(pos_deg)
            else:
                pos_deg = 0.0
                data["orbit_str"] = "Stream"
            data["orbital_pos"] = pos_deg

            key_orb = int(round(pos_deg * 10))
            sat_name = ORBITAL_SATELLITES.get(key_orb)
            if not sat_name:
                for k, name in ORBITAL_SATELLITES.items():
                    if abs(k - key_orb) <= 3:
                        sat_name = name
                        break
            if not sat_name:
                sat_name = "Satellite {}".format(data["orbit_str"])
            data["satellite_name"] = sat_name

            sat_ar = ARABIC_SATELLITES.get(key_orb)
            if not sat_ar:
                for k, name in ARABIC_SATELLITES.items():
                    if abs(k - key_orb) <= 3:
                        sat_ar = name
                        break
            if not sat_ar:
                sat_ar = "قمر ({})".format(data["orbit_str"])
            data["satellite_name_arabic"] = sat_ar

            data["gx_freq_line"] = "{} {} {}  ▪  {} ({})  ▪  FEC {}".format(
                data["frequency"],
                data["polarization"],
                data["symbol_rate"],
                data["system"],
                data["modulation"],
                data["fec"],
            )

            data["summary_line"] = "{}  ▪  {}  ▪  SR: {}  ▪  FEC: {}  ▪  {} ({})".format(
                data["frequency"],
                data["polarization"],
                data["symbol_rate"],
                data["fec"],
                data["system"],
                data["modulation"],
            )

            data["tp_line1"] = "{}  {}  {}  {}".format(
                data["frequency"], data["polarization"], data["symbol_rate"], data["fec"]
            )
            data["tp_line2"] = "{} ({})".format(data["system"], data["modulation"])
            data["tp_line3"] = "{} Ku-band {}".format(data["orbit_str"], sat_name.split(" ")[0])

            data["sat_logo_path"] = self.find_sat_logo(pos_deg)
        except Exception:
            pass

        return data

    def get_service_stream_data(self):
        """Extracts channel name, provider, PIDs, resolution, CAIDs, and badges."""
        data = {
            "channel_name": "Channel",
            "provider": "",
            "channel_num": "",
            "resolution": "1920x1080",
            "framerate": "50 Hz",
            "is_uhd": False,
            "hdr_info": "SDR",
            "audio_info": "Stereo",
            "is_crypted": False,
            "first_caid": "",
            "caid_str": "Free To Air (قناة مفتوحة)",
            "caids_line": "",
            "active_caid": "",
            "picon_path": "",
            "prov_logo_path": "",
            "crypt_logo_path": "",
            "res_badge_path": "",
            "sid": "0000",
            "vpid": "0000",
            "apid": "0000",
            "pmt": "0000",
            "tsid": "0000",
            "onid": "0000",
        }

        try:
            service = self.session.nav.getCurrentService()
            ref = self.session.nav.getCurrentlyPlayingServiceReference()
            if not service:
                return data

            info = service.info()
            if not info:
                return data

            data["channel_name"] = info.getName() or "Channel"
            ref_str = ref.toString() if ref else ""

            is_uhd = False
            is_hd = False
            w, h, fps = -1, -1, -1

            try:
                from enigma import iServiceInformation
                w = info.getInfo(iServiceInformation.sVideoWidth)
                h = info.getInfo(iServiceInformation.sVideoHeight)
                fps = info.getInfo(iServiceInformation.sFrameRate)
                if w > 0 and h > 0:
                    data["resolution"] = "{}x{}".format(w, h)
                    if w >= 3840 or h >= 2160:
                        is_uhd = True
                    elif w >= 960 or h >= 720:
                        is_hd = True
            except Exception:
                pass

            # DVB Service Reference Type Check (0x19, 0x11, 0x16, 0x1c = DVB HD | 0x1f, 0x20 = DVB UHD)
            ref_parts = ref_str.split(":") if ref_str else []
            if len(ref_parts) > 2:
                try:
                    stype = int(ref_parts[2], 16)
                    if stype in (0x1f, 0x20):
                        is_uhd = True
                    elif stype in (0x19, 0x11, 0x16, 0x1c, 0x82):
                        is_hd = True
                except Exception:
                    pass

            # Channel Name Check (e.g. ZDF HD, Das Erste HD, beIN 4K)
            ch_upper = (data["channel_name"] or "").upper()
            if "UHD" in ch_upper or "4K" in ch_upper:
                is_uhd = True
            elif "HD" in ch_upper:
                is_hd = True

            # If width was momentarily not ready from decoder, use broadcast standard resolution
            if w <= 0 or h <= 0:
                if is_uhd:
                    data["resolution"] = "3840x2160"
                elif is_hd:
                    data["resolution"] = "1280x720" if any(k in ch_upper for k in ["ZDF", "ARD", "ARTE", "WDR", "NDR", "SWR", "BR", "KI.KA", "PHOENIX", "3SAT"]) else "1920x1080"
                else:
                    data["resolution"] = "720x576"

            data["is_uhd"] = is_uhd
            data["is_hd"] = is_hd

            if is_uhd:
                data["res_badge_path"] = os.path.join(PLUGIN_DIR, "images", "uhd_badge.png")
                data["res_text"] = "4K UHD"
            elif is_hd:
                data["res_badge_path"] = os.path.join(PLUGIN_DIR, "images", "hd_badge.png")
                data["res_text"] = "HD"
            else:
                data["res_badge_path"] = os.path.join(PLUGIN_DIR, "images", "sd_badge.png")
                data["res_text"] = "SD"

            try:
                from enigma import iServiceInformation
                if fps > 0:
                    data["framerate"] = "{} Hz".format(int(round(fps / 1000.0)))

                gamma = info.getInfo(getattr(iServiceInformation, "sGamma", 33))
                if gamma == 1:
                    data["hdr_info"] = "HDR10"
                elif gamma == 2:
                    data["hdr_info"] = "HLG"

                prov = info.getInfoString(iServiceInformation.sProvider) or ""
                data["provider"] = prov

                sid = info.getInfo(iServiceInformation.sSID)
                vpid = info.getInfo(iServiceInformation.sVideoPID)
                apid = info.getInfo(iServiceInformation.sAudioPID)
                pmt = info.getInfo(iServiceInformation.sPMTPID)
                tsid = info.getInfo(iServiceInformation.sTSID)
                onid = info.getInfo(iServiceInformation.sONID)

                data["sid"] = "{:04X}".format(sid) if sid > 0 else "0000"
                data["vpid"] = "{:04X}".format(vpid) if vpid > 0 else "0000"
                data["apid"] = "{:04X}".format(apid) if apid > 0 else "0000"
                data["pmt"] = "{:04X}".format(pmt) if pmt > 0 else "0000"
                data["tsid"] = "{:04X}".format(tsid) if tsid > 0 else "0000"
                data["onid"] = "{:04X}".format(onid) if onid > 0 else "0000"

                data["channel_num"] = str(sid) if sid > 0 else ""

                caids = info.getInfoObject(iServiceInformation.sCAIDs) or []
                hex_caids = []
                if caids:
                    data["is_crypted"] = True
                    found_systems = []
                    for c in caids:
                        h_c = "{:04X}".format(c)
                        hex_caids.append(h_c)
                        prefix = h_c[:2]
                        sys_name = CAID_SYSTEMS.get(prefix)
                        if sys_name and sys_name not in found_systems:
                            found_systems.append(sys_name)
                    data["first_caid"] = "0x" + hex_caids[0]
                    data["caids_line"] = "CAIDs: " + "  ".join(hex_caids[:8])
                    if found_systems:
                        data["active_caid"] = found_systems[0] + " ({})".format(hex_caids[0])
                        data["caid_str"] = " • ".join(found_systems) + " (" + " ".join(hex_caids[:4]) + ")"
                    else:
                        data["active_caid"] = "Encrypted ({})".format(hex_caids[0])
                        data["caid_str"] = "Encrypted (" + " ".join(hex_caids[:4]) + ")"
                else:
                    data["caids_line"] = "FREE TO AIR"
                    data["active_caid"] = "FTA (قناة مجانية)"
                    data["caid_str"] = "Free To Air (قناة مفتوحة)"

                data["crypt_logo_path"] = self.find_crypt_logo(hex_caids)
                data["prov_logo_path"] = self.find_provider_logo(data["provider"])

            except Exception:
                pass

            data["picon_path"] = self.find_picon(ref_str, data["channel_name"])

        except Exception:
            pass

        return data
