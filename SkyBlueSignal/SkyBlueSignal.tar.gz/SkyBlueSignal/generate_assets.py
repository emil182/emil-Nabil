import os
from PIL import Image, ImageDraw, ImageFont

img_dir = r"c:\Users\SKY\Desktop\SkyBlueSubtitles\SkyBlueSignal\images"
os.makedirs(img_dir, exist_ok=True)

# 1. Generate bar_snr.png (Gradient: Cyan -> Electric Green)
w, h = 1000, 26
bar_snr = Image.new("RGBA", (w, h), (0, 0, 0, 0))
draw = ImageDraw.Draw(bar_snr)

for x in range(w):
    factor = x / float(w)
    # Start: #00d2ff (0, 210, 255) -> End: #00e676 (0, 230, 118)
    r = int(0 * (1 - factor) + 0 * factor)
    g = int(210 * (1 - factor) + 235 * factor)
    b = int(255 * (1 - factor) + 110 * factor)
    draw.line([(x, 1), (x, h - 2)], fill=(r, g, b, 255))
    # Add subtle top highlight
    draw.point((x, 0), fill=(min(255, r + 60), min(255, g + 60), min(255, b + 60), 255))
    draw.point((x, h - 1), fill=(max(0, r - 50), max(0, g - 50), max(0, b - 50), 255))

bar_snr.save(os.path.join(img_dir, "bar_snr.png"), "PNG")

# 2. Generate bar_agc.png (Gradient: Blue -> Violet/Magenta)
bar_agc = Image.new("RGBA", (w, h), (0, 0, 0, 0))
draw = ImageDraw.Draw(bar_agc)

for x in range(w):
    factor = x / float(w)
    # Start: #0091ea (0, 145, 234) -> End: #b388ff (179, 136, 255)
    r = int(0 * (1 - factor) + 180 * factor)
    g = int(145 * (1 - factor) + 130 * factor)
    b = int(234 * (1 - factor) + 255 * factor)
    draw.line([(x, 1), (x, h - 2)], fill=(r, g, b, 255))
    draw.point((x, 0), fill=(min(255, r + 50), min(255, g + 50), min(255, b + 50), 255))
    draw.point((x, h - 1), fill=(max(0, r - 40), max(0, g - 40), max(0, b - 40), 255))

bar_agc.save(os.path.join(img_dir, "bar_agc.png"), "PNG")

# 3. Generate bar_bg.png (Dark glass track)
bar_bg = Image.new("RGBA", (w, h), (20, 25, 38, 220))
draw = ImageDraw.Draw(bar_bg)
draw.rectangle([(0, 0), (w - 1, h - 1)], outline=(50, 75, 110, 255), width=1)
bar_bg.save(os.path.join(img_dir, "bar_bg.png"), "PNG")

# 4. Generate plugin.png (Icon 150x150)
ico = Image.new("RGBA", (180, 180), (0, 0, 0, 0))
draw = ImageDraw.Draw(ico)
# Rounded background card
draw.rounded_rectangle([(6, 6), (174, 174)], radius=32, fill=(13, 20, 36, 245), outline=(0, 210, 255, 255), width=3)
# Inner glow
draw.rounded_rectangle([(10, 10), (170, 170)], radius=28, outline=(0, 140, 255, 120), width=1)

# Dish base / arm
draw.line([(90, 125), (90, 150)], fill=(0, 220, 255, 255), width=5)
draw.line([(65, 150), (115, 150)], fill=(0, 220, 255, 255), width=5)
# Dish bowl arc
draw.arc([(50, 65), (130, 130)], start=190, end=350, fill=(0, 220, 255, 255), width=6)
# LNB feed arm
draw.line([(90, 105), (130, 60)], fill=(255, 215, 0, 255), width=4)
draw.ellipse([(124, 54), (136, 66)], fill=(255, 80, 80, 255), outline=(255, 255, 255, 255), width=2)

# Radio / Signal waves (arcs radiating)
for radius, alpha, w_arc in [(25, 255, 4), (45, 210, 3), (65, 150, 2)]:
    box = [(130 - radius, 60 - radius), (130 + radius, 60 + radius)]
    draw.arc(box, start=30, end=110, fill=(0, 230, 118, alpha), width=w_arc)

ico.save(os.path.join(img_dir, "plugin.png"), "PNG")
ico.save(os.path.join(r"c:\Users\SKY\Desktop\SkyBlueSubtitles\SkyBlueSignal", "plugin.png"), "PNG")

print("Graphics generated successfully!")

