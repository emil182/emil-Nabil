# -*- coding: utf-8 -*-
"""
SkyBlueSignal Audio Beeper
Dynamic acoustic signal feedback for dish & LNB alignment.
Pitch and repeat interval dynamically scale with SNR.
"""

import os
import wave
import math
import struct

WAV_PATH = "/tmp/sky_beep.wav"


def ensure_beep_wav():
    """Generates a short, crisp sine-wave beep in pure Python if not already present."""
    if os.path.exists(WAV_PATH):
        return True
    try:
        sample_rate = 16000
        duration_ms = 45
        frequency = 1400
        n_samples = int(sample_rate * (duration_ms / 1000.0))
        with wave.open(WAV_PATH, 'wb') as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(sample_rate)
            frames = bytearray()
            for i in range(n_samples):
                env = 1.0
                if i < 60:
                    env = i / 60.0
                elif i > n_samples - 60:
                    env = (n_samples - i) / 60.0
                val = int(24000.0 * env * math.sin(2.0 * math.pi * frequency * i / sample_rate))
                frames.extend(struct.pack('<h', val))
            wf.writeframes(frames)
        return True
    except Exception:
        return False


class SignalBeeper:
    """Manages audio feedback for satellite dish alignment."""

    def __init__(self):
        self.enabled = False
        self.timer = None
        self.console = None
        self.current_snr_db = 0.0

    def start(self):
        ensure_beep_wav()
        self.enabled = True
        try:
            from enigma import eTimer, eConsoleAppContainer
            self.console = eConsoleAppContainer()
            self.timer = eTimer()
            self.timer.callback.append(self._on_tick)
            self._schedule_next()
        except Exception:
            pass

    def stop(self):
        self.enabled = False
        if self.timer:
            try:
                self.timer.stop()
            except Exception:
                pass
            self.timer = None
        self.console = None

    def update_snr(self, snr_db):
        self.current_snr_db = max(0.0, float(snr_db))

    def _schedule_next(self):
        if not self.enabled or not self.timer:
            return

        db = self.current_snr_db
        if db >= 16.0:
            interval_ms = 120
        elif db >= 13.0:
            interval_ms = int(220 - (db - 13.0) * 30)
        elif db >= 9.0:
            interval_ms = int(500 - (db - 9.0) * 70)
        elif db >= 5.0:
            interval_ms = int(950 - (db - 5.0) * 110)
        else:
            interval_ms = 1800

        self.timer.start(interval_ms, True)

    def _on_tick(self):
        if not self.enabled:
            return
        try:
            if os.path.exists(WAV_PATH) and self.console:
                cmd = "gst-launch-1.0 playbin uri=file://" + WAV_PATH + " >/dev/null 2>&1 &"
                self.console.execute(cmd)
        except Exception:
            pass
        self._schedule_next()
