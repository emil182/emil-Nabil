# -*- coding: utf-8 -*-
"""
SkyBlueSignal Modern Glassmorphism & Pure Black OLED Skins
Full HD (1920x1080) & UHD (3840x2160) Fullscreen Cockpits with Cairo/Osama typography.
Includes 4 distinct VIP styles (Default: Pro Observatory Pure Black OLED):
1. Pro Observatory Cockpit (Pure Black OLED Fullscreen with Dual-Spectrum, 86pt dB, Softcam/CW Box & Live Mini TV)
2. GX Classic Elite (Legendary GX receiver signal meter layout & colors on Pure Black with 88pt dB)
3. Cyber Neon HUD (Futuristic cyberpunk digital telemetry with Softcam/CW Box & Live Mini TV)
4. Ultra Slim Sports HUD (Floating bottom bar for live broadcast & matches)
"""

import os

PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
IMG_DIR = os.path.join(PLUGIN_DIR, "images")

# ==============================================================================
# STYLE 1 (DEFAULT): Pro Observatory Cockpit (PURE BLACK OLED + 86pt dB + SOFTCAM/CW + MINI TV)
# ==============================================================================
SKIN_PRO_OBSERVATORY = """
<screen name="SkyBlueSignalObservatory" position="0,0" size="1920,1080" title="SkyBlue Signal Observatory" flags="wfNoBorder" backgroundColor="#04000000">
    <!-- Outer Neon Cyan & Gold Glass Borders on Pure Black -->
    <eLabel position="0,0" size="1920,3" backgroundColor="#00ffff" zPosition="10" />
    <eLabel position="0,1077" size="1920,3" backgroundColor="#ffd700" zPosition="10" />
    <eLabel position="0,0" size="3,1080" backgroundColor="#00ffff" zPosition="10" />
    <eLabel position="1917,0" size="3,1080" backgroundColor="#ffd700" zPosition="10" />

    <!-- ================= ZONE 1: TOP OBSERVATORY HEADER (PURE BLACK) ================= -->
    <eLabel position="25,14" size="1870,106" backgroundColor="#06040507" zPosition="1" />
    <eLabel position="25,14" size="1870,2" backgroundColor="#00ffff" zPosition="2" />
    <eLabel position="25,118" size="1870,1" backgroundColor="#1e293b" zPosition="2" />
    
    <widget name="res_badge" position="45,34" size="55,42" alphatest="blend" zPosition="5" transparent="1" />
    <widget name="channel_num" position="115,24" size="150,58" font="SkyCairo;38" foregroundColor="#00ff88" transparent="1" zPosition="5" />
    <widget name="channel_name" position="280,18" size="850,68" font="SkyCairo;48" foregroundColor="#ffffff" transparent="1" zPosition="5" />
    <widget name="provider_name" position="280,82" size="850,34" font="SkyCairo;24" foregroundColor="#00e5ff" transparent="1" zPosition="5" />

    <widget name="clock_time" position="1380,20" size="480,48" font="SkyCairo;34" foregroundColor="#ffd700" halign="right" transparent="1" zPosition="5" />
    <widget name="lock_badge" position="1380,74" size="480,38" font="SkyCairo;25" foregroundColor="#00ff88" halign="right" transparent="1" zPosition="5" />

    <!-- ================= ZONE 2: GIANT SIGNAL POWER CORE (86pt dB & LUXURY CRYSTAL BARS) ================= -->
    <!-- Card A: Colossal 86pt Digital dB & Rain Margin on Pure Black -->
    <eLabel position="25,130" size="530,282" backgroundColor="#06040507" zPosition="1" />
    <eLabel position="25,130" size="530,3" backgroundColor="#ffd700" zPosition="2" />
    <eLabel position="25,410" size="530,2" backgroundColor="#ff6600" zPosition="2" />
    <eLabel text="SIGNAL QUALITY (SNR)" position="35,134" size="510,24" font="SkyCairo;19" foregroundColor="#00ffff" halign="center" transparent="1" zPosition="4" />
    <widget name="snr_db" position="30,152" size="520,126" font="SkyCairo;86" foregroundColor="#ffd700" halign="center" valign="center" transparent="1" zPosition="4" />
    <widget name="margin_badge" position="35,280" size="510,34" font="SkyCairo;24" foregroundColor="#00ff88" halign="center" transparent="1" zPosition="4" />
    <widget name="sensitivity_badge" position="35,316" size="510,32" font="SkyCairo;22" foregroundColor="#ffaa00" halign="center" transparent="1" zPosition="4" />
    <widget name="stability_badge" position="35,350" size="510,32" font="SkyCairo;22" foregroundColor="#00ffff" halign="center" transparent="1" zPosition="4" />

    <!-- Card B: Dual Extra-Thick 68px 3D Aurora Jewel Crystal Bars on Pure Black -->
    <eLabel position="570,130" size="1325,282" backgroundColor="#06040507" zPosition="1" />
    <eLabel position="570,130" size="1325,3" backgroundColor="#00ffff" zPosition="2" />
    <eLabel position="570,410" size="1325,2" backgroundColor="#ff007f" zPosition="2" />

    <!-- SNR Bar (Width 1140px, Extra-Thick Height 68px! Distinct Gold-Emerald-Cyan Crystal Spectrum) -->
    <eLabel text="SNR (Quality):" position="590,132" size="320,40" font="SkyCairo;25" foregroundColor="#00ffff" transparent="1" zPosition="4" />
    <widget name="snr_progress" position="590,174" size="1140,68" pixmap="{IMG_DIR}/bar_qual_gold_emerald.png" backgroundColor="#0a0a0f" zPosition="4" borderWidth="2" borderColor="#00ffff" />
    <widget name="snr_percent" position="1742,172" size="145,72" font="SkyCairo;44" foregroundColor="#00ff88" halign="left" valign="center" transparent="1" zPosition="4" />

    <!-- AGC Bar (Width 1140px, Extra-Thick Height 68px! Distinct Rose-Amethyst-Orchid Crystal Spectrum) -->
    <eLabel text="AGC (RF Power):" position="590,246" size="320,40" font="SkyCairo;25" foregroundColor="#ff007f" transparent="1" zPosition="4" />
    <widget name="agc_progress" position="590,288" size="1140,68" pixmap="{IMG_DIR}/bar_agc_crystal.png" backgroundColor="#0a0a0f" zPosition="4" borderWidth="2" borderColor="#ff007f" />
    <widget name="agc_percent" position="1742,286" size="145,72" font="SkyCairo;44" foregroundColor="#ff00aa" halign="left" valign="center" transparent="1" zPosition="4" />

    <!-- Sub-metrics -->
    <widget name="ber_value" position="590,368" size="240,36" font="SkyCairo;24" foregroundColor="#ff2a55" transparent="1" zPosition="4" />
    <widget name="cn_ratio" position="845,368" size="310,36" font="SkyCairo;24" foregroundColor="#ffd700" transparent="1" zPosition="4" />
    <widget name="stream_summary" position="1170,368" size="495,36" font="SkyCairo;24" foregroundColor="#00ffff" transparent="1" zPosition="4" />
    <widget name="key_yellow" position="1675,368" size="200,36" font="SkyCairo;22" foregroundColor="#ffff00" halign="right" transparent="1" zPosition="4" />

    <!-- ================= ZONE 3: DUAL SPECTRUM GRAPH & TRANSPONDER/SIDS/EVENT ================= -->
    <!-- Card C: Dual-Spectrum Analyzer (Fire + Cyan/Magenta) on Pure Black -->
    <eLabel position="25,420" size="920,272" backgroundColor="#03000000" zPosition="1" />
    <eLabel position="25,420" size="920,2" backgroundColor="#ff6600" zPosition="2" />
    <widget name="signal_graph" position="40,438" size="890,232" alphatest="blend" zPosition="5" transparent="1" />

    <!-- Card D: Transponder, SIDs/CAIDs & Clear Event Title on Pure Black -->
    <eLabel position="965,420" size="930,272" backgroundColor="#06040507" zPosition="1" />
    <eLabel position="965,420" size="930,2" backgroundColor="#ffd700" zPosition="2" />
    
    <!-- Frequency Line (Huge Solar Gold 38pt font) -->
    <widget name="tp_freq_pol" position="985,424" size="890,48" font="SkyCairo;38" foregroundColor="#ffd700" transparent="1" zPosition="4" />
    
    <!-- System & Modulation Line (Electric Cyan 30pt font) -->
    <widget name="tp_sys_mod" position="985,474" size="890,40" font="SkyCairo;30" foregroundColor="#00ffff" transparent="1" zPosition="4" />
    
    <eLabel position="985,518" size="890,2" backgroundColor="#222230" zPosition="2" />

    <!-- CAIDs & Active System (26pt font: Fiery Orange & Laser Emerald) -->
    <widget name="caids_line" position="985,522" size="580,36" font="SkyCairo;26" foregroundColor="#ff7700" transparent="1" zPosition="4" />
    <widget name="active_caid" position="1570,522" size="305,36" font="SkyCairo;26" foregroundColor="#00ff88" halign="right" transparent="1" zPosition="4" />

    <!-- SIDs & PIDs Grid (24pt font: Neon Magenta/Orchid) -->
    <widget name="pids_grid" position="985,560" size="900,34" font="SkyCairo;24" foregroundColor="#ff66ff" transparent="1" zPosition="4" />

    <eLabel position="985,598" size="890,2" backgroundColor="#222230" zPosition="2" />

    <!-- Event / Program Title (Full 52px vertical clearance & native Regular Arabic+Latin font so zero letters drop or clip!) -->
    <widget name="event_title" position="985,602" size="685,52" font="Regular;28" foregroundColor="#00ffcc" valign="center" transparent="1" zPosition="4" />
    <widget name="event_time" position="1675,606" size="200,44" font="SkyCairo;24" foregroundColor="#ffd700" halign="right" valign="center" transparent="1" zPosition="4" />
    <widget name="event_progress" position="985,664" size="890,16" pixmap="{IMG_DIR}/bar_snr.png" zPosition="4" borderWidth="1" borderColor="#00ffff" />

    <!-- ================= ZONE 4: 4 PICON CARDS + SOFTCAM/CW BOX BELOW PICONS + LIVE MINI TV ================= -->
    <eLabel position="25,702" size="1870,310" backgroundColor="#06040507" zPosition="1" />
    <eLabel position="25,702" size="1870,2" backgroundColor="#00ff88" zPosition="2" />

    <!-- Card 1: Channel Picon -->
    <ePixmap position="45,712" size="220,130" pixmap="{IMG_DIR}/picon_frame_large.png" alphatest="blend" zPosition="4" transparent="1" />
    <widget name="picon" position="50,718" size="210,118" alphatest="blend" zPosition="5" transparent="1" />

    <!-- Card 2: Provider / Distro Logo -->
    <ePixmap position="278,712" size="220,130" pixmap="{IMG_DIR}/picon_frame_large.png" alphatest="blend" zPosition="4" transparent="1" />
    <widget name="prov_logo" position="283,718" size="210,118" alphatest="blend" zPosition="5" transparent="1" />

    <!-- Card 3: Satellite Orbit Logo -->
    <ePixmap position="511,712" size="220,130" pixmap="{IMG_DIR}/picon_frame_large.png" alphatest="blend" zPosition="4" transparent="1" />
    <widget name="sat_logo" position="516,718" size="210,118" alphatest="blend" zPosition="5" transparent="1" />

    <!-- Card 4: Crypt / Security Badge -->
    <ePixmap position="744,712" size="220,130" pixmap="{IMG_DIR}/picon_frame_large.png" alphatest="blend" zPosition="4" transparent="1" />
    <widget name="crypt_logo" position="749,718" size="210,118" alphatest="blend" zPosition="5" transparent="1" />

    <!-- Orbit, Accurate DVB-S2 Tuner & Beeper Info (Right next to the 4 Picon Cards) -->
    <widget name="sat_badge" position="980,714" size="325,40" font="SkyCairo;24" foregroundColor="#00ffff" transparent="1" zPosition="5" />
    <widget name="tuner_badge" position="980,756" size="325,40" font="SkyCairo;24" foregroundColor="#ffd700" transparent="1" zPosition="5" />
    <widget name="beeper_status" position="980,798" size="325,38" font="SkyCairo;22" foregroundColor="#00ff88" transparent="1" zPosition="5" />

    <!-- ================= DEDICATED SOFTCAM / SERVER HOST / CW KEY BOX BELOW PICONS ================= -->
    <eLabel position="45,850" size="1255,152" backgroundColor="#04030508" zPosition="2" />
    <eLabel position="45,850" size="1255,2" backgroundColor="#ffd700" zPosition="3" />
    <eLabel position="45,1000" size="1255,2" backgroundColor="#00ff88" zPosition="3" />
    <eLabel position="45,850" size="3,152" backgroundColor="#ffd700" zPosition="3" />
    <eLabel position="1297,850" size="3,152" backgroundColor="#00ff88" zPosition="3" />

    <widget name="cam_server_line" position="60,855" size="1225,44" font="SkyCairo;25" foregroundColor="#ffd700" valign="center" transparent="1" zPosition="5" />
    <widget name="cam_ecm_line" position="60,901" size="1225,44" font="SkyCairo;24" foregroundColor="#00ffff" valign="center" transparent="1" zPosition="5" />
    <widget name="cam_cw_line" position="60,947" size="1225,46" font="SkyCairo;25" foregroundColor="#00ff88" valign="center" transparent="1" zPosition="5" />

    <!-- ================= LIVE MINI TV WINDOW (PICTURE-IN-GRAPHIC) ================= -->
    <eLabel text="📺 LIVE CHANNEL BROADCAST" position="1320,710" size="550,28" font="SkyCairo;22" foregroundColor="#00ffff" transparent="1" zPosition="5" />
    <eLabel position="1318,740" size="554,262" backgroundColor="#00ffff" zPosition="2" />
    <widget source="session.VideoPicture" render="Pig" position="1320,742" size="550,258" zPosition="3" backgroundColor="#ff000000" />

    <!-- Bottom Action Pill Bar -->
    <eLabel position="25,1022" size="1870,46" backgroundColor="#06040507" zPosition="2" />
    <eLabel text="[MENU] إعدادات وتحديث    [&lt; / &gt;] تصفح القنوات    [Blue] الستايل    [7] الطيف    [Rec/Help] لقطة شاشة    [0] تخصيص الزر    [Exit] إغلاق" position="40,1028" size="1840,32" font="SkyCairo;22" foregroundColor="#00e5ff" halign="center" transparent="1" zPosition="5" />
</screen>
""".format(IMG_DIR=IMG_DIR)

# ==============================================================================
# STYLE 2: GX Classic Elite (Legendary GX meters + Giant 88pt dB + Dual Spectrum + Softcam Info)
# ==============================================================================
SKIN_GX_ELITE = """
<screen name="SkyBlueSignalGX" position="0,0" size="1920,1080" title="SkyBlue Signal GX" flags="wfNoBorder" backgroundColor="#04000000">
    <!-- Glowing Dual-Tone Outer Neon Border -->
    <eLabel position="0,0" size="1920,3" backgroundColor="#ff6d00" zPosition="10" />
    <eLabel position="0,1077" size="1920,3" backgroundColor="#00ffff" zPosition="10" />
    <eLabel position="0,0" size="3,1080" backgroundColor="#ff6d00" zPosition="10" />
    <eLabel position="1917,0" size="3,1080" backgroundColor="#00ffff" zPosition="10" />

    <!-- Top Section: Satellite Name (Cyan) & Channel Name (Bold White) -->
    <widget name="gx_sat_name" position="50,16" size="1820,52" font="Regular;40" foregroundColor="#00ffff" halign="center" transparent="1" zPosition="5" />
    <widget name="channel_name" position="50,70" size="1820,78" font="SkyCairo;52" foregroundColor="#ffffff" halign="center" transparent="1" zPosition="5" />

    <!-- ================= GIANT 88pt DIGITAL dB DISPLAY ================= -->
    <widget name="snr_db" position="50,148" size="1820,128" font="SkyCairo;88" foregroundColor="#ffd700" halign="center" valign="center" transparent="1" zPosition="5" />

    <!-- ================= S ROW (Signal Strength - 100% FLAME) ================= -->
    <ePixmap position="70,282" size="86,76" pixmap="{IMG_DIR}/box_sq.png" alphatest="blend" zPosition="4" />
    <eLabel text="S" position="70,282" size="86,76" font="SkyCairo;44" foregroundColor="#ffffff" halign="center" transparent="1" zPosition="5" />
    <widget name="gx_s_progress" position="175,282" size="1540,76" pixmap="{IMG_DIR}/bar_gx_red.png" backgroundColor="#0a0f18" zPosition="3" borderWidth="3" borderColor="#ffffff" />
    <ePixmap position="1735,282" size="125,76" pixmap="{IMG_DIR}/box_pct.png" alphatest="blend" zPosition="4" />
    <widget name="gx_s_percent" position="1735,282" size="125,76" font="SkyCairo;40" foregroundColor="#ffffff" halign="center" transparent="1" zPosition="5" />

    <!-- ================= Q ROW (Signal Quality - DISTINCT GOLD-EMERALD CRYSTAL SPECTRUM) ================= -->
    <ePixmap position="70,374" size="86,76" pixmap="{IMG_DIR}/box_sq.png" alphatest="blend" zPosition="4" />
    <eLabel text="Q" position="70,374" size="86,76" font="SkyCairo;44" foregroundColor="#ffffff" halign="center" transparent="1" zPosition="5" />
    <widget name="gx_q_progress" position="175,374" size="1540,76" pixmap="{IMG_DIR}/bar_qual_gold_emerald.png" backgroundColor="#0a0f18" zPosition="3" borderWidth="3" borderColor="#00ffff" />
    <ePixmap position="1735,374" size="125,76" pixmap="{IMG_DIR}/box_pct.png" alphatest="blend" zPosition="4" />
    <widget name="gx_q_percent" position="1735,374" size="125,76" font="SkyCairo;40" foregroundColor="#ffffff" halign="center" transparent="1" zPosition="5" />

    <!-- ================= DYNAMIC DUAL SPECTRUM OSCILLOSCOPE ================= -->
    <widget name="signal_graph" position="515,468" size="890,232" alphatest="blend" zPosition="5" transparent="1" />

    <!-- ================= BOTTOM TECHNICAL & SOFTCAM TELEMETRY ================= -->
    <widget name="gx_freq_line" position="50,712" size="1820,54" font="SkyCairo;40" foregroundColor="#ffd700" halign="center" transparent="1" zPosition="5" />
    <widget name="gx_snr_ber_line" position="50,770" size="1820,48" font="SkyCairo;34" foregroundColor="#00ffff" halign="center" transparent="1" zPosition="5" />
    <widget name="lock_badge" position="50,822" size="1820,42" font="SkyCairo;28" foregroundColor="#00ff88" halign="center" transparent="1" zPosition="5" />

    <!-- Softcam Host & CW Info in GX Mode -->
    <widget name="cam_server_line" position="50,872" size="1820,40" font="SkyCairo;25" foregroundColor="#ffd700" halign="center" transparent="1" zPosition="5" />
    <widget name="cam_cw_line" position="50,916" size="1820,40" font="SkyCairo;25" foregroundColor="#00ff88" halign="center" transparent="1" zPosition="5" />

    <!-- Shortcuts Navigation Legend -->
    <eLabel text="[MENU] إعدادات    [&lt; / &gt;] تصفح القنوات    [Blue] الستايل    [7] الطيف    [Rec/Help] لقطة شاشة    [0] تخصيص الزر    [Exit] إغلاق" position="50,975" size="1820,38" font="SkyCairo;24" foregroundColor="#00e5ff" halign="center" transparent="1" zPosition="5" />
</screen>
""".format(IMG_DIR=IMG_DIR)

# ==============================================================================
# STYLE 3: Cyber Neon HUD (Pure Black High-Contrast Neon Dark with Softcam & Mini TV)
# ==============================================================================
SKIN_CYBER_NEON = """
<screen name="SkyBlueSignalCyber" position="0,0" size="1920,1080" title="SkyBlue Signal Cyber" flags="wfNoBorder" backgroundColor="#04000000">
    <!-- Glowing Dual-Tone Outer Neon Border -->
    <eLabel position="0,0" size="1920,3" backgroundColor="#00f5d4" zPosition="10" />
    <eLabel position="0,1077" size="1920,3" backgroundColor="#f72585" zPosition="10" />
    <eLabel position="0,0" size="3,1080" backgroundColor="#00f5d4" zPosition="10" />
    <eLabel position="1917,0" size="3,1080" backgroundColor="#f72585" zPosition="10" />

    <!-- ================= ROW 1: TOP HUD TITLE & REAL-TIME CLOCK ================= -->
    <eLabel text="⚡ CYBER NEON SIGNAL TELEMETRY" position="40,18" size="650,38" font="SkyCairo;28" foregroundColor="#00ffff" transparent="1" zPosition="5" />
    <widget name="clock_time" position="1380,18" size="500,38" font="SkyCairo;28" foregroundColor="#ff007f" halign="right" transparent="1" zPosition="5" />

    <!-- ================= ROW 2: CHANNEL NAME & MASSIVE 82pt AMBER GOLD dB ================= -->
    <widget name="res_badge" position="40,72" size="55,42" alphatest="blend" zPosition="5" transparent="1" />
    <widget name="channel_num" position="110,64" size="130,60" font="SkyCairo;36" foregroundColor="#00ff88" transparent="1" zPosition="5" />
    <widget name="channel_name" position="260,58" size="700,72" font="SkyCairo;48" foregroundColor="#ffffff" transparent="1" zPosition="5" />
    <widget name="provider_name" position="265,128" size="700,32" font="SkyCairo;24" foregroundColor="#00e5ff" transparent="1" zPosition="5" />

    <!-- Colossal Amber Gold dB (82pt font with 120px height, zero overlap) -->
    <widget name="snr_db" position="980,44" size="560,120" font="SkyCairo;82" foregroundColor="#ffd700" halign="center" valign="center" transparent="1" zPosition="5" />

    <!-- ================= ROW 3: DUAL EXTRA-THICK 68px SIGNAL POWER BARS ================= -->
    <eLabel text="SNR:" position="40,178" size="110,54" font="SkyCairo;34" foregroundColor="#00ffff" transparent="1" zPosition="4" />
    <widget name="snr_progress" position="160,172" size="1550,68" pixmap="{IMG_DIR}/bar_qual_gold_emerald.png" backgroundColor="#0a0a0f" zPosition="4" borderWidth="2" borderColor="#00ffff" />
    <widget name="snr_percent" position="1725,170" size="155,72" font="SkyCairo;42" foregroundColor="#00ff88" halign="right" valign="center" transparent="1" zPosition="4" />

    <eLabel text="AGC:" position="40,258" size="110,54" font="SkyCairo;34" foregroundColor="#ff007f" transparent="1" zPosition="4" />
    <widget name="agc_progress" position="160,252" size="1550,68" pixmap="{IMG_DIR}/bar_agc_crystal.png" backgroundColor="#0a0a0f" zPosition="4" borderWidth="2" borderColor="#ff007f" />
    <widget name="agc_percent" position="1725,250" size="155,72" font="SkyCairo;42" foregroundColor="#ff00aa" halign="right" valign="center" transparent="1" zPosition="4" />

    <eLabel position="40,332" size="1840,1" backgroundColor="#2a1b40" zPosition="2" />

    <!-- ================= ROW 4: STREAM TELEMETRY & CLEAR EVENT PROGRESS ================= -->
    <widget name="caids_line" position="40,340" size="1050,38" font="SkyCairo;28" foregroundColor="#ff7700" transparent="1" zPosition="4" />
    <widget name="active_caid" position="1120,340" size="760,38" font="SkyCairo;28" foregroundColor="#00ff88" halign="right" transparent="1" zPosition="4" />

    <widget name="pids_grid" position="40,382" size="1840,34" font="SkyCairo;26" foregroundColor="#ff66ff" transparent="1" zPosition="4" />

    <widget name="event_title" position="40,420" size="1050,50" font="Regular;28" foregroundColor="#00ffcc" valign="center" transparent="1" zPosition="4" />
    <widget name="event_progress" position="1110,438" size="560,16" pixmap="{IMG_DIR}/bar_snr.png" zPosition="4" borderWidth="1" borderColor="#00ffff" />
    <widget name="event_time" position="1690,424" size="190,42" font="SkyCairo;24" foregroundColor="#ffd700" halign="right" valign="center" transparent="1" zPosition="4" />

    <eLabel position="40,474" size="1840,1" backgroundColor="#2a1b40" zPosition="2" />

    <!-- Lock, Stream Summary & BER -->
    <widget name="lock_badge" position="40,482" size="550,36" font="SkyCairo;28" foregroundColor="#00ff88" transparent="1" zPosition="4" />
    <widget name="stream_summary" position="610,482" size="820,36" font="SkyCairo;26" foregroundColor="#00ffff" halign="center" transparent="1" zPosition="4" />
    <widget name="ber_value" position="1450,482" size="430,36" font="SkyCairo;28" foregroundColor="#ff007f" halign="right" transparent="1" zPosition="4" />

    <eLabel position="40,524" size="1840,2" backgroundColor="#ff007f" zPosition="2" />

    <!-- ================= ROW 5: 4 GLASS CARDS + TRANSPONDER + SOFTCAM BOX + MINI TV ================= -->
    <ePixmap position="40,536" size="220,130" pixmap="{IMG_DIR}/picon_frame.png" alphatest="blend" zPosition="4" transparent="1" />
    <widget name="picon" position="45,541" size="210,120" alphatest="blend" zPosition="5" transparent="1" />

    <ePixmap position="275,536" size="220,130" pixmap="{IMG_DIR}/picon_frame.png" alphatest="blend" zPosition="4" transparent="1" />
    <widget name="prov_logo" position="280,541" size="210,120" alphatest="blend" zPosition="5" transparent="1" />

    <ePixmap position="510,536" size="220,130" pixmap="{IMG_DIR}/picon_frame.png" alphatest="blend" zPosition="4" transparent="1" />
    <widget name="sat_logo" position="515,541" size="210,120" alphatest="blend" zPosition="5" transparent="1" />

    <ePixmap position="745,536" size="220,130" pixmap="{IMG_DIR}/picon_frame.png" alphatest="blend" zPosition="4" transparent="1" />
    <widget name="crypt_logo" position="750,541" size="210,120" alphatest="blend" zPosition="5" transparent="1" />

    <widget name="tp_line1" position="40,676" size="650,46" font="SkyCairo;36" foregroundColor="#ffd700" transparent="1" zPosition="5" />
    <widget name="tp_line2" position="700,680" size="580,42" font="SkyCairo;30" foregroundColor="#00ffff" transparent="1" zPosition="5" />
    <widget name="sat_badge" position="40,726" size="650,36" font="SkyCairo;25" foregroundColor="#00e5ff" transparent="1" zPosition="5" />
    <widget name="tuner_badge" position="700,726" size="580,36" font="SkyCairo;25" foregroundColor="#ffd700" transparent="1" zPosition="5" />

    <!-- Softcam Box Below Picons in Cyber Neon -->
    <eLabel position="40,770" size="1255,142" backgroundColor="#04030508" zPosition="2" />
    <eLabel position="40,770" size="1255,2" backgroundColor="#00ffff" zPosition="3" />
    <eLabel position="40,910" size="1255,2" backgroundColor="#ff007f" zPosition="3" />
    <widget name="cam_server_line" position="55,776" size="1225,42" font="SkyCairo;25" foregroundColor="#ffd700" valign="center" transparent="1" zPosition="5" />
    <widget name="cam_ecm_line" position="55,820" size="1225,42" font="SkyCairo;24" foregroundColor="#00ffff" valign="center" transparent="1" zPosition="5" />
    <widget name="cam_cw_line" position="55,864" size="1225,42" font="SkyCairo;25" foregroundColor="#00ff88" valign="center" transparent="1" zPosition="5" />

    <!-- ================= LIVE MINI TV WINDOW (PICTURE-IN-GRAPHIC) ================= -->
    <eLabel text="📺 LIVE CHANNEL BROADCAST" position="1320,536" size="550,28" font="SkyCairo;22" foregroundColor="#00ffff" transparent="1" zPosition="5" />
    <eLabel position="1318,570" size="554,342" backgroundColor="#00ffff" zPosition="2" />
    <widget source="session.VideoPicture" render="Pig" position="1320,572" size="550,338" zPosition="3" backgroundColor="#ff000000" />

    <!-- Navigation Shortcuts -->
    <eLabel position="40,1020" size="1840,40" backgroundColor="#06040507" zPosition="2" />
    <eLabel text="[MENU] إعدادات وتحديث    [&lt; / &gt;] تصفح القنوات    [Blue] الستايل    [7] الطيف    [Rec/Help] لقطة شاشة    [0] تخصيص الزر    [Exit] إغلاق" position="40,1024" size="1840,32" font="SkyCairo;22" foregroundColor="#00e5ff" halign="center" transparent="1" zPosition="5" />
</screen>
""".format(IMG_DIR=IMG_DIR)

# ==============================================================================
# STYLE 4: Ultra Slim Sports HUD (Floating Bottom Banner on Pure Black)
# ==============================================================================
SKIN_SLIM_HUD = """
<screen name="SkyBlueSignalSlim" position="120,760" size="1680,285" title="SkyBlue Signal Slim" flags="wfNoBorder" backgroundColor="#04000000">
    <eLabel position="0,0" size="1680,3" backgroundColor="#00ffff" zPosition="10" />
    <eLabel position="0,282" size="1680,3" backgroundColor="#ffd700" zPosition="10" />

    <widget name="picon" position="25,18" size="180,105" alphatest="blend" zPosition="5" transparent="1" />
    <widget name="channel_name" position="25,128" size="280,48" font="SkyCairo;32" foregroundColor="#ffffff" transparent="1" zPosition="5" />
    <widget name="provider_name" position="25,178" size="280,34" font="SkyCairo;22" foregroundColor="#00e5ff" transparent="1" zPosition="5" />
    <widget name="lock_badge" position="25,216" size="280,34" font="SkyCairo;22" foregroundColor="#00ff88" transparent="1" zPosition="5" />

    <widget name="snr_db" position="315,10" size="360,104" font="SkyCairo;70" foregroundColor="#ffd700" halign="center" valign="center" transparent="1" zPosition="5" />
    
    <eLabel text="SNR:" position="680,20" size="90,50" font="SkyCairo;30" foregroundColor="#00ffff" halign="right" transparent="1" zPosition="4" />
    <widget name="snr_progress" position="780,16" size="735,48" pixmap="{IMG_DIR}/bar_qual_gold_emerald.png" zPosition="4" borderWidth="2" borderColor="#00ffff" />
    <widget name="snr_percent" position="1525,14" size="135,54" font="SkyCairo;34" foregroundColor="#00ff88" valign="center" transparent="1" zPosition="4" />

    <eLabel text="AGC:" position="680,74" size="90,50" font="SkyCairo;30" foregroundColor="#ff007f" halign="right" transparent="1" zPosition="4" />
    <widget name="agc_progress" position="780,70" size="735,48" pixmap="{IMG_DIR}/bar_agc_crystal.png" zPosition="4" borderWidth="2" borderColor="#ff007f" />
    <widget name="agc_percent" position="1525,68" size="135,54" font="SkyCairo;34" foregroundColor="#ff00aa" valign="center" transparent="1" zPosition="4" />

    <widget name="tp_line1" position="320,124" size="450,38" font="SkyCairo;30" foregroundColor="#ffd700" transparent="1" zPosition="5" />
    <widget name="stream_summary" position="780,124" size="550,34" font="SkyCairo;24" foregroundColor="#00ffff" transparent="1" zPosition="5" />
    <widget name="clock_time" position="1350,124" size="300,34" font="SkyCairo;24" foregroundColor="#ffd700" halign="right" transparent="1" zPosition="5" />

    <widget name="event_title" position="320,164" size="800,48" font="Regular;26" foregroundColor="#00ffcc" valign="center" transparent="1" zPosition="5" />
    <widget name="event_time" position="1130,168" size="180,40" font="SkyCairo;22" foregroundColor="#ffd700" halign="right" valign="center" transparent="1" zPosition="4" />
    <widget name="event_progress" position="1320,182" size="330,14" pixmap="{IMG_DIR}/bar_snr.png" zPosition="4" borderWidth="1" borderColor="#00ffff" />

    <widget name="cam_server_line" position="320,216" size="1330,32" font="SkyCairo;21" foregroundColor="#ffd700" transparent="1" zPosition="5" />
    <widget name="cam_cw_line" position="320,248" size="1330,32" font="SkyCairo;21" foregroundColor="#00ff88" transparent="1" zPosition="5" />
</screen>
""".format(IMG_DIR=IMG_DIR)
