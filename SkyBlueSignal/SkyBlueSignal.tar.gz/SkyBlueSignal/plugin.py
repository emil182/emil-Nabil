# -*- coding: utf-8 -*-
"""
SkyBlueSignal Pro - Next Generation Satellite Signal Cockpit (Pure Black OLED Edition)
Version: 1.3.0
Author: SkyBlue Team
Features:
- Pro Observatory Cockpit (Default Pure Black OLED, 86pt dB, Dual-Spectrum, Softcam/CW Box & Live Mini TV)
- Distinct 3D Crystal Bar Colors for SNR (Quality) vs AGC (RF Power) + Customizable Quality Bar Theme
- Direct Remote Hotkey Capture (RaedQuickSignal-style KeyCaptureScreen + instant GlobalActionMap binding)
- Crash-free <15ms UP/DOWN/Blue style switching via deferred modal reopen timer
"""

import os
import threading
from datetime import datetime

# Enigma2 Core Imports
from Screens.Screen import Screen
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.ProgressBar import ProgressBar
from Components.Pixmap import Pixmap
from Components.config import (
    config,
    ConfigSubsection,
    ConfigSelection,
    ConfigText,
    configfile,
)
from GlobalActions import globalActionMap
from enigma import eTimer, addFont, eActionMap, eRCInput
from Tools.LoadPixmap import LoadPixmap
from Plugins.Plugin import PluginDescriptor

try:
    from keymapparser import readKeymap, removeKeymap
except Exception:
    try:
        from Components.ActionMap import loadKeymap as readKeymap, removeKeymap
    except Exception:
        readKeymap = None
        removeKeymap = None

# Internal Modules
from .engine import SignalEngine, fit_image_to_card, _get_osc_bg_template
from .beeper import SignalBeeper
from .skin_modern import (
    SKIN_GX_ELITE,
    SKIN_PRO_OBSERVATORY,
    SKIN_CYBER_NEON,
    SKIN_SLIM_HUD,
)

PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
FONTS_DIR = os.path.join(PLUGIN_DIR, "fonts")
IMAGES_DIR = os.path.join(PLUGIN_DIR, "images")
KEYMAP_PATH = os.path.join(PLUGIN_DIR, "keymap.xml")

# Global RAM caches for instant zero-spinner opening & style switching
_SHARED_ENGINE = None
_PIXMAP_CACHE = {}
FONTS_INITIALIZED = False

# Deferred modal reopen state (prevents StartEnigma 'Modal open are allowed only from a screen which is modal!' crash)
_PENDING_REOPEN = {"session": None, "style": None}
_REOPEN_TIMER = eTimer()


def _execute_deferred_reopen():
    sess = _PENDING_REOPEN.get("session")
    st = _PENDING_REOPEN.get("style")
    _PENDING_REOPEN["session"] = None
    _PENDING_REOPEN["style"] = None
    if sess is not None:
        try:
            sess.open(SkyBlueSignalScreen, style=st)
        except Exception:
            pass


try:
    _REOPEN_TIMER.callback.append(_execute_deferred_reopen)
except Exception:
    pass

# Setup Persistent Configuration
config.plugins.SkyBlueSignal = ConfigSubsection()
config.plugins.SkyBlueSignal.style = ConfigSelection(
    default="observatory",
    choices=[
        ("observatory", "👑 Pro Observatory Black (المرصد الأسود الملكي - الافتراضي)"),
        ("gx", "💎 GX Classic Elite (ستايل أجهزة GX الأسطوري)"),
        ("cyber", "⚡ Cyber Neon HUD (السيبراني الأسود النيون)"),
        ("slim", "🎯 Ultra Slim Sports HUD (شريط الاستاد السفلي للمباريات)"),
    ],
)
config.plugins.SkyBlueSignal.style_black_default = ConfigSelection(
    default="observatory",
    choices=[
        ("observatory", "👑 Pro Observatory Black (المرصد الأسود الملكي - الافتراضي)"),
        ("gx", "💎 GX Classic Elite (ستايل أجهزة GX الأسطوري)"),
        ("cyber", "⚡ Cyber Neon HUD (السيبراني الأسود النيون)"),
        ("slim", "🎯 Ultra Slim Sports HUD (شريط الاستاد السفلي للمباريات)"),
    ],
)
config.plugins.SkyBlueSignal.quality_bar_color = ConfigSelection(
    default="gold_emerald",
    choices=[
        ("gold_emerald", "🌟 الذهبي والزمردي المشع (Solar Gold & Emerald - الافتراضي المميز)"),
        ("cyber_ice", "💎 الكريستال السماوي والأزرق الملكي (Cyber Ice & Sapphire)"),
        ("lava_fire", "🔥 الطيف الناري المتوهج (Volcanic Fire & Supernova Gold)"),
        ("aurora_jewel", "🔮 طيف الجواهر البنفسجي والوردي (Aurora Amethyst & Rose)"),
    ],
)
config.plugins.SkyBlueSignal.keyname = ConfigText(default="KEY_F1", fixed_size=False)
config.plugins.SkyBlueSignal.timeout = ConfigSelection(
    default="0",
    choices=[
        ("0", "دائم (لا يغلق إلا بالضغط على Exit)"),
        ("5", "إغلاق تلقائي بعد 5 ثوانٍ"),
        ("10", "إغلاق تلقائي بعد 10 ثوانٍ"),
        ("15", "إغلاق تلقائي بعد 15 ثانية"),
    ],
)
config.plugins.SkyBlueSignal.spectrum_style = ConfigSelection(
    default="fire_dual",
    choices=[
        ("fire_dual", "🔥 الطيف المزدوج الناري والسماوي (Dual Fire & Laser Cyan)"),
        ("matrix_neon", "⚡ طيف الماتريكس السيبراني النيون (Cyber Matrix Laser Wave)"),
        ("retro_led", "📊 طيف الـ LED الاحترافي (Retro 40-CH Broadcast Equalizer)"),
        ("aurora_cosmic", "🌌 طيف الشفق القطبي الكوني (Cosmic Aurora Borealis)"),
    ],
)
config.plugins.SkyBlueSignal.update_url = ConfigText(
    default="https://updates.skyblue1.us/e2/signal/SkyBlueSignal.tar.gz",
    fixed_size=False,
)

QUALITY_BAR_FILES = {
    "gold_emerald": os.path.join(IMAGES_DIR, "bar_qual_gold_emerald.png"),
    "cyber_ice": os.path.join(IMAGES_DIR, "bar_qual_cyber_ice.png"),
    "lava_fire": os.path.join(IMAGES_DIR, "bar_qual_lava_fire.png"),
    "aurora_jewel": os.path.join(IMAGES_DIR, "bar_rainbow.png"),
}


def register_fonts():
    """Registers modern Cairo and Osama fonts once per Enigma2 session."""
    global FONTS_INITIALIZED
    if FONTS_INITIALIZED:
        return
    try:
        cairo_path = os.path.join(FONTS_DIR, "Cairo-Bold.ttf")
        if os.path.exists(cairo_path):
            addFont(cairo_path, "SkyCairo", 100, False, 0)

        osama_path = os.path.join(FONTS_DIR, "Osama.otf")
        if os.path.exists(osama_path):
            addFont(osama_path, "SkyOsama", 100, False, 0)

        _get_osc_bg_template()
        FONTS_INITIALIZED = True
    except Exception:
        pass


def get_shared_engine(session):
    """Returns shared SignalEngine instance so history & caches persist across opens and style switches."""
    global _SHARED_ENGINE
    if _SHARED_ENGINE is None:
        _SHARED_ENGINE = SignalEngine(session)
    else:
        _SHARED_ENGINE.session = session
    return _SHARED_ENGINE


def load_cached_card_pixmap(src_path, dst_path):
    """Loads fitted card pixmap from RAM cache in 0ms, or fits once and caches."""
    if not src_path or not os.path.exists(src_path):
        return None
    if src_path in _PIXMAP_CACHE:
        return _PIXMAP_CACHE[src_path]
    try:
        fit_path = fit_image_to_card(src_path, dst_path)
        pix = LoadPixmap(fit_path or src_path)
        if pix:
            _PIXMAP_CACHE[src_path] = pix
        return pix
    except Exception:
        return None


def get_screenshot_directory():
    """Discovers available storage (HDD/USB/Flash) and returns dedicated SkyBlueScreenshots folder."""
    candidates = [
        "/media/hdd",
        "/media/usb",
        "/media/sda1",
        "/media/sdb1",
        "/media/mmc",
    ]
    for mount in candidates:
        if os.path.isdir(mount) and os.access(mount, os.W_OK):
            shot_dir = os.path.join(mount, "SkyBlueScreenshots")
            try:
                os.makedirs(shot_dir, exist_ok=True)
                return shot_dir
            except Exception:
                pass
    fallback = "/tmp/SkyBlueScreenshots"
    try:
        os.makedirs(fallback, exist_ok=True)
    except Exception:
        pass
    return fallback


def get_skin_by_style(style_key):
    """Returns the matching XML skin for the selected style."""
    if style_key == "gx":
        return SKIN_GX_ELITE
    elif style_key == "cyber":
        return SKIN_CYBER_NEON
    elif style_key == "slim":
        return SKIN_SLIM_HUD
    return SKIN_PRO_OBSERVATORY


class KeyCaptureScreen(Screen):
    """
    RaedQuickSignal-style interactive remote control key capture dialog.
    Captures any remote button pressed by the user and assigns it as the direct launch hotkey.
    """

    skin = """
    <screen name="SkyBlueKeyCapture" position="center,center" size="920,260" title="SkyBlue Signal Hotkey" flags="wfNoBorder" backgroundColor="#04000000">
        <eLabel position="0,0" size="920,3" backgroundColor="#ffd700" zPosition="10" />
        <eLabel position="0,257" size="920,3" backgroundColor="#00ffff" zPosition="10" />
        <eLabel position="0,0" size="3,260" backgroundColor="#ffd700" zPosition="10" />
        <eLabel position="917,0" size="3,260" backgroundColor="#00ffff" zPosition="10" />
        <widget name="title_lbl" position="20,18" size="880,48" font="Regular;32" foregroundColor="#ffd700" halign="center" valign="center" transparent="1" zPosition="5" />
        <widget name="label" position="20,78" size="880,96" font="Regular;28" foregroundColor="#00ffff" halign="center" valign="center" transparent="1" zPosition="5" />
        <widget name="sub_lbl" position="20,188" size="880,46" font="Regular;24" foregroundColor="#00ff88" halign="center" valign="center" transparent="1" zPosition="5" />
    </screen>
    """

    def __init__(self, session):
        register_fonts()
        Screen.__init__(self, session)
        cur_key = config.plugins.SkyBlueSignal.keyname.value or "KEY_F1"
        self["title_lbl"] = Label("تخصيص زر التشغيل المباشر (SkyBlue Signal Pro)")
        self["label"] = Label("اضغط الآن على أي زر في الريموت لتخصيصه لتشغيل البلجن مباشرة")
        self["sub_lbl"] = Label("الزر الحالي: [ {} ]   |   اضغط [ EXIT ] للإلغاء".format(cur_key))
        self.key_caught = False
        self["actions"] = ActionMap(
            ["SetupActions", "WizardActions", "MenuActions"],
            {
                "cancel": self.close,
                "ok": self.dummy,
                "up": self.dummy,
                "down": self.dummy,
                "left": self.dummy,
                "right": self.dummy,
            },
            -100,
        )
        self.onFirstExecBegin.append(self.startHook)
        self.onClose.append(self.stopHook)

    def dummy(self):
        return 1

    def startHook(self):
        try:
            self.hook_slot = eActionMap.getInstance().bindAction("", -2147483648, self.keyPressed)
        except Exception:
            pass

    def stopHook(self):
        try:
            if hasattr(self, "hook_slot"):
                self.hook_slot = None
                eActionMap.getInstance().unbindAction("", self.keyPressed)
        except Exception:
            pass

    def keyPressed(self, key, flag):
        if flag == 1:
            keyname = self.resolveKeyName(key)
            if keyname:
                if keyname in ("KEY_EXIT", "KEY_ESC"):
                    self.close(None)
                    return 1
                if not self.key_caught:
                    self.key_caught = True
                    self.close(keyname)
                    return 1
        return 1

    def resolveKeyName(self, key):
        try:
            from keyids import KEYIDS
            for name, k_id in KEYIDS.items():
                if k_id == key:
                    return name
        except Exception:
            pass
        try:
            rc = eRCInput.getInstance()
            if hasattr(rc, "getLabel"):
                return rc.getLabel(key)
            if hasattr(rc, "getKeyName"):
                return rc.getKeyName(key)
        except Exception:
            pass
        return None


class SkyBlueScreenshotNotice(Screen):
    """Sleek, glassmorphic toast notification shown strictly AFTER the screenshot file is saved."""

    skin = """
    <screen name="SkyBlueScreenshotNotice" position="center,center" size="920,185" flags="wfNoBorder" backgroundColor="#04000000" zPosition="999">
        <eLabel position="0,0" size="920,2" backgroundColor="#00ffff" zPosition="10" />
        <eLabel position="0,183" size="920,2" backgroundColor="#ffd700" zPosition="10" />
        <eLabel position="0,0" size="2,185" backgroundColor="#00ffff" zPosition="10" />
        <eLabel position="918,0" size="2,185" backgroundColor="#ffd700" zPosition="10" />
        <eLabel position="2,2" size="916,181" backgroundColor="#0804060c" zPosition="1" />

        <widget name="title" position="20,12" size="880,38" font="SkyCairo;27" foregroundColor="#ffd700" halign="center" transparent="1" zPosition="5" />
        <widget name="path_lbl" position="20,52" size="880,36" font="SkyCairo;22" foregroundColor="#00ffff" halign="center" transparent="1" zPosition="5" />
        <widget name="sub_lbl" position="20,90" size="880,34" font="SkyCairo;22" foregroundColor="#00ff88" halign="center" transparent="1" zPosition="5" />
        <eLabel text="[ تم الحفظ بنجاح  ▪  تغلق هذه الرسالة تلقائياً خلال ثانيتين ]" position="20,132" size="880,30" font="SkyCairo;20" foregroundColor="#8899aa" halign="center" transparent="1" zPosition="5" />
    </screen>
    """

    def __init__(self, session, shot_path, filename):
        register_fonts()
        Screen.__init__(self, session)
        self["title"] = Label("📸 تم التقاط لقطة الشاشة بنجاح بدقة فائقة (Full HD 1080p)")
        self["path_lbl"] = Label("📁 " + shot_path)
        self["sub_lbl"] = Label("✅ الجودة: 1080p Bicubic Lossless PNG (صورة نقية بدون أي رسائل)")
        self["actions"] = ActionMap(["OkCancelActions"], {"ok": self.close, "cancel": self.close}, -1)
        self.timer = eTimer()
        self.timer.callback.append(self.close)
        self.onLayoutFinish.append(self._start_timer)

    def _start_timer(self):
        self.timer.start(2200, True)


class SkyBlueSignalHotKey(object):
    """Global Hotkey Manager (works identically to RaedQuickSignal pSignal with live reload)."""

    def __init__(self):
        self.session = None
        self.loaded_keymap = False

    def gotSession(self, session):
        self.session = session
        self.bind_keymap(config.plugins.SkyBlueSignal.keyname.value)

    def bind_keymap(self, keyname=None):
        if not keyname:
            keyname = config.plugins.SkyBlueSignal.keyname.value or "KEY_F1"
        try:
            if self.loaded_keymap and removeKeymap and os.path.exists(KEYMAP_PATH):
                try:
                    removeKeymap(KEYMAP_PATH)
                except Exception:
                    pass

            xml_content = (
                '<keymap>\n'
                '\t<map context="GlobalActions">\n'
                '\t\t<key id="%s" mapto="showSkyBlueSignal" flags="m" />\n'
                '\t</map>\n'
                '</keymap>\n' % keyname
            )
            with open(KEYMAP_PATH, "w") as kf:
                kf.write(xml_content)

            if readKeymap:
                readKeymap(KEYMAP_PATH)
                self.loaded_keymap = True

            globalActionMap.actions["showSkyBlueSignal"] = self.show_hide
        except Exception:
            pass

    def show_hide(self):
        if self.session is None:
            return
        try:
            # If SkyBlueSignalScreen is already open, pressing the hotkey closes it cleanly
            if isinstance(getattr(self.session, "current_dialog", None), SkyBlueSignalScreen):
                self.session.current_dialog.key_exit()
                return

            # Open only when current dialog is modal and in_exec
            if getattr(self.session, "in_exec", True):
                self.session.open(SkyBlueSignalScreen)
        except Exception:
            pass


pSkyBlueHotkey = SkyBlueSignalHotKey()


class SkyBlueSignalScreen(Screen):
    """Next-Gen Satellite Signal Cockpit Screen with Pure Black OLED default & zero-spinner engine."""

    skin = SKIN_PRO_OBSERVATORY

    def __init__(self, session, style=None):
        register_fonts()
        self.session = session
        self.current_style = style or config.plugins.SkyBlueSignal.style_black_default.value or "observatory"
        self.skin = get_skin_by_style(self.current_style)
        Screen.__init__(self, session)

        # Ensure hotkey manager has session reference
        if pSkyBlueHotkey.session is None:
            pSkyBlueHotkey.gotSession(session)

        # Core Engines
        self.engine = get_shared_engine(session)
        self.beeper = SignalBeeper()
        self.cached_tp = None
        self.cached_srv = None
        self.tick_count = 0
        self._graph_busy = False
        self._graph_ready_path = ""

        # UI Widgets - 4 Cards, Badges & Oscilloscope
        self["picon"] = Pixmap()
        self["prov_logo"] = Pixmap()
        self["sat_logo"] = Pixmap()
        self["crypt_logo"] = Pixmap()
        self["res_badge"] = Pixmap()
        self["signal_graph"] = Pixmap()

        # GX Signature Widgets
        self["gx_sat_name"] = Label("")
        self["gx_freq_line"] = Label("")
        self["gx_snr_ber_line"] = Label("")
        self["gx_s_progress"] = ProgressBar()
        self["gx_s_percent"] = Label("0%")
        self["gx_q_progress"] = ProgressBar()
        self["gx_q_percent"] = Label("0%")

        # Channel & Telemetry
        self["channel_num"] = Label("")
        self["channel_name"] = Label("Loading...")
        self["provider_name"] = Label("")
        self["clock_time"] = Label("--:--:--")

        # Live Event & Match Tracking
        self["event_title"] = Label("")
        self["event_time"] = Label("")
        self["event_progress"] = ProgressBar()

        # Signal Gauges
        self["snr_db"] = Label("0.00 dB")
        self["snr_progress"] = ProgressBar()
        self["snr_percent"] = Label("0%")
        self["agc_progress"] = ProgressBar()
        self["agc_percent"] = Label("0%")
        self["ber_value"] = Label("BER: 0")
        self["lock_badge"] = Label("Checking Signal...")

        # Sensitivity & Stability Metrics
        self["margin_badge"] = Label("")
        self["sensitivity_badge"] = Label("")
        self["stability_badge"] = Label("")
        self["cn_ratio"] = Label("")

        # Transponder & Stream Info
        self["stream_summary"] = Label("")
        self["pids_grid"] = Label("")
        self["caids_line"] = Label("")
        self["active_caid"] = Label("")
        self["tp_freq_pol"] = Label("")
        self["tp_sys_mod"] = Label("")
        self["tp_line1"] = Label("")
        self["tp_line2"] = Label("")
        self["tp_line3"] = Label("")
        self["sat_badge"] = Label("")
        self["tuner_badge"] = Label("")
        self["beeper_status"] = Label("🔊 Audio Tone: Ready")
        self["key_yellow"] = Label("Tone (ON/OFF)")

        # Dedicated Softcam / Server Host / CW Key Widgets
        self["cam_server_line"] = Label("🖥 Checking Softcam / Server...")
        self["cam_ecm_line"] = Label("")
        self["cam_cw_line"] = Label("")

        # Action Map (Remote Control Keys)
        self["actions"] = ActionMap(
            [
                "OkCancelActions",
                "ColorActions",
                "DirectionActions",
                "MenuActions",
                "NumberActions",
                "InfobarChannelSelection",
                "ChannelSelectBaseActions",
                "HelpActions",
                "InfobarRecordActions",
            ],
            {
                "ok": self.key_exit,
                "cancel": self.key_exit,
                "red": self.key_satfinder,
                "green": self.key_positioner,
                "yellow": self.key_toggle_beeper,
                "blue": self.key_choose_style,
                "menu": self.key_open_settings_menu,
                "0": self.key_capture_hotkey_direct,
                "7": self.key_cycle_spectrum,
                "8": self.key_take_screenshot,
                "help": self.key_take_screenshot,
                "displayHelp": self.key_take_screenshot,
                "record": self.key_take_screenshot,
                "left": self.key_zap_prev,
                "right": self.key_zap_next,
                "up": self.key_cycle_style_prev,
                "down": self.key_cycle_style_next,
                "zapUp": self.key_zap_prev,
                "zapDown": self.key_zap_next,
                "nextBouquet": self.key_zap_next,
                "prevBouquet": self.key_zap_prev,
            },
            -1,
        )

        # Signal refresh timer (250ms ultra-smooth & fast)
        self.refresh_timer = eTimer()
        self.refresh_timer.callback.append(self.update_live_signals)

        # Turbo Zap Polling timer (50ms burst for instantaneous tuner lock during channel browsing)
        self.zap_turbo_timer = eTimer()
        self.zap_turbo_timer.callback.append(self.on_zap_turbo_tick)
        self._zap_turbo_count = 0

        # Graph refresh timer (1200ms non-blocking threaded)
        self.graph_timer = eTimer()
        self.graph_timer.callback.append(self.update_graph_tick)

        # Deferred logo/graph loader for instant 0ms window appearance
        self.init_defer_timer = eTimer()
        self.init_defer_timer.callback.append(self._deferred_load_assets)

        # Zap refresh timer
        self.zap_timer = eTimer()
        self.zap_timer.callback.append(self.load_static_metadata)

        # Auto-timeout timer
        self.timeout_timer = eTimer()
        self.timeout_timer.callback.append(self.key_exit)

        self.onLayoutFinish.append(self.on_layout_ready)
        self.onClose.append(self.on_screen_close)

    def apply_quality_bar_color(self):
        """Applies the user-selected distinct 3D Crystal Quality Bar pixmap to SNR/Q bars."""
        try:
            q_theme = config.plugins.SkyBlueSignal.quality_bar_color.value or "gold_emerald"
            bar_path = QUALITY_BAR_FILES.get(q_theme, QUALITY_BAR_FILES["gold_emerald"])
            if os.path.exists(bar_path):
                pix = _PIXMAP_CACHE.get(bar_path) or LoadPixmap(bar_path)
                if pix:
                    _PIXMAP_CACHE[bar_path] = pix
                    if self["snr_progress"].instance:
                        self["snr_progress"].instance.setPixmap(pix)
                        self["snr_progress"].instance.invalidate()
                    if self["gx_q_progress"].instance:
                        self["gx_q_progress"].instance.setPixmap(pix)
                        self["gx_q_progress"].instance.invalidate()
        except Exception:
            pass

    def on_layout_ready(self):
        """Called once skin layout is initialized. Loads text in <5ms, defers heavy images by 30ms."""
        self.apply_quality_bar_color()
        self.load_text_metadata()
        self.update_live_signals()

        # Load existing oscilloscope frame immediately if present in /tmp
        if self.current_style in ["gx", "observatory"] and os.path.exists("/tmp/signal_oscilloscope.png"):
            try:
                pix = LoadPixmap("/tmp/signal_oscilloscope.png", cached=False)
                if pix:
                    self["signal_graph"].instance.setPixmap(pix)
            except Exception:
                pass

        self.init_defer_timer.start(30, True)
        self.refresh_timer.start(250, False)

        if self.current_style in ["gx", "observatory"]:
            self.graph_timer.start(1200, False)

        try:
            to_sec = int(config.plugins.SkyBlueSignal.timeout.value)
            if to_sec > 0:
                self.timeout_timer.start(to_sec * 1000, True)
        except Exception:
            pass

    def load_static_metadata(self):
        """Reloads both text metadata and card logos after channel zap."""
        self.cached_tp = None
        self.cached_srv = None
        self.load_text_metadata()
        self._deferred_load_assets()
        self.update_live_signals()

    def load_text_metadata(self):
        """Instant (<3ms) text metadata extraction with zero PIL image processing."""
        try:
            tp = self.engine.get_transponder_data()
            self.cached_tp = tp
            self["gx_sat_name"].setText(tp["satellite_name_arabic"])
            self["gx_freq_line"].setText(tp["gx_freq_line"])
            self["tp_freq_pol"].setText(tp["tp_line1"])
            self["tp_sys_mod"].setText(tp["tp_line2"] + "  ▪  " + tp["tp_line3"])
            self["tp_line1"].setText(tp["tp_line1"])
            self["tp_line2"].setText(tp["tp_line2"])
            self["tp_line3"].setText(tp["tp_line3"])
            self["sat_badge"].setText("🛰️ " + tp["satellite_name"])
            self["tuner_badge"].setText("📡 " + tp["tuner_name"])

            srv = self.engine.get_service_stream_data()
            self.cached_srv = srv
            self["channel_name"].setText(srv["channel_name"])
            self["provider_name"].setText(srv["provider"])
            self["channel_num"].setText(srv["channel_num"])

            ev = self.engine.get_event_data()
            self["event_title"].setText(ev["title"])
            self["event_time"].setText(ev["time_str"])
            self["event_progress"].setValue(ev["progress"])

            hdr_badge = " ▪ " + srv["hdr_info"] if srv["hdr_info"] != "SDR" else ""
            uhd_badge = srv.get("res_text", "4K UHD" if srv["is_uhd"] else ("HD" if srv.get("is_hd") else "SD"))
            stream_str = "{} @ {} ▪ {} ▪ {}{}".format(
                srv["resolution"],
                srv["framerate"],
                uhd_badge,
                srv["audio_info"],
                hdr_badge,
            )
            self["stream_summary"].setText(stream_str)

            pids_str = "SID: {} ▪ VPID: {} ▪ APID: {} ▪ PMT: {} ▪ TSID: {} ▪ ONID: {}".format(
                srv["sid"], srv["vpid"], srv["apid"], srv["pmt"], srv["tsid"], srv["onid"]
            )
            self["pids_grid"].setText(pids_str)
            self["caids_line"].setText(srv["caids_line"])
            self["active_caid"].setText(srv["active_caid"])

            # Load Softcam / OSCam / CCcam Server & CW telemetry
            sc = self.engine.get_softcam_data(srv["is_crypted"], srv["first_caid"])
            self["cam_server_line"].setText(sc["cam_server_line"])
            self["cam_ecm_line"].setText(sc["cam_ecm_line"])
            self["cam_cw_line"].setText(sc["cam_cw_line"])
        except Exception:
            pass

    def _deferred_load_assets(self):
        """Loads card logos from RAM cache (0ms) or fits once after screen is already visible."""
        try:
            tp = self.cached_tp or self.engine.get_transponder_data()
            srv = self.cached_srv or self.engine.get_service_stream_data()

            # Resolution Badge
            if srv["res_badge_path"]:
                pix = _PIXMAP_CACHE.get(srv["res_badge_path"]) or LoadPixmap(srv["res_badge_path"])
                if pix:
                    _PIXMAP_CACHE[srv["res_badge_path"]] = pix
                    self["res_badge"].instance.setPixmap(pix)
                    self["res_badge"].show()
                else:
                    self["res_badge"].hide()
            else:
                self["res_badge"].hide()

            if self.current_style in ["observatory", "cyber", "slim"]:
                pix_picon = load_cached_card_pixmap(srv["picon_path"], "/tmp/sb_fit_picon.png")
                if pix_picon:
                    self["picon"].instance.setPixmap(pix_picon)
                    self["picon"].show()
                else:
                    self["picon"].hide()

            if self.current_style in ["observatory", "cyber"]:
                pix_sat = load_cached_card_pixmap(tp["sat_logo_path"], "/tmp/sb_fit_sat.png")
                if pix_sat:
                    self["sat_logo"].instance.setPixmap(pix_sat)
                    self["sat_logo"].show()
                else:
                    self["sat_logo"].hide()

                pix_prov = load_cached_card_pixmap(srv["prov_logo_path"], "/tmp/sb_fit_prov.png")
                if pix_prov:
                    self["prov_logo"].instance.setPixmap(pix_prov)
                    self["prov_logo"].show()
                else:
                    self["prov_logo"].hide()

                pix_crypt = load_cached_card_pixmap(srv["crypt_logo_path"], "/tmp/sb_fit_crypt.png")
                if pix_crypt:
                    self["crypt_logo"].instance.setPixmap(pix_crypt)
                    self["crypt_logo"].show()
                else:
                    self["crypt_logo"].hide()

            if self.current_style in ["gx", "observatory"]:
                self.update_graph_tick()
        except Exception:
            pass

    def update_live_signals(self):
        """Ultra-lightweight real-time signal measurement tick (<0.2ms on main thread)."""
        try:
            self.tick_count += 1
            sig = self.engine.get_signal_data()
            self["snr_db"].setText(sig["snr_db_str"])
            self["snr_percent"].setText("{}%".format(sig["snr_percent"]))
            self["snr_progress"].setValue(sig["snr_percent"])

            self["agc_percent"].setText("{}%".format(sig["agc_percent"]))
            self["agc_progress"].setValue(sig["agc_percent"])

            # Dedicated GX Hardware Style Bars
            s_val = sig["snr_percent"]
            if sig["lock"] and s_val == 0:
                s_val = 100
            self["gx_s_percent"].setText("{}%".format(s_val))
            self["gx_s_progress"].setValue(s_val)

            if sig["lock"]:
                q_val = int(min(99, max(5, round((sig["snr_db"] / 17.0) * 100.0))))
            else:
                q_val = 0
            self["gx_q_percent"].setText("{}%".format(q_val))
            self["gx_q_progress"].setValue(q_val)

            self["ber_value"].setText("BER: {}".format(sig["ber"]))
            self["gx_snr_ber_line"].setText(sig["gx_snr_ber_line"])
            self["cn_ratio"].setText("C/N Ratio: {}".format(sig["snr_db_str"]))

            tp = self.cached_tp
            if not tp:
                tp = self.engine.get_transponder_data()
                self.cached_tp = tp

            sens = self.engine.get_sensitivity_metrics(
                tp["system"], tp["modulation"], tp["fec"], sig["snr_db"]
            )
            self["margin_badge"].setText(sens["margin_badge"])
            self["sensitivity_badge"].setText(sens["sens_badge"])
            self["stability_badge"].setText(sens["stab_badge"])

            if sig["lock"]:
                self["lock_badge"].setText(
                    "🔒 LOCKED ({}  ▪  {})".format(sig["quality_text"], sens["margin_str"])
                )
            else:
                self["lock_badge"].setText("❌ NO LOCK ({})".format(sig["quality_text"]))

            # Refresh live Softcam ECM/CW keys every 3 ticks (~1.2s)
            if self.tick_count % 3 == 0:
                srv = self.cached_srv or {"is_crypted": True, "first_caid": ""}
                sc = self.engine.get_softcam_data(srv.get("is_crypted", True), srv.get("first_caid", ""))
                self["cam_server_line"].setText(sc["cam_server_line"])
                self["cam_ecm_line"].setText(sc["cam_ecm_line"])
                self["cam_cw_line"].setText(sc["cam_cw_line"])

            self.beeper.update_snr(sig["snr_db"])

            now = datetime.now()
            self["clock_time"].setText(now.strftime("%d-%m-%Y   %H:%M:%S"))
        except Exception:
            pass

    def _render_graph_worker(self):
        """Background thread worker so oscilloscope rendering takes 0.0ms on Enigma2 GUI thread."""
        try:
            s_mode = config.plugins.SkyBlueSignal.spectrum_style.value or "fire_dual"
            gpath = self.engine.generate_oscilloscope(
                "/tmp/signal_oscilloscope.png",
                style_mode=s_mode
            )
            if gpath:
                self._graph_ready_path = gpath
        except Exception:
            pass
        finally:
            self._graph_busy = False

    def update_graph_tick(self):
        """Non-blocking oscilloscope tick."""
        if self.current_style not in ["gx", "observatory"]:
            return
        try:
            if self._graph_ready_path and os.path.exists(self._graph_ready_path):
                path_to_load = self._graph_ready_path
                self._graph_ready_path = ""
                pix = LoadPixmap(path_to_load, cached=False)
                if pix:
                    self["signal_graph"].instance.setPixmap(pix)

            if not self._graph_busy:
                self._graph_busy = True
                t = threading.Thread(target=self._render_graph_worker)
                t.daemon = True
                t.start()
        except Exception:
            self._graph_busy = False

    def key_open_settings_menu(self):
        """Opens the comprehensive Settings Menu (Hotkey capture, Quality Bar Color, Style Selector, Spectrum, Screenshot, Online Update)."""
        cur_key = config.plugins.SkyBlueSignal.keyname.value or "KEY_F1"
        cur_qcolor = config.plugins.SkyBlueSignal.quality_bar_color.value or "gold_emerald"
        cur_spec = config.plugins.SkyBlueSignal.spectrum_style.value or "fire_dual"
        spec_names = {
            "fire_dual": "🔥 الطيف المزدوج الناري والسماوي",
            "matrix_neon": "⚡ طيف الماتريكس السيبراني",
            "retro_led": "📊 طيف الـ LED الاحترافي",
            "aurora_cosmic": "🌌 طيف الشفق القطبي الكوني",
        }
        cur_spec_name = spec_names.get(cur_spec, cur_spec)
        choices = [
            (
                "1. 🎮 اختيار زر التشغيل المباشر من الريموت (الحالي: {})".format(cur_key),
                "hotkey",
            ),
            (
                "2. 🎨 تخصيص لون شريط الكوالتي (Quality Bar Color — الحالي: {})".format(cur_qcolor),
                "qcolor",
            ),
            (
                "3. 🖼 تغيير مظهر وستايل شاشة الإشارة (Skin Style Selector)",
                "style",
            ),
            (
                "4. 🌊 تغيير أشكال طيف الإشارة المتعددة (الحالي: {})".format(cur_spec_name),
                "spectrum",
            ),
            (
                "5. 📸 التقاط لقطة شاشة وحفظها (Take Screenshot)",
                "screenshot",
            ),
            (
                "6. 🌐 فحص وتحديث البلجن أونلاين (Online Update)",
                "online_update",
            ),
            (
                "7. ⏱ مؤقت الإغلاق التلقائي (Auto-Close Timeout)",
                "timeout",
            ),
        ]
        self.session.openWithCallback(
            self.on_settings_menu_selected,
            ChoiceBox,
            title="⚙️ إعدادات وتخصيص SkyBlue Signal Pro:",
            list=choices,
        )

    def on_settings_menu_selected(self, choice):
        if not choice:
            return
        action = choice[1]
        if action == "hotkey":
            self.key_capture_hotkey_direct()
        elif action == "qcolor":
            self.key_choose_quality_color()
        elif action == "style":
            self.key_choose_style()
        elif action == "spectrum":
            self.key_choose_spectrum()
        elif action == "screenshot":
            self.key_take_screenshot()
        elif action == "online_update":
            self.key_online_update()
        elif action == "timeout":
            self.key_choose_timeout()

    def key_cycle_spectrum(self):
        """Cycles to the next spectrum visualizer style on remote key 7."""
        styles = ["fire_dual", "matrix_neon", "retro_led", "aurora_cosmic"]
        cur = config.plugins.SkyBlueSignal.spectrum_style.value or "fire_dual"
        idx = styles.index(cur) if cur in styles else 0
        next_s = styles[(idx + 1) % len(styles)]
        config.plugins.SkyBlueSignal.spectrum_style.value = next_s
        config.plugins.SkyBlueSignal.spectrum_style.save()
        try:
            configfile.save()
        except Exception:
            pass
        self._graph_busy = False
        self.update_graph_tick()

    def key_choose_spectrum(self):
        """Opens Spectrum Visualizer Style selector dialog."""
        choices = [
            ("1. 🔥 الطيف المزدوج الناري والسماوي (Dual Fire & Laser Cyan)", "fire_dual"),
            ("2. ⚡ طيف الماتريكس السيبراني النيون (Cyber Matrix Laser Wave)", "matrix_neon"),
            ("3. 📊 طيف الـ LED الاحترافي (Retro 40-CH Broadcast Equalizer)", "retro_led"),
            ("4. 🌌 طيف الشفق القطبي الكوني (Cosmic Aurora Borealis)", "aurora_cosmic"),
        ]
        self.session.openWithCallback(
            self.on_spectrum_selected,
            ChoiceBox,
            title="🌊 اختر شكل وتأثير طيف الإشارة (Spectrum Visualizer):",
            list=choices,
        )

    def on_spectrum_selected(self, choice):
        if not choice:
            return
        config.plugins.SkyBlueSignal.spectrum_style.value = choice[1]
        config.plugins.SkyBlueSignal.spectrum_style.save()
        try:
            configfile.save()
        except Exception:
            pass
        self._graph_busy = False
        self.update_graph_tick()

    def key_take_screenshot(self):
        """Captures OSD and video to dedicated SkyBlueScreenshots folder on HDD/USB using grab."""
        try:
            dest_dir = get_screenshot_directory()
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = "SkyBlueSignal_{}.png".format(ts)
            shot_path = os.path.join(dest_dir, filename)

            # High-resolution capture: run grab in background thread BEFORE showing any toast
            # so the saved PNG is 100% clean, crisp and without any popup box!
            def _capture_worker():
                try:
                    # -d: full OSD resolution (1080p FHD matching screen geometry)
                    # -b: bicubic interpolation for maximum image quality
                    # -p: lossless 24/32-bit PNG
                    os.system("grab -d -b -p '{}' > /dev/null 2>&1".format(shot_path))
                except Exception:
                    pass
                try:
                    if os.path.exists(shot_path) and os.path.getsize(shot_path) > 1024:
                        # Open sleek SkyBlueScreenshotNotice only AFTER file is written to disk!
                        self.session.open(SkyBlueScreenshotNotice, shot_path, filename)
                except Exception:
                    pass

            t = threading.Thread(target=_capture_worker)
            t.daemon = True
            t.start()
        except Exception:
            pass

    def key_online_update(self):
        """Checks and performs online update of SkyBlue Signal Pro."""
        self.session.openWithCallback(
            self.on_confirm_online_update,
            MessageBox,
            "🌐 هل تريد فحص وتثبيت آخر تحديث لبلجن SkyBlue Signal Pro عبر الإنترنت؟",
            MessageBox.TYPE_YESNO,
        )

    def on_confirm_online_update(self, confirmed):
        if not confirmed:
            return
        url = config.plugins.SkyBlueSignal.update_url.value or "https://raw.githubusercontent.com/SkyBlueTeam/SkyBlueSignal/main/SkyBlueSignal.tar.gz"
        tar_dst = "/tmp/SkyBlueSignal.tar.gz"

        def _do_update():
            try:
                import urllib.request
                req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Enigma2; SkyBlueSignal)"})
                with urllib.request.urlopen(req, timeout=15) as resp:
                    with open(tar_dst, "wb") as f:
                        f.write(resp.read())

                if os.path.exists(tar_dst) and os.path.getsize(tar_dst) > 1024:
                    rc = os.system("tar -xzf /tmp/SkyBlueSignal.tar.gz -C /usr/lib/enigma2/python/Plugins/Extensions/")
                    if rc == 0:
                        return True, "✅ تم تثبيت أحدث إصدار بنجاح! يرجى إعادة تشغيل واجهة الجهاز (Restart GUI) لتطبيق التحديث."
                    else:
                        return False, "❌ حدث خطأ أثناء فك حزمة التحديث (Error extracting archive)."
                else:
                    return False, "❌ تعذر تحميل ملف التحديث من الرابط المحدد."
            except Exception as e:
                if os.path.exists(tar_dst) and os.path.getsize(tar_dst) > 1024:
                    rc = os.system("tar -xzf /tmp/SkyBlueSignal.tar.gz -C /usr/lib/enigma2/python/Plugins/Extensions/")
                    if rc == 0:
                        return True, "✅ تم تثبيت التحديث من الملف المحلي /tmp/SkyBlueSignal.tar.gz بنجاح!"
                return False, "⚠️ تعذر الاتصال بسيرفر التحديث:\n{}\n\nيمكنك التحديث يدوياً عبر أمر التيلنت المباشر.".format(str(e))

        def _update_finished(result):
            success, msg = result
            if success:
                self.session.openWithCallback(
                    self._restart_gui_callback,
                    MessageBox,
                    msg + "\n\nهل تريد إعادة تشغيل واجهة الجهاز (Restart GUI) الآن؟",
                    MessageBox.TYPE_YESNO,
                )
            else:
                self.session.open(MessageBox, msg, MessageBox.TYPE_ERROR, timeout=6)

        t = threading.Thread(target=lambda: _update_finished(_do_update()))
        t.daemon = True
        t.start()

    def _restart_gui_callback(self, confirmed):
        if confirmed:
            try:
                from Screens.Standby import TryQuitMainloop
                self.session.open(TryQuitMainloop, 3)
            except Exception:
                os.system("killall -9 enigma2")

    def key_capture_hotkey_direct(self):
        """Opens RaedQuickSignal-style KeyCaptureScreen to capture any remote button."""
        self.session.openWithCallback(self.on_hotkey_captured, KeyCaptureScreen)

    def on_hotkey_captured(self, keyname=None):
        """Saves and activates the newly captured remote control hotkey immediately."""
        if not keyname:
            return
        try:
            config.plugins.SkyBlueSignal.keyname.value = keyname
            config.plugins.SkyBlueSignal.keyname.save()
            configfile.save()
            pSkyBlueHotkey.bind_keymap(keyname)
            self.session.open(
                MessageBox,
                "✅ تم تخصيص الزر [ {} ] لتشغيل SkyBlue Signal Pro مباشرة من الريموت!".format(keyname),
                MessageBox.TYPE_INFO,
                timeout=4,
            )
        except Exception:
            pass

    def key_choose_quality_color(self):
        """Opens Quality Bar 3D Crystal Color Theme selector."""
        choices = [
            ("1. 🌟 الذهبي والزمردي المشع (Solar Gold & Neon Emerald - الافتراضي المميز)", "gold_emerald"),
            ("2. 💎 الكريستال السماوي والأزرق الملكي (Cyber Ice & Sapphire)", "cyber_ice"),
            ("3. 🔥 الطيف الناري المتوهج (Volcanic Fire & Supernova Gold)", "lava_fire"),
            ("4. 🔮 طيف الجواهر البنفسجي والوردي (Aurora Amethyst & Rose)", "aurora_jewel"),
        ]
        self.session.openWithCallback(
            self.on_quality_color_selected,
            ChoiceBox,
            title="🎨 اختر لون شريط الكوالتي (SNR Quality Bar Color):",
            list=choices,
        )

    def on_quality_color_selected(self, choice):
        if not choice:
            return
        qcolor = choice[1]
        config.plugins.SkyBlueSignal.quality_bar_color.value = qcolor
        config.plugins.SkyBlueSignal.quality_bar_color.save()
        try:
            configfile.save()
        except Exception:
            pass
        self.apply_quality_bar_color()
        self.update_live_signals()

    def key_choose_timeout(self):
        """Opens Auto-Close Timeout selector."""
        choices = [
            ("1. دائم (لا يغلق إلا بالضغط على Exit)", "0"),
            ("2. إغلاق تلقائي بعد 5 ثوانٍ", "5"),
            ("3. إغلاق تلقائي بعد 10 ثوانٍ", "10"),
            ("4. إغلاق تلقائي بعد 15 ثانية", "15"),
        ]
        self.session.openWithCallback(
            self.on_timeout_selected,
            ChoiceBox,
            title="⏱ اختر مؤقت الإغلاق التلقائي:",
            list=choices,
        )

    def on_timeout_selected(self, choice):
        if not choice:
            return
        config.plugins.SkyBlueSignal.timeout.value = choice[1]
        config.plugins.SkyBlueSignal.timeout.save()
        try:
            configfile.save()
        except Exception:
            pass

    def key_choose_style(self):
        """Opens interactive Style Chooser dialog."""
        choices = [
            ("1. 👑 Pro Observatory Black (المرصد الأسود الملكي - الافتراضي)", "observatory"),
            ("2. 💎 GX Classic Elite (ستايل أجهزة GX الأسطوري - شريط أحمر وذهبي)", "gx"),
            ("3. ⚡ Cyber Neon HUD (السيبراني الداكن عالي التباين)", "cyber"),
            ("4. 🎯 Ultra Slim Sports HUD (شريط الاستاد السفلي الخفيف للمباريات)", "slim"),
        ]
        self.session.openWithCallback(
            self.on_style_selected,
            ChoiceBox,
            title="🎨 اختر مظهر شاشة الإشارة (SkyBlue Signal Style):",
            list=choices,
        )

    def on_style_selected(self, choice):
        """Applies and switches to the selected style instantly."""
        if not choice:
            return
        style_key = choice[1]
        self.switch_to_style(style_key, save_now=True)

    def switch_to_style(self, style_key, save_now=False):
        """
        Crash-free, zero-spinner style switching!
        Uses _REOPEN_TIMER (25ms) so StartEnigma completes self.close() & processDelay()
        before opening the new modal SkyBlueSignalScreen.
        """
        config.plugins.SkyBlueSignal.style.value = style_key
        config.plugins.SkyBlueSignal.style_black_default.value = style_key
        config.plugins.SkyBlueSignal.style.save()
        config.plugins.SkyBlueSignal.style_black_default.save()
        if save_now:
            try:
                configfile.save()
            except Exception:
                pass

        self._stop_timers()
        _PENDING_REOPEN["session"] = self.session
        _PENDING_REOPEN["style"] = style_key
        self.close()
        _REOPEN_TIMER.start(25, True)

    def key_cycle_style_next(self):
        """Cycles to the next style using remote DOWN arrow without modal crash or flash I/O lag."""
        styles = ["observatory", "gx", "cyber", "slim"]
        cur = self.current_style
        idx = styles.index(cur) if cur in styles else 0
        next_style = styles[(idx + 1) % len(styles)]
        self.switch_to_style(next_style, save_now=False)

    def key_cycle_style_prev(self):
        """Cycles to the previous style using remote UP arrow without modal crash or flash I/O lag."""
        styles = ["observatory", "gx", "cyber", "slim"]
        cur = self.current_style
        idx = styles.index(cur) if cur in styles else 0
        prev_style = styles[(idx - 1) % len(styles)]
        self.switch_to_style(prev_style, save_now=False)

    def key_toggle_beeper(self):
        """Toggles dish alignment audio tone ON / OFF."""
        if self.beeper.enabled:
            self.beeper.stop()
            self["key_yellow"].setText("Tone (OFF)")
            self["beeper_status"].setText("🔇 Audio Tone: OFF")
        else:
            self.beeper.start()
            self["key_yellow"].setText("Tone (ON)")
            self["beeper_status"].setText("🔊 Audio Tone: ACTIVE (Beeping)")

    def key_satfinder(self):
        """Opens Enigma2 native Satfinder."""
        try:
            from Plugins.SystemPlugins.Satfinder.plugin import Satfinder
            self.session.open(Satfinder)
        except Exception:
            try:
                from Screens.Satfinder import Satfinder
                self.session.open(Satfinder)
            except Exception:
                pass

    def key_positioner(self):
        """Opens Enigma2 native Positioner Setup for rotor motors."""
        try:
            from Screens.PositionerSetup import PositionerSetup
            self.session.open(PositionerSetup)
        except Exception:
            pass

    def key_zap_next(self):
        """Zaps to next channel directly from signal meter using InfoBar with instant turbo lock."""
        try:
            from Screens.InfoBar import InfoBar
            ib = getattr(InfoBar, "instance", None)
            if ib and hasattr(ib, "zapDown"):
                ib.zapDown()
            elif ib and hasattr(ib, "servicelist") and ib.servicelist:
                ib.servicelist.moveDown()
                ib.servicelist.zap()
            else:
                self.session.nav.playNextService()
            self._on_channel_zap_triggered()
        except Exception:
            pass

    def key_zap_prev(self):
        """Zaps to previous channel directly from signal meter using InfoBar with instant turbo lock."""
        try:
            from Screens.InfoBar import InfoBar
            ib = getattr(InfoBar, "instance", None)
            if ib and hasattr(ib, "zapUp"):
                ib.zapUp()
            elif ib and hasattr(ib, "servicelist") and ib.servicelist:
                ib.servicelist.moveUp()
                ib.servicelist.zap()
            else:
                self.session.nav.playPrevService()
            self._on_channel_zap_triggered()
        except Exception:
            pass

    def _on_channel_zap_triggered(self):
        """Instant UI pre-fetch & triggers 50ms turbo tuner poller for lightning-fast signal lock."""
        self.cached_tp = None
        self.cached_srv = None
        self._zap_turbo_count = 0

        # Pre-fetch channel name & number immediately in 0ms from servicelist
        try:
            from Screens.InfoBar import InfoBar
            ib = getattr(InfoBar, "instance", None)
            if ib and hasattr(ib, "servicelist") and ib.servicelist:
                cur_ref = ib.servicelist.getCurrentSelection()
                if cur_ref:
                    from enigma import eServiceCenter
                    s_info = eServiceCenter.getInstance().info(cur_ref)
                    if s_info:
                        ch_name = s_info.getName(cur_ref) or ""
                        if ch_name:
                            self["channel_name"].setText(ch_name)
        except Exception:
            pass

        self["lock_badge"].setText("⚡ جارٍ التقاط الإشارة...")

        if self.zap_turbo_timer.isActive():
            self.zap_turbo_timer.stop()
        self.zap_turbo_timer.start(50, False)

    def on_zap_turbo_tick(self):
        """50ms burst tick: detects hardware tuner lock in <100ms and immediately updates display."""
        self._zap_turbo_count += 1
        try:
            sig = self.engine.get_signal_data()
            is_locked = sig.get("lock", False)
            snr_db = sig.get("snr_db", 0.0)

            # If tuner locked, or has signal > 1.0dB, or reached 16 ticks (~800ms)
            if is_locked or snr_db > 1.0 or self._zap_turbo_count >= 16:
                self.zap_turbo_timer.stop()
                self.load_static_metadata()
            else:
                # Still tuning: update gauges in real-time
                self.update_live_signals()
        except Exception:
            if self._zap_turbo_count >= 16:
                self.zap_turbo_timer.stop()
                self.load_static_metadata()

    def key_exit(self):
        """Saves style preference if changed and closes screen cleanly."""
        try:
            config.plugins.SkyBlueSignal.style.save()
            config.plugins.SkyBlueSignal.style_black_default.save()
        except Exception:
            pass
        self.close()

    def _stop_timers(self):
        """Stops all active timers immediately."""
        try:
            for t in (
                self.refresh_timer,
                self.graph_timer,
                self.init_defer_timer,
                self.zap_timer,
                self.zap_turbo_timer,
                self.timeout_timer,
            ):
                if t.isActive():
                    t.stop()
            self.beeper.stop()
        except Exception:
            pass

    def on_screen_close(self):
        """Cleanup timers and background processes."""
        self._stop_timers()


def sessionstart(reason, session=None, **kwargs):
    """Registers global direct remote hotkey when Enigma2 starts."""
    if reason == 0 and session is not None:
        pSkyBlueHotkey.gotSession(session)


def main(session, **kwargs):
    """Entry point when triggered from Extensions or Plugin Menu."""
    session.open(SkyBlueSignalScreen)


def menu_callback(menuid, **kwargs):
    """Controls where the plugin appears in setup menus (Enigma2 Main Menu)."""
    if menuid == "mainmenu":
        return [("👑 SkyBlue Signal Pro", main, "skyblue_signal", 2)]
    return []


def Plugins(**kwargs):
    """Enigma2 Plugin Descriptors registering SessionStart Hotkey, Menus & Channel Context."""
    return [
        PluginDescriptor(
            where=[PluginDescriptor.WHERE_SESSIONSTART],
            fnc=sessionstart,
        ),
        PluginDescriptor(
            name="👑 SkyBlue Signal Pro",
            description="Next-Gen Satellite Signal Cockpit (Pure Black OLED, Hotkey & Softcam)",
            where=[
                PluginDescriptor.WHERE_PLUGINMENU,
                PluginDescriptor.WHERE_EXTENSIONSMENU,
            ],
            icon="plugin.png",
            fnc=main,
        ),
        PluginDescriptor(
            name="👑 SkyBlue Signal Pro",
            description="Next-Gen Satellite Signal Cockpit (Pure Black OLED, Hotkey & Softcam)",
            where=PluginDescriptor.WHERE_MENU,
            fnc=menu_callback,
        ),
        PluginDescriptor(
            name="👑 SkyBlue Signal Pro",
            description="Next-Gen Satellite Signal Cockpit (Pure Black OLED, Hotkey & Softcam)",
            where=PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU,
            fnc=main,
        ),
    ]
