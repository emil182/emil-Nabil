# -*- coding: utf-8 -*-
# Obsidian FHD Apps: one entry in the main menu ("Obsidian Apps"). A grid of "apps" (weather, bitrate, menu style,
# channel list style, infobar style, About & update, clock); each opens its own page with a preview, details and a Turn on / off
# button or a style choice.
# Apps only write flag files in /etc/enigma2 that the skin reads at start-up (a GUI restart applies them). While the
# panel is open it also checks GitHub for a newer release (see ObsidianSysInfo.UpdateCheck) and can install it.
# Exception: the optional Permanent clock app (clock.py) keeps a small on-screen window while TV plays; it starts
# only when the user turns it on and stops on any error.
from os import remove
from os.path import exists

from Plugins.Plugin import PluginDescriptor

# Python's own HTTPS client, the last download fallback (the Apps catalogue already reads GitHub this way)
PY_FETCH = 'import sys;u=sys.version_info[0]>2 and __import__("urllib.request").request or __import__("urllib2");d=u.urlopen(sys.argv[1],timeout=30).read();open(sys.argv[2],"wb").write(d)'


def fetchShell(url, target, seconds, log):
	# Shell for one download: wget, then curl (OpenPLi's wget can drop GitHub's HTTPS connection), then Python.
	# Every failure goes to the log, so an error message can show the real reason.
	return ('{ wget -T 30 -t 1 -O %(t)s %(u)s || { echo "wget failed: $?"; curl -fsSL --connect-timeout 15 --max-time %(s)d -o %(t)s %(u)s; } || '
		'{ echo "curl failed: $?"; python3 -c \'%(p)s\' %(u)s %(t)s; } || { echo "python3 failed: $?"; python -c \'%(p)s\' %(u)s %(t)s; } || echo "python failed: $?"; } >> %(l)s 2>&1'
		) % {"u": url, "t": target, "s": seconds, "l": log, "p": PY_FETCH}


INSTALL_CMD = ("u=https://raw.githubusercontent.com/dali44g/Obsidian-FHD/main/install.sh; f=/tmp/obsidian-install.sh; l=/tmp/obsidian-install.log; rm -f $f; : > $l; "
	+ fetchShell("$u", "$f", 60, "$l") +
	"; if [ -s $f ]; then sh $f; else echo 'Download failed:'; tail -n 6 $l; fi; rm -f $f")
NO_WEATHER = "/etc/enigma2/obsidian_noweather"
MENU_FLOATING = "/etc/enigma2/obsidian_menu_floating"
MENU_EDGE = "/etc/enigma2/obsidian_menu_edge"
NO_BITRATE = "/etc/enigma2/obsidian_nobitrate"
NO_INFOBAR_CLOCK = "/etc/enigma2/obsidian_noclock"
CHLIST_FLOATING = "/etc/enigma2/obsidian_chlist_floating"
CHLIST_EDGE = "/etc/enigma2/obsidian_chlist_edge"
INFOBAR_GLASS = "/etc/enigma2/obsidian_infobar_glass"
INFOBAR_NOVA = "/etc/enigma2/obsidian_infobar_nova"
MENU_NOVA = "/etc/enigma2/obsidian_menu_nova"
CHLIST_NOVA = "/etc/enigma2/obsidian_chlist_nova"
MENU_K7 = "/etc/enigma2/obsidian_menu_k7"
CHLIST_K7 = "/etc/enigma2/obsidian_chlist_k7"
INFOBAR_K7 = "/etc/enigma2/obsidian_infobar_k7"
MENU_SYNTHWAVE = "/etc/enigma2/obsidian_menu_synthwave"
CHLIST_SYNTHWAVE = "/etc/enigma2/obsidian_chlist_synthwave"
INFOBAR_SYNTHWAVE = "/etc/enigma2/obsidian_infobar_synthwave"
MENU_MATCHDAY = "/etc/enigma2/obsidian_menu_matchday"
CHLIST_MATCHDAY = "/etc/enigma2/obsidian_chlist_matchday"
INFOBAR_MATCHDAY = "/etc/enigma2/obsidian_infobar_matchday"
NOVA_OBSIDIAN = "/etc/enigma2/obsidian_nova_obsidian"  # Nova pack in Obsidian colours instead of purple
CONVERTERS = "/usr/lib/enigma2/python/Components/Converter/"
SKIN_DIR = "/usr/share/enigma2/Obsidian-FHD/"
# Style packs: separate packages installed from Obsidian Apps (Classic and Floating are built in).
# A pack is "full look": choosing it sets every screen it covers; leaving it on one screen leaves it everywhere.
PACKS = {
	"edge": {"name": "Edge", "package": "enigma2-plugin-skins-obsidian-fhd-edge", "size": "0.3 MB",
		"files": [SKIN_DIR + "skin_menu_edge.xml", SKIN_DIR + "skin_setup_edge.xml", SKIN_DIR + "skin_chlist_edge.xml"]},
	"nova": {"name": "Nova", "package": "enigma2-plugin-skins-obsidian-fhd-nova", "size": "0.3 MB",
		"files": [SKIN_DIR + "skin_chlist_nova.xml", SKIN_DIR + "skin_infobar_nova.xml"]},
	"k7": {"name": "K7", "package": "enigma2-plugin-skins-obsidian-fhd-k7", "size": "0.4 MB",
		"files": [SKIN_DIR + "skin_k7_base.xml", SKIN_DIR + "skin_k7_palette.xml", SKIN_DIR + "skin_menu_k7.xml",
			SKIN_DIR + "skin_chlist_k7.xml", SKIN_DIR + "skin_infobar_k7.xml"]},
	"synthwave": {"name": "Synthwave", "package": "enigma2-plugin-skins-obsidian-fhd-synthwave", "size": "0.4 MB",
		"files": [SKIN_DIR + "skin_menu_synthwave.xml", SKIN_DIR + "skin_setup_synthwave.xml", SKIN_DIR + "skin_chlist_synthwave.xml",
			SKIN_DIR + "skin_infobar_synthwave.xml"]},
	"matchday": {"name": "Matchday", "package": "enigma2-plugin-skins-obsidian-fhd-matchday", "size": "0.2 MB",
		"files": [SKIN_DIR + "skin_matchday_base.xml", SKIN_DIR + "skin_menu_matchday.xml", SKIN_DIR + "skin_setup_matchday.xml",
			SKIN_DIR + "skin_chlist_matchday.xml", SKIN_DIR + "skin_infobar_matchday.xml"]},
}
# Latest GitHub Release asset first (download counted), then the copy in the repository.
PACK_URLS = ("https://github.com/dali44g/Obsidian-FHD/releases/latest/download/%s_all.ipk",
	"https://raw.githubusercontent.com/dali44g/Obsidian-FHD/main/release/%s_all.ipk")
# Downloadable apps: separate packages with their own versions, listed in the catalogue apps.json (latest GitHub
# Release asset first, then the repository copy). A download is installed only when its size and sha256 match the
# catalogue; without the catalogue nothing is installed.
CATALOGUE_URLS = ("https://github.com/dali44g/Obsidian-FHD/releases/latest/download/apps.json",
	"https://raw.githubusercontent.com/dali44g/Obsidian-FHD/main/release/apps.json")
APP_RELEASE_URLS = ("https://github.com/dali44g/Obsidian-FHD/releases/latest/download/%s",
	"https://raw.githubusercontent.com/dali44g/Obsidian-FHD/main/release/%s")


def testSource(path="/etc/enigma2/obsidian-test-server"):
	# Testing a pre-release on a receiver: this file (absent for users) names where downloads are tried first,
	# "github:<tag>" (e.g. github:v1.6.0-rc1, a GitHub pre-release) or "http://<pc>:8000/" (a local server).
	try:
		with open(path) as f:
			value = f.read().strip()
	except Exception:
		return None
	if value.startswith("github:") and value[7:].replace(".", "").replace("-", "").isalnum():
		return "https://github.com/dali44g/Obsidian-FHD/releases/download/%s/" % value[7:]
	if (value.startswith("http://") or value.startswith("https://")) and " " not in value and '"' not in value:
		return value.rstrip("/") + "/"
	return None


_test = testSource()
if _test:
	PACK_URLS = (_test + "%s_all.ipk",) + PACK_URLS
	CATALOGUE_URLS = (_test + "apps.json",) + CATALOGUE_URLS
	APP_RELEASE_URLS = (_test + "%s",) + APP_RELEASE_URLS
APP_PACKAGES = {
	"mawaqit": {"name": "Mawaqit", "package": "enigma2-plugin-extensions-obsidian-mawaqit",
		"plugin": "/usr/lib/enigma2/python/Plugins/Extensions/ObsidianMawaqit/", "module": "Plugins.Extensions.ObsidianMawaqit.screens"},
	"posters": {"name": "Posters", "package": "enigma2-plugin-extensions-obsidian-posters",
		"plugin": "/usr/lib/enigma2/python/Plugins/Extensions/ObsidianPosters/", "module": "Plugins.Extensions.ObsidianPosters.screens"},
	"cast": {"name": "Cast", "package": "enigma2-plugin-extensions-obsidian-cast",
		"plugin": "/usr/lib/enigma2/python/Plugins/Extensions/ObsidianCast/", "module": "Plugins.Extensions.ObsidianCast.screens"},
}


# French / Arabic texts of the Apps panel, keyed by the English text ("key|page" = page variant). ASCII escapes only.
TRANSLATIONS = {
	# Look page
	'MENUS': (u'MENUS', u'\u0627\u0644\u0642\u0627\u0626\u0645\u0629'),
	'CHANNELS': (u'CHA\xceNES', u'\u0627\u0644\u0642\u0646\u0648\u0627\u062a'),
	'INFOBAR': (u'BARRE D\'INFOS', u'\u0634\u0631\u064a\u0637 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a'),
	# Look page
	'Infobar. Nova comes with the Nova style pack; its colours apply to every Nova screen.': (u'Barre d\'infos. Nova est fournie avec le pack de style Nova ; ses couleurs s\'appliquent \xe0 tous les \xe9crans Nova.', u'\u0634\u0631\u064a\u0637 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a. \u064a\u0623\u062a\u064a Nova \u0645\u0639 \u062d\u0632\u0645\u0629 \u0646\u0645\u0637 Nova\u060c \u0648\u062a\u064f\u0637\u0628\u064e\u0651\u0642 \u0623\u0644\u0648\u0627\u0646\u0647 \u0639\u0644\u0649 \u062c\u0645\u064a\u0639 \u0634\u0627\u0634\u0627\u062a Nova.'),
	# Look page
	'Custom': (u'Personnalis\xe9', u'\u0645\u062e\u0635\u0651\u0635'),
	'Neon 80s arcade': (u'Arcade n\xe9on ann\xe9es 80', u'\u0623\u0631\u0643\u064a\u062f \u0646\u064a\u0648\u0646 \u0627\u0644\u062b\u0645\u0627\u0646\u064a\u0646\u0627\u062a'),
	'Nova Purple': (u'Nova violet', u'Nova \u0628\u0646\u0641\u0633\u062c\u064a'),
	'Nova Obsidian': (u'Nova Obsidian', u'Nova \u0623\u0648\u0628\u0633\u064a\u062f\u064a\u0627\u0646'),
	'Saved': (u'Enregistr\xe9', u'\u0645\u062d\u0641\u0648\u0638'),
	'Sets menus, channel list and infobar together.': (u'R\xe8gle ensemble les menus, la liste des cha\xeenes et la barre d\'infos.', u'\u064a\u0636\u0628\u0637 \u0627\u0644\u0642\u0648\u0627\u0626\u0645 \u0648\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0642\u0646\u0648\u0627\u062a \u0648\u0634\u0631\u064a\u0637 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0645\u0639\u0627\u064b.'),
	'Save downloads the %s style pack (%s) first.': (u'L\'enregistrement t\xe9l\xe9charge d\'abord le pack de style %s (%s).', u'\u0627\u0644\u062d\u0641\u0638 \u064a\u062d\u0645\u0651\u0644 \u0623\u0648\u0644\u0627\u064b \u062d\u0632\u0645\u0629 \u0627\u0644\u0646\u0645\u0637 %s (%s).'),
	'Not saved yet. GREEN saves, then the GUI restarts to apply.': (u'Pas encore enregistr\xe9. VERT enregistre, puis l\'interface red\xe9marre pour appliquer.', u'\u0644\u0645 \u064a\u064f\u062d\u0641\u0638 \u0628\u0639\u062f. \u0627\u0644\u0623\u062e\u0636\u0631 \u064a\u062d\u0641\u0638 \u062b\u0645 \u062a\u064f\u0639\u0627\u062f \u0627\u0644\u0648\u0627\u062c\u0647\u0629 \u0644\u062a\u0637\u0628\u064a\u0642 \u0627\u0644\u062a\u063a\u064a\u064a\u0631\u0627\u062a.'),
	'LEFT / RIGHT changes a setting, GREEN saves.': (u'GAUCHE / DROITE change un r\xe9glage, VERT enregistre.', u'\u064a\u0633\u0627\u0631 / \u064a\u0645\u064a\u0646 \u064a\u063a\u064a\u0651\u0631 \u0627\u0644\u0625\u0639\u062f\u0627\u062f\u060c \u0648\u0627\u0644\u0623\u062e\u0636\u0631 \u064a\u062d\u0641\u0638.'),
	'Download the style pack %s and save?': (u'T\xe9l\xe9charger le pack de style %s et enregistrer ?', u'\u062a\u062d\u0645\u064a\u0644 \u062d\u0632\u0645\u0629 \u0627\u0644\u0646\u0645\u0637 %s \u0648\u0627\u0644\u062d\u0641\u0638\u061f'),
	'Leave without saving the changes?': (u'Quitter sans enregistrer les changements ?', u'\u0627\u0644\u062e\u0631\u0648\u062c \u062f\u0648\u0646 \u062d\u0641\u0638 \u0627\u0644\u062a\u063a\u064a\u064a\u0631\u0627\u062a\u061f'),
	# Look page
	'Customise style, colours, menus, channel list and infobar on one page.': (u'Personnalisez le style, les couleurs, les menus, la liste des cha\xeenes et la barre d\'infos sur une seule page.', u'\u062e\u0635\u0651\u0635 \u0627\u0644\u0646\u0645\u0637 \u0648\u0627\u0644\u0623\u0644\u0648\u0627\u0646 \u0648\u0627\u0644\u0642\u0648\u0627\u0626\u0645 \u0648\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0642\u0646\u0648\u0627\u062a \u0648\u0634\u0631\u064a\u0637 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0641\u064a \u0635\u0641\u062d\u0629 \u0648\u0627\u062d\u062f\u0629.'),
	'Customise': (u'Personnaliser', u'\u062a\u062e\u0635\u064a\u0635'),
	'Style cards': (u'Cartes de style', u'\u0628\u0637\u0627\u0642\u0627\u062a \u0627\u0644\u0623\u0646\u0645\u0627\u0637'),
	'Classic, Floating, Edge or Nova': (u'Classic, Floating, Edge ou Nova', u'Classic \u0623\u0648 Floating \u0623\u0648 Edge \u0623\u0648 Nova'),
	# Look page
	'Look': (u'Apparence', u'\u0627\u0644\u0645\u0638\u0647\u0631'),
	'Choose': (u'Choisir', u'\u0627\u062e\u062a\u064a\u0627\u0631'),
	'Open': (u'Ouvrir', u'\u0641\u062a\u062d'),
	'Style, menus, channel list and infobar on one page.': (u'Style, menus, liste des cha\xeenes et barre d\'infos sur une seule page.', u'\u0627\u0644\u0646\u0645\u0637 \u0648\u0627\u0644\u0642\u0648\u0627\u0626\u0645 \u0648\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0642\u0646\u0648\u0627\u062a \u0648\u0634\u0631\u064a\u0637 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0641\u064a \u0635\u0641\u062d\u0629 \u0648\u0627\u062d\u062f\u0629.'),
	'Style, colours and infobar': (u'Style, couleurs et barre d\'infos', u'\u0627\u0644\u0646\u0645\u0637 \u0648\u0627\u0644\u0623\u0644\u0648\u0627\u0646 \u0648\u0634\u0631\u064a\u0637 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a'),
	'Colours': (u'Couleurs', u'\u0627\u0644\u0623\u0644\u0648\u0627\u0646'),
	'Infobar': (u'Barre d\'infos', u'\u0634\u0631\u064a\u0637 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a'),
	'Mixed': (u'Mixte', u'\u0645\u062e\u062a\u0644\u0637'),
	'Purple': (u'Violet', u'\u0628\u0646\u0641\u0633\u062c\u064a'),
	'Obsidian': (u'Obsidian', u'\u0623\u0648\u0628\u0633\u064a\u062f\u064a\u0627\u0646'),
	'In use: %s': (u'Utilis\xe9 : %s', u'\u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645: %s'),
	'SETTINGS': (u'R\xc9GLAGES', u'\u0627\u0644\u0625\u0639\u062f\u0627\u062f\u0627\u062a'),
	'Please wait': (u'Veuillez patienter', u'\u064a\u0631\u062c\u0649 \u0627\u0644\u0627\u0646\u062a\u0638\u0627\u0631'),
	'Sets menus, settings pages and channel list together. A style pack also sets its infobar.': (u'R\xe8gle ensemble les menus, les pages de r\xe9glages et la liste des cha\xeenes. Un pack de style r\xe8gle aussi sa barre d\'infos.', u'\u064a\u0636\u0628\u0637 \u0627\u0644\u0642\u0648\u0627\u0626\u0645 \u0648\u0635\u0641\u062d\u0627\u062a \u0627\u0644\u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0648\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0642\u0646\u0648\u0627\u062a \u0645\u0639\u0627\u064b. \u062d\u0632\u0645\u0629 \u0627\u0644\u0646\u0645\u0637 \u062a\u0636\u0628\u0637 \u0623\u064a\u0636\u0627\u064b \u0634\u0631\u064a\u0637 \u0645\u0639\u0644\u0648\u0645\u0627\u062a\u0647\u0627.'),
	'Colours of every Nova screen.': (u'Couleurs de tous les \xe9crans Nova.', u'\u0623\u0644\u0648\u0627\u0646 \u062c\u0645\u064a\u0639 \u0634\u0627\u0634\u0627\u062a Nova.'),
	'Menus and settings pages.': (u'Menus et pages de r\xe9glages.', u'\u0627\u0644\u0642\u0648\u0627\u0626\u0645 \u0648\u0635\u0641\u062d\u0627\u062a \u0627\u0644\u0625\u0639\u062f\u0627\u062f\u0627\u062a.'),
	'Channel list.': (u'Liste des cha\xeenes.', u'\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0642\u0646\u0648\u0627\u062a.'),
	'Infobar. Nova comes with the Nova style pack.': (u'Barre d\'infos. Nova est fournie avec le pack de style Nova.', u'\u0634\u0631\u064a\u0637 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a. \u064a\u0623\u062a\u064a Nova \u0645\u0639 \u062d\u0632\u0645\u0629 \u0646\u0645\u0637 Nova.'),
	'%s is a style pack (%s): downloaded once, then it applies to all its screens.': (u'%s est un pack de style (%s) : t\xe9l\xe9charg\xe9 une fois, il s\'applique ensuite \xe0 tous ses \xe9crans.', u'%s \u062d\u0632\u0645\u0629 \u0646\u0645\u0637 (%s): \u062a\u064f\u062d\u0645\u064e\u0651\u0644 \u0645\u0631\u0629 \u0648\u0627\u062d\u062f\u0629 \u062b\u0645 \u062a\u064f\u0637\u0628\u064e\u0651\u0642 \u0639\u0644\u0649 \u062c\u0645\u064a\u0639 \u0634\u0627\u0634\u0627\u062a\u0647\u0627.'),
	'LEFT / RIGHT shows a value, GREEN applies it. Changes apply after a GUI restart.': (u'GAUCHE / DROITE affiche une valeur, VERT l\'applique. Les changements s\'appliquent apr\xe8s un red\xe9marrage de l\'interface.', u'\u064a\u0633\u0627\u0631 / \u064a\u0645\u064a\u0646 \u064a\u0639\u0631\u0636 \u0642\u064a\u0645\u0629\u060c \u0648\u0627\u0644\u0623\u062e\u0636\u0631 \u064a\u0637\u0628\u0651\u0642\u0647\u0627. \u062a\u064f\u0637\u0628\u064e\u0651\u0642 \u0627\u0644\u062a\u063a\u064a\u064a\u0631\u0627\u062a \u0628\u0639\u062f \u0625\u0639\u0627\u062f\u0629 \u062a\u0634\u063a\u064a\u0644 \u0627\u0644\u0648\u0627\u062c\u0647\u0629.'),
	'Settings': (u'R\xe9glages', u'\u0627\u0644\u0625\u0639\u062f\u0627\u062f\u0627\u062a'),
	'Open app': (u'Ouvrir', u'\u0641\u062a\u062d'),
	'Close': (u'Fermer', u'\u0625\u063a\u0644\u0627\u0642'),
	'Turn on / off': (u'Activer / d\xe9sactiver', u'\u062a\u0641\u0639\u064a\u0644 / \u062a\u0639\u0637\u064a\u0644'),
	'Back to apps': (u'Retour aux applications', u'\u0631\u062c\u0648\u0639 \u0625\u0644\u0649 \u0627\u0644\u062a\u0637\u0628\u064a\u0642\u0627\u062a'),
	'Scroll': (u'D\xe9filer', u'\u062a\u0645\u0631\u064a\u0631'),
	'Back': (u'Retour', u'\u0631\u062c\u0648\u0639'),
	'Obsidian Apps': (u'Obsidian Apps', u'\u062a\u0637\u0628\u064a\u0642\u0627\u062a Obsidian'),
	'PREVIEW': (u'APER\u00c7U', u'\u0645\u0639\u0627\u064a\u0646\u0629'),
	'DETAILS': (u'D\u00c9TAILS', u'\u0627\u0644\u062a\u0641\u0627\u0635\u064a\u0644'),
	'Apps': (u'Applications', u'\u0627\u0644\u062a\u0637\u0628\u064a\u0642\u0627\u062a'),
	'APPS': (u'APPLICATIONS', u'\u0627\u0644\u062a\u0637\u0628\u064a\u0642\u0627\u062a'),
	'%d on  -  %d off': (u'%d actives  -  %d inactives', u'%d \u0645\u0641\u0639\u0651\u0644  -  %d \u0645\u0639\u0637\u0651\u0644'),
	'ON': (u'ACTIF', u'\u0645\u0641\u0639\u0651\u0644'),
	'OFF': (u'INACTIF', u'\u0645\u0639\u0637\u0651\u0644'),
	'NEEDS PLUGIN': (u'PLUGIN REQUIS', u'\u064a\u062a\u0637\u0644\u0628 \u0625\u0636\u0627\u0641\u0629'),
	'UPDATE v%s': (u'MISE \xc0 JOUR v%s', u'\u062a\u062d\u062f\u064a\u062b v%s'),
	'Turn on': (u'Activer', u'\u062a\u0641\u0639\u064a\u0644'),
	'Turn off': (u'D\xe9sactiver', u'\u062a\u0639\u0637\u064a\u0644'),
	'On': (u'Actif', u'\u0645\u0641\u0639\u0651\u0644'),
	'Off': (u'Inactif', u'\u0645\u0639\u0637\u0651\u0644'),
	'On - waiting for the plugin': (u'Actif - plugin manquant', u'\u0645\u0641\u0639\u0651\u0644 - \u0628\u0627\u0646\u062a\u0638\u0627\u0631 \u0627\u0644\u0625\u0636\u0627\u0641\u0629'),
	'Status': (u'\xc9tat', u'\u0627\u0644\u062d\u0627\u0644\u0629'),
	'Needs': (u'Requiert', u'\u064a\u062a\u0637\u0644\u0628'),
	'Uses': (u'Utilise', u'\u064a\u0633\u062a\u062e\u062f\u0645'),
	'Applies': (u'Effet', u'\u0627\u0644\u062a\u0637\u0628\u064a\u0642'),
	'After a GUI restart': (u"Apr\xe8s red\xe9marrage de l'interface", u'\u0628\u0639\u062f \u0625\u0639\u0627\u062f\u0629 \u062a\u0634\u063a\u064a\u0644 \u0627\u0644\u0648\u0627\u062c\u0647\u0629'),
	'not installed': (u'non install\xe9', u'\u063a\u064a\u0631 \u0645\u062b\u0628\u062a'),
	'Nothing': (u'Rien', u'\u0644\u0627 \u0634\u064a\u0621'),
	'Version': (u'Version', u'\u0627\u0644\u0625\u0635\u062f\u0627\u0631'),
	'Receiver': (u'R\xe9cepteur', u'\u0627\u0644\u062c\u0647\u0627\u0632'),
	'Update': (u'Mise \xe0 jour', u'\u0627\u0644\u062a\u062d\u062f\u064a\u062b'),
	'Licence': (u'Licence', u'\u0627\u0644\u062a\u0631\u062e\u064a\u0635'),
	'Up to date': (u'\xc0 jour', u'\u0645\u062d\u062f\u0651\u062b'),
	'Update now': (u'Mettre \xe0 jour', u'\u062a\u062d\u062f\u064a\u062b \u0627\u0644\u0622\u0646'),
	'v%s available': (u'v%s disponible', u'v%s \u0645\u062a\u0627\u062d'),
	'A new version is available': (u'Une nouvelle version est disponible', u'\u064a\u062a\u0648\u0641\u0631 \u0625\u0635\u062f\u0627\u0631 \u062c\u062f\u064a\u062f'),
	'Version, update, licence': (u'Version, mise \xe0 jour, licence', u'\u0627\u0644\u0625\u0635\u062f\u0627\u0631\u060c \u0627\u0644\u062a\u062d\u062f\u064a\u062b\u060c \u0627\u0644\u062a\u0631\u062e\u064a\u0635'),
	'Install Obsidian FHD v%s now?': (u'Installer Obsidian FHD v%s maintenant ?', u'\u062a\u062b\u0628\u064a\u062a Obsidian FHD v%s \u0627\u0644\u0622\u0646\u061f'),
	'Updating Obsidian FHD': (u"Mise \xe0 jour d'Obsidian FHD", u'\u062a\u062d\u062f\u064a\u062b Obsidian FHD'),
	'Restart the GUI now to apply the changes?': (u"Red\xe9marrer l'interface maintenant pour appliquer les changements ?", u'\u0625\u0639\u0627\u062f\u0629 \u062a\u0634\u063a\u064a\u0644 \u0627\u0644\u0648\u0627\u062c\u0647\u0629 \u0627\u0644\u0622\u0646 \u0644\u062a\u0637\u0628\u064a\u0642 \u0627\u0644\u062a\u063a\u064a\u064a\u0631\u0627\u062a\u061f'),
	"What's new": (u'Nouveaut\xe9s', u'\u0627\u0644\u062c\u062f\u064a\u062f'),
	'Loading...': (u'Chargement...', u'\u062c\u0627\u0631\u064d \u0627\u0644\u062a\u062d\u0645\u064a\u0644...'),
	'The list of changes could not be loaded. Check the internet connection and try again later.': (u"La liste des nouveaut\xe9s n'a pas pu \xeatre charg\xe9e. V\xe9rifiez la connexion internet et r\xe9essayez plus tard.", u'\u062a\u0639\u0630\u0651\u0631 \u062a\u062d\u0645\u064a\u0644 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u062a\u063a\u064a\u064a\u0631\u0627\u062a. \u062a\u062d\u0642\u0642 \u0645\u0646 \u0627\u0644\u0627\u062a\u0635\u0627\u0644 \u0628\u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a \u0648\u062d\u0627\u0648\u0644 \u0644\u0627\u062d\u0642\u0627\u064b.'),
	'Obsidian Apps could not open.': (u"Obsidian Apps n'a pas pu s'ouvrir.", u'\u062a\u0639\u0630\u0651\u0631 \u0641\u062a\u062d \u062a\u0637\u0628\u064a\u0642\u0627\u062a Obsidian.'),
	'Restart the GUI and try again. If it persists, send the log (search for ObsidianFHD).': (u"Red\xe9marrez l'interface et r\xe9essayez. Si le probl\xe8me persiste, envoyez le journal (cherchez ObsidianFHD).", u'\u0623\u0639\u062f \u062a\u0634\u063a\u064a\u0644 \u0627\u0644\u0648\u0627\u062c\u0647\u0629 \u0648\u062d\u0627\u0648\u0644 \u0645\u062c\u062f\u062f\u0627\u064b. \u0625\u0630\u0627 \u0627\u0633\u062a\u0645\u0631\u062a \u0627\u0644\u0645\u0634\u0643\u0644\u0629\u060c \u0623\u0631\u0633\u0644 \u0627\u0644\u0633\u062c\u0644 (\u0627\u0628\u062d\u062b \u0639\u0646 ObsidianFHD).'),
	'Weather': (u'M\xe9t\xe9o', u'\u0627\u0644\u0637\u0642\u0633'),
	'Forecast in the infobar': (u"Pr\xe9visions dans l'infobar", u'\u0627\u0644\u062a\u0648\u0642\u0639\u0627\u062a \u0641\u064a \u0634\u0631\u064a\u0637 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a'),
	"Today's weather and the 5-day forecast at the top of the infobar.": (u"La m\xe9t\xe9o du jour et les pr\xe9visions sur 5 jours en haut de l'infobar.", u'\u0637\u0642\u0633 \u0627\u0644\u064a\u0648\u0645 \u0648\u062a\u0648\u0642\u0639\u0627\u062a 5 \u0623\u064a\u0627\u0645 \u0623\u0639\u0644\u0649 \u0634\u0631\u064a\u0637 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a.'),
	'OAWeather plugin': (u'Plugin OAWeather', u'\u0625\u0636\u0627\u0641\u0629 OAWeather'),
	'Internet, through OAWeather': (u'Internet, via OAWeather', u'\u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a \u0639\u0628\u0631 OAWeather'),
	'City and units are set in the OAWeather plugin. Turning this off hides only the weather bar; OAWeather keeps working.': (u'La ville et les unit\xe9s se r\xe8glent dans le plugin OAWeather. D\xe9sactiver masque seulement la barre m\xe9t\xe9o ; OAWeather continue de fonctionner.', u'\u062a\u064f\u0636\u0628\u0637 \u0627\u0644\u0645\u062f\u064a\u0646\u0629 \u0648\u0627\u0644\u0648\u062d\u062f\u0627\u062a \u0641\u064a \u0625\u0636\u0627\u0641\u0629 OAWeather. \u0627\u0644\u062a\u0639\u0637\u064a\u0644 \u064a\u062e\u0641\u064a \u0634\u0631\u064a\u0637 \u0627\u0644\u0637\u0642\u0633 \u0641\u0642\u0637 \u0648\u062a\u0628\u0642\u0649 OAWeather \u062a\u0639\u0645\u0644.'),
	'Bitrate': (u'D\xe9bit', u'\u0645\u0639\u062f\u0644 \u0627\u0644\u0628\u062a'),
	'Bitrate|page': (u'D\xe9bit (Bitrate)', u'\u0645\u0639\u062f\u0644 \u0627\u0644\u0628\u062a (Bitrate)'),
	'Video and audio bitrate': (u'D\xe9bit vid\xe9o et audio', u'\u0645\u0639\u062f\u0644 \u0628\u062a \u0627\u0644\u0635\u0648\u0631\u0629 \u0648\u0627\u0644\u0635\u0648\u062a'),
	'Video and audio bitrate under the clock and in the second infobar.': (u"D\xe9bit vid\xe9o et audio sous l'horloge et dans la seconde infobar.", u'\u0645\u0639\u062f\u0644 \u0628\u062a \u0627\u0644\u0635\u0648\u0631\u0629 \u0648\u0627\u0644\u0635\u0648\u062a \u062a\u062d\u062a \u0627\u0644\u0633\u0627\u0639\u0629 \u0648\u0641\u064a \u0634\u0631\u064a\u0637 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0627\u0644\u062b\u0627\u0646\u064a.'),
	'BitrateViewer plugin': (u'Plugin BitrateViewer', u'\u0625\u0636\u0627\u0641\u0629 BitrateViewer'),
	'Measured only while the infobar is shown': (u"Mesur\xe9 seulement quand l'infobar est affich\xe9e", u'\u064a\u064f\u0642\u0627\u0633 \u0641\u0642\u0637 \u0623\u062b\u0646\u0627\u0621 \u0638\u0647\u0648\u0631 \u0634\u0631\u064a\u0637 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a'),
	'Shown on satellite, cable and terrestrial channels. IPTV streams have no tuner data, so nothing is shown there.': (u"Affich\xe9 sur les cha\xeenes satellite, c\xe2ble et TNT. Les flux IPTV n'ont pas de donn\xe9es tuner, rien n'y est affich\xe9.", u'\u064a\u0638\u0647\u0631 \u0639\u0644\u0649 \u0642\u0646\u0648\u0627\u062a \u0627\u0644\u0633\u062a\u0627\u0644\u0627\u064a\u062a \u0648\u0627\u0644\u0643\u0627\u0628\u0644 \u0648\u0627\u0644\u0623\u0631\u0636\u064a. \u0628\u062b IPTV \u0644\u0627 \u064a\u062d\u062a\u0648\u064a \u0628\u064a\u0627\u0646\u0627\u062a \u0627\u0644\u0645\u0648\u0627\u0644\u0641 \u0641\u0644\u0627 \u064a\u0638\u0647\u0631 \u0634\u064a\u0621.'),
	'Floating menu': (u'Menu flottant', u'\u0642\u0627\u0626\u0645\u0629 \u0639\u0627\u0626\u0645\u0629'),
	'Menu over live TV': (u'Menu sur la TV en direct', u'\u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u0641\u0648\u0642 \u0627\u0644\u0628\u062b \u0627\u0644\u0645\u0628\u0627\u0634\u0631'),
	'Menu cards floating over live TV, with a live dashboard beside the main menu.': (u'Cartes de menu flottant sur la TV en direct, avec un tableau de bord \xe0 c\xf4t\xe9 du menu principal.', u'\u0628\u0637\u0627\u0642\u0627\u062a \u0642\u0627\u0626\u0645\u0629 \u0639\u0627\u0626\u0645\u0629 \u0641\u0648\u0642 \u0627\u0644\u0628\u062b \u0627\u0644\u0645\u0628\u0627\u0634\u0631\u060c \u0645\u0639 \u0644\u0648\u062d\u0629 \u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0628\u062c\u0627\u0646\u0628 \u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0631\u0626\u064a\u0633\u064a\u0629.'),
	'Dashboard values while the menu is open': (u'Valeurs du tableau de bord quand le menu est ouvert', u'\u0642\u064a\u0645 \u0644\u0648\u062d\u0629 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0623\u062b\u0646\u0627\u0621 \u0641\u062a\u062d \u0627\u0644\u0642\u0627\u0626\u0645\u0629'),
	'The dashboard shows temperature, CPU, RAM, disks and network. Off: the classic full-screen menus.': (u'Le tableau de bord affiche temp\xe9rature, CPU, RAM, disques et r\xe9seau. Inactif : les menus classiques plein \xe9cran.', u'\u062a\u0639\u0631\u0636 \u0627\u0644\u0644\u0648\u062d\u0629 \u0627\u0644\u062d\u0631\u0627\u0631\u0629 \u0648\u0627\u0644\u0645\u0639\u0627\u0644\u062c \u0648\u0627\u0644\u0630\u0627\u0643\u0631\u0629 \u0648\u0627\u0644\u0623\u0642\u0631\u0627\u0635 \u0648\u0627\u0644\u0634\u0628\u0643\u0629. \u0639\u0646\u062f \u0627\u0644\u062a\u0639\u0637\u064a\u0644: \u0627\u0644\u0642\u0648\u0627\u0626\u0645 \u0627\u0644\u0643\u0644\u0627\u0633\u064a\u0643\u064a\u0629 \u0628\u0645\u0644\u0621 \u0627\u0644\u0634\u0627\u0634\u0629.'),
	'Floating channel list': (u'Liste des cha\xeenes flottante', u'\u0642\u0627\u0626\u0645\u0629 \u0642\u0646\u0648\u0627\u062a \u0639\u0627\u0626\u0645\u0629'),
	'Channel list over live TV': (u'Cha\xeenes sur la TV en direct', u'\u0627\u0644\u0642\u0646\u0648\u0627\u062a \u0641\u0648\u0642 \u0627\u0644\u0628\u062b \u0627\u0644\u0645\u0628\u0627\u0634\u0631'),
	'Channel list and programme card floating over live TV.': (u'Liste des cha\xeenes et fiche du programme flottant sur la TV en direct.', u'\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0642\u0646\u0648\u0627\u062a \u0648\u0628\u0637\u0627\u0642\u0629 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062c \u0639\u0627\u0626\u0645\u0629 \u0641\u0648\u0642 \u0627\u0644\u0628\u062b \u0627\u0644\u0645\u0628\u0627\u0634\u0631.'),
	'Nothing extra': (u'Rien de plus', u'\u0644\u0627 \u0634\u064a\u0621 \u0625\u0636\u0627\u0641\u064a'),
	'Tip: for roomy rows set Channel Selection Settings > Number of rows to 10 (visible with the Advanced setup level).': (u'Astuce : pour des lignes a\xe9r\xe9es, r\xe9glez Param\xe8tres de la liste des cha\xeenes > Nombre de lignes sur 10 (visible en niveau Avanc\xe9).', u'\u0646\u0635\u064a\u062d\u0629: \u0644\u0635\u0641\u0648\u0641 \u0623\u0648\u0633\u0639 \u0627\u0636\u0628\u0637 \u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0642\u0646\u0648\u0627\u062a > \u0639\u062f\u062f \u0627\u0644\u0635\u0641\u0648\u0641 \u0639\u0644\u0649 10 (\u064a\u0638\u0647\u0631 \u0641\u064a \u0627\u0644\u0645\u0633\u062a\u0648\u0649 \u0627\u0644\u0645\u062a\u0642\u062f\u0645).'),
	'Install plugin': (u'Installer le plugin', u'\u062a\u062b\u0628\u064a\u062a \u0627\u0644\u0625\u0636\u0627\u0641\u0629'),
	'Install %s now?': (u'Installer %s maintenant ?', u'\u062a\u062b\u0628\u064a\u062a %s \u0627\u0644\u0622\u0646\u061f'),
	'Installing...': (u'Installation...', u'\u062c\u0627\u0631\u064d \u0627\u0644\u062a\u062b\u0628\u064a\u062a...'),
	'Installed - restart the GUI to apply': (u'Install\u00e9 - red\u00e9marrez l\'interface', u'\u062a\u0645 \u0627\u0644\u062a\u062b\u0628\u064a\u062a - \u0623\u0639\u062f \u062a\u0634\u063a\u064a\u0644 \u0627\u0644\u0648\u0627\u062c\u0647\u0629'),
	'Installation failed. Check the internet connection and try again.': (u'\u00c9chec de l\'installation. V\u00e9rifiez la connexion internet et r\u00e9essayez.', u'\u0641\u0634\u0644 \u0627\u0644\u062a\u062b\u0628\u064a\u062a. \u062a\u062d\u0642\u0642 \u0645\u0646 \u0627\u0644\u0627\u062a\u0635\u0627\u0644 \u0628\u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a \u0648\u062d\u0627\u0648\u0644 \u0645\u062c\u062f\u062f\u0627\u064b.'),
	'Not enough free space on the receiver to install the plugin.': (u'Pas assez d\'espace libre sur le r\u00e9cepteur pour installer le plugin.', u'\u0644\u0627 \u062a\u0648\u062c\u062f \u0645\u0633\u0627\u062d\u0629 \u0643\u0627\u0641\u064a\u0629 \u0639\u0644\u0649 \u0627\u0644\u062c\u0647\u0627\u0632 \u0644\u062a\u062b\u0628\u064a\u062a \u0627\u0644\u0625\u0636\u0627\u0641\u0629.'),
	'Halo infobar': (u'Infobar Halo', u'\u0634\u0631\u064a\u0637 \u0645\u0639\u0644\u0648\u0645\u0627\u062a Halo'),
	'Infobar with a soft light': (u'Infobar avec une lumi\u00e8re douce', u'\u0634\u0631\u064a\u0637 \u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0628\u0625\u0636\u0627\u0621\u0629 \u0646\u0627\u0639\u0645\u0629'),
	'Solid dark infobar with a soft teal light along its top edge.': (u'Infobar sombre et opaque avec une lumi\u00e8re turquoise douce sur le bord sup\u00e9rieur.', u'\u0634\u0631\u064a\u0637 \u0645\u0639\u0644\u0648\u0645\u0627\u062a \u062f\u0627\u0643\u0646 \u0645\u0639 \u0625\u0636\u0627\u0621\u0629 \u0641\u064a\u0631\u0648\u0632\u064a\u0629 \u0646\u0627\u0639\u0645\u0629 \u0639\u0644\u0649 \u062d\u0627\u0641\u062a\u0647 \u0627\u0644\u0639\u0644\u0648\u064a\u0629.'),
	'Off: the Glass infobar of earlier versions (slightly see-through).': (u'Inactif : l\'infobar Glass des versions pr\u00e9c\u00e9dentes (l\u00e9g\u00e8rement transparente).', u'\u0639\u0646\u062f \u0627\u0644\u062a\u0639\u0637\u064a\u0644: \u0634\u0631\u064a\u0637 Glass \u0645\u0646 \u0627\u0644\u0625\u0635\u062f\u0627\u0631\u0627\u062a \u0627\u0644\u0633\u0627\u0628\u0642\u0629 (\u0634\u0628\u0647 \u0634\u0641\u0627\u0641).'),
	'Infobar style': (u'Style de l\'infobar', u'\u0646\u0645\u0637 \u0634\u0631\u064a\u0637 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a'),
	'Choose the look of the infobar': (u'Choisir l\'apparence de l\'infobar', u'\u0627\u062e\u062a\u0631 \u0645\u0638\u0647\u0631 \u0634\u0631\u064a\u0637 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a'),
	'Halo: soft teal light. Glass: see-through bars. Nova: floating indigo capsule.': (u'Halo : lumi\u00e8re turquoise douce. Glass : barres transparentes. Nova : capsule indigo flottante.', u'Halo: \u0625\u0636\u0627\u0621\u0629 \u0641\u064a\u0631\u0648\u0632\u064a\u0629 \u0646\u0627\u0639\u0645\u0629. Glass: \u0623\u0634\u0631\u0637\u0629 \u0634\u0641\u0627\u0641\u0629. Nova: \u0643\u0628\u0633\u0648\u0644\u0629 \u0646\u064a\u0644\u064a\u0629 \u0639\u0627\u0626\u0645\u0629.'),
	'Style': (u'Style', u'\u0627\u0644\u0646\u0645\u0637'),
	'Styles': (u'Styles', u'\u0627\u0644\u0623\u0646\u0645\u0627\u0637'),
	'Next style': (u'Style suivant', u'\u0627\u0644\u0646\u0645\u0637 \u0627\u0644\u062a\u0627\u0644\u064a'),
	'Change style': (u'Changer de style', u'\u062a\u063a\u064a\u064a\u0631 \u0627\u0644\u0646\u0645\u0637'),
	'LEFT / RIGHT or GREEN changes the style; it applies after the GUI restart.': (u'GAUCHE / DROITE ou VERT change le style ; il s\'applique apr\u00e8s le red\u00e9marrage de l\'interface.', u'\u064a\u063a\u064a\u0651\u0631 \u064a\u0633\u0627\u0631 / \u064a\u0645\u064a\u0646 \u0623\u0648 \u0627\u0644\u0623\u062e\u0636\u0631 \u0627\u0644\u0646\u0645\u0637\u060c \u0648\u064a\u064f\u0637\u0628\u0651\u0642 \u0628\u0639\u062f \u0625\u0639\u0627\u062f\u0629 \u062a\u0634\u063a\u064a\u0644 \u0627\u0644\u0648\u0627\u062c\u0647\u0629.'),
	'About & update': (u'\xc0 propos et mise \xe0 jour', u'\u062d\u0648\u0644 \u0648\u062a\u062d\u062f\u064a\u062b'),
	'Dark 1080p skin for OpenATV and OpenPLi.': (u'Skin sombre 1080p pour OpenATV et OpenPLi.', u'\u0633\u0643\u064a\u0646 \u062f\u0627\u0643\u0646 1080p \u0644\u0640 OpenATV \u0648 OpenPLi.'),
	'MIXED': (u'MIXTE', u'\u0645\u062e\u062a\u0644\u0637'),
	'Full screen, live picture in a corner': (u'Plein \xe9cran, image en direct dans un coin', u'\u0645\u0644\u0621 \u0627\u0644\u0634\u0627\u0634\u0629\u060c \u0627\u0644\u0635\u0648\u0631\u0629 \u0627\u0644\u0645\u0628\u0627\u0634\u0631\u0629 \u0641\u064a \u0627\u0644\u0632\u0627\u0648\u064a\u0629'),
	'Cards floating over live TV': (u'Cartes flottantes sur la TV en direct', u'\u0628\u0637\u0627\u0642\u0627\u062a \u0639\u0627\u0626\u0645\u0629 \u0641\u0648\u0642 \u0627\u0644\u0628\u062b \u0627\u0644\u0645\u0628\u0627\u0634\u0631'),
	'Sidebar with a live hardware panel': (u'Barre lat\xe9rale avec infos mat\xe9riel en direct', u'\u0634\u0631\u064a\u0637 \u062c\u0627\u0646\u0628\u064a \u0645\u0639 \u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0627\u0644\u062c\u0647\u0627\u0632 \u0645\u0628\u0627\u0634\u0631\u0629'),
	'BUILT IN': (u'INT\xc9GR\xc9', u'\u0645\u062f\u0645\u062c'),
	'INSTALLED': (u'INSTALL\xc9', u'\u0645\u062b\u0628\u062a'),
	'DOWNLOAD %s': (u'T\xc9L\xc9CHARGER %s', u'\u062a\u0646\u0632\u064a\u0644 %s'),
	'Menus': (u'Menus', u'\u0627\u0644\u0642\u0648\u0627\u0626\u0645'),
	'Channel list': (u'Liste des cha\xeenes', u'\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0642\u0646\u0648\u0627\u062a'),
	'In use': (u'Utilis\xe9', u'\u0645\u0633\u062a\u062e\u062f\u0645'),
	'Not installed': (u'Non install\xe9', u'\u063a\u064a\u0631 \u0645\u062b\u0628\u062a'),
	'Details': (u'D\xe9tails', u'\u0627\u0644\u062a\u0641\u0627\u0635\u064a\u0644'),
	'Use for both': (u'Utiliser pour les deux', u'\u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0644\u0644\u0627\u062b\u0646\u064a\u0646'),
	'Used for': (u'Utilis\xe9 pour', u'\u0645\u0633\u062a\u062e\u062f\u0645 \u0644\u0640'),
	'Menus and channel list': (u'Menus et liste des cha\xeenes', u'\u0627\u0644\u0642\u0648\u0627\u0626\u0645 \u0648\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0642\u0646\u0648\u0627\u062a'),
	'Not used': (u'Non utilis\xe9', u'\u063a\u064a\u0631 \u0645\u0633\u062a\u062e\u062f\u0645'),
	'Installed': (u'Install\xe9', u'\u0645\u062b\u0628\u062a'),
	'Menus only': (u'Menus seulement', u'\u0627\u0644\u0642\u0648\u0627\u0626\u0645 \u0641\u0642\u0637'),
	'Channel list only': (u'Liste des cha\xeenes seulement', u'\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0642\u0646\u0648\u0627\u062a \u0641\u0642\u0637'),
	'Use for': (u'Utiliser pour', u'\u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0644\u0640'),
	'LEFT / RIGHT chooses where to use it; GREEN applies. Menus and channel list can use different built-in styles.': (u"GAUCHE / DROITE choisit o\xf9 l'utiliser ; VERT applique. Menus et liste des cha\xeenes peuvent avoir des styles int\xe9gr\xe9s diff\xe9rents.", u'\u064a\u0633\u0627\u0631 / \u064a\u0645\u064a\u0646 \u0644\u0627\u062e\u062a\u064a\u0627\u0631 \u0645\u0643\u0627\u0646 \u0627\u0644\u0627\u0633\u062a\u062e\u062f\u0627\u0645\u060c \u0627\u0644\u0623\u062e\u0636\u0631 \u0644\u0644\u062a\u0637\u0628\u064a\u0642. \u064a\u0645\u0643\u0646 \u0644\u0644\u0642\u0648\u0627\u0626\u0645 \u0648\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0642\u0646\u0648\u0627\u062a \u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0623\u0646\u0645\u0627\u0637 \u0645\u062f\u0645\u062c\u0629 \u0645\u062e\u062a\u0644\u0641\u0629.'),
	'Use it': (u'Utiliser', u'\u0627\u0633\u062a\u062e\u062f\u0627\u0645'),
	'%s is a style pack: it is downloaded once and applies to menus, settings pages and channel list together.': (u"%s est un pack de style : il se t\xe9l\xe9charge une fois et s'applique ensemble aux menus, aux pages de r\xe9glages et \xe0 la liste des cha\xeenes.", u'%s \u062d\u0632\u0645\u0629 \u0646\u0645\u0637: \u062a\u064f\u0646\u0632\u064e\u0651\u0644 \u0645\u0631\u0629 \u0648\u0627\u062d\u062f\u0629 \u0648\u062a\u064f\u0637\u0628\u064e\u0651\u0642 \u0639\u0644\u0649 \u0627\u0644\u0642\u0648\u0627\u0626\u0645 \u0648\u0635\u0641\u062d\u0627\u062a \u0627\u0644\u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0648\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0642\u0646\u0648\u0627\u062a \u0645\u0639\u0627\u064b.'),
	'download': (u't\xe9l\xe9chargement', u'\u062a\u0646\u0632\u064a\u0644'),
	'Downloading...': (u'T\xe9l\xe9chargement...', u'\u062c\u0627\u0631\u064d \u0627\u0644\u062a\u0646\u0632\u064a\u0644...'),
	'Removing...': (u'Suppression...', u'\u062c\u0627\u0631\u064d \u0627\u0644\u062d\u0630\u0641...'),
	'Internet, %s': (u'Internet, %s', u'\u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a\u060c %s'),
	'Download, %s': (u'T\xe9l\xe9chargement, %s', u'\u062a\u0646\u0632\u064a\u0644\u060c %s'),
	'%s is a style pack. It is downloaded once and applies to menus, settings pages and channel list together.': (u"%s est un pack de style. Il se t\xe9l\xe9charge une fois et s'applique ensemble aux menus, aux pages de r\xe9glages et \xe0 la liste des cha\xeenes.", u'%s \u062d\u0632\u0645\u0629 \u0646\u0645\u0637. \u062a\u064f\u0646\u0632\u064e\u0651\u0644 \u0645\u0631\u0629 \u0648\u0627\u062d\u062f\u0629 \u0648\u062a\u064f\u0637\u0628\u064e\u0651\u0642 \u0639\u0644\u0649 \u0627\u0644\u0642\u0648\u0627\u0626\u0645 \u0648\u0635\u0641\u062d\u0627\u062a \u0627\u0644\u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0648\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0642\u0646\u0648\u0627\u062a \u0645\u0639\u0627\u064b.'),
	'Download': (u'T\xe9l\xe9charger', u'\u062a\u0646\u0632\u064a\u0644'),
	'not selected': (u'non choisi', u'\u063a\u064a\u0631 \u0645\u062e\u062a\u0627\u0631'),
	'Style pack, %s': (u'Pack de style, %s', u'\u062d\u0632\u0645\u0629 \u0646\u0645\u0637\u060c %s'),
	'Built in': (u'Int\xe9gr\xe9', u'\u0645\u062f\u0645\u062c'),
	'%s is installed. Choose where it is used in Styles > Customise. YELLOW removes the pack.': (u"%s est install\u00e9. Choisissez o\u00f9 l'utiliser dans Styles > Personnaliser. JAUNE supprime le pack.", u'%s \u0645\u062b\u0628\u0651\u062a. \u0627\u062e\u062a\u0631 \u0623\u064a\u0646 \u064a\u064f\u0633\u062a\u062e\u062f\u0645 \u0641\u064a \u0627\u0644\u0623\u0646\u0645\u0627\u0637 > \u062a\u062e\u0635\u064a\u0635. \u0627\u0644\u0623\u0635\u0641\u0631 \u064a\u062d\u0630\u0641 \u0627\u0644\u062d\u0632\u0645\u0629.'),
	'%s applies to menus, settings pages and channel list together. YELLOW removes the pack.': (u"%s s'applique ensemble aux menus, aux pages de r\xe9glages et \xe0 la liste des cha\xeenes. JAUNE supprime le pack.", u'%s \u064a\u064f\u0637\u0628\u064e\u0651\u0642 \u0639\u0644\u0649 \u0627\u0644\u0642\u0648\u0627\u0626\u0645 \u0648\u0635\u0641\u062d\u0627\u062a \u0627\u0644\u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0648\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0642\u0646\u0648\u0627\u062a \u0645\u0639\u0627\u064b. \u0627\u0644\u0623\u0635\u0641\u0631 \u064a\u062d\u0630\u0641 \u0627\u0644\u062d\u0632\u0645\u0629.'),
	'Use %s': (u'Utiliser %s', u'\u0627\u0633\u062a\u062e\u062f\u0627\u0645 %s'),
	'Remove pack': (u'Supprimer le pack', u'\u062d\u0630\u0641 \u0627\u0644\u062d\u0632\u0645\u0629'),
	'Remove the %s style pack? Screens using it go back to Classic.': (u"Supprimer le pack de style %s ? Les \xe9crans qui l'utilisent repassent en Classic.", u'\u062d\u0630\u0641 \u062d\u0632\u0645\u0629 \u0627\u0644\u0646\u0645\u0637 %s\u061f \u0627\u0644\u0634\u0627\u0634\u0627\u062a \u0627\u0644\u062a\u064a \u062a\u0633\u062a\u062e\u062f\u0645\u0647\u0627 \u062a\u0639\u0648\u062f \u0625\u0644\u0649 Classic.'),
	'Leave %s for all screens?': (u'Quitter %s pour tous les \xe9crans ?', u'\u062a\u0631\u0643 %s \u0644\u0643\u0644 \u0627\u0644\u0634\u0627\u0634\u0627\u062a\u061f'),
	'Not enough free space on the receiver to download the style pack.': (u"Pas assez d'espace libre sur le r\xe9cepteur pour t\xe9l\xe9charger le pack de style.", u'\u0644\u0627 \u062a\u0648\u062c\u062f \u0645\u0633\u0627\u062d\u0629 \u0643\u0627\u0641\u064a\u0629 \u0641\u064a \u0627\u0644\u062c\u0647\u0627\u0632 \u0644\u062a\u0646\u0632\u064a\u0644 \u062d\u0632\u0645\u0629 \u0627\u0644\u0646\u0645\u0637.'),
	'Download failed. Check the internet connection and try again.': (u'\xc9chec du t\xe9l\xe9chargement. V\xe9rifiez la connexion internet et r\xe9essayez.', u'\u0641\u0634\u0644 \u0627\u0644\u062a\u0646\u0632\u064a\u0644. \u062a\u062d\u0642\u0651\u0642 \u0645\u0646 \u0627\u0644\u0627\u062a\u0635\u0627\u0644 \u0628\u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a \u0648\u0623\u0639\u062f \u0627\u0644\u0645\u062d\u0627\u0648\u0644\u0629.'),
	'The style pack was downloaded but could not be installed:': (u"Le pack de style a \xe9t\xe9 t\xe9l\xe9charg\xe9 mais n'a pas pu \xeatre install\xe9 :", u'تم تنزيل حزمة النمط لكن تعذّر تثبيتها:'),
	'The style pack could not be removed.': (u"Le pack de style n'a pas pu \xeatre supprim\xe9.", u'\u062a\u0639\u0630\u0651\u0631 \u062d\u0630\u0641 \u062d\u0632\u0645\u0629 \u0627\u0644\u0646\u0645\u0637.'),
	'Update Obsidian FHD first (About & update), then download %s.': (u"Mettez d'abord Obsidian FHD \xe0 jour (\xc0 propos et mise \xe0 jour), puis t\xe9l\xe9chargez %s.", u'\u062d\u062f\u0651\u062b Obsidian FHD \u0623\u0648\u0644\u0627\u064b (\u062d\u0648\u0644 \u0648\u062a\u062d\u062f\u064a\u062b)\u060c \u062b\u0645 \u0646\u0632\u0651\u0644 %s.'),
	'Download the %s style pack (%s)?': (u'T\xe9l\xe9charger le pack de style %s (%s) ?', u'\u062a\u0646\u0632\u064a\u0644 \u062d\u0632\u0645\u0629 \u0627\u0644\u0646\u0645\u0637 %s (%s)\u061f'),
	'Menu style': (u'Style du menu', u'\u0646\u0645\u0637 \u0627\u0644\u0642\u0627\u0626\u0645\u0629'),
	'Channel list style': (u'Style de la liste des cha\xeenes', u'\u0646\u0645\u0637 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0642\u0646\u0648\u0627\u062a'),
	'Classic, Floating or Edge': (u'Classic, Floating ou Edge', u'Classic \u0623\u0648 Floating \u0623\u0648 Edge'),
	'Classic: full screen. Floating: cards over live TV. Edge: sidebar with a hardware panel.': (u'Classic : plein \xe9cran. Floating : cartes sur la TV en direct. Edge : barre lat\xe9rale avec infos mat\xe9riel.', u'Classic: \u0645\u0644\u0621 \u0627\u0644\u0634\u0627\u0634\u0629. Floating: \u0628\u0637\u0627\u0642\u0627\u062a \u0641\u0648\u0642 \u0627\u0644\u0628\u062b \u0627\u0644\u0645\u0628\u0627\u0634\u0631. Edge: \u0634\u0631\u064a\u0637 \u062c\u0627\u0646\u0628\u064a \u0645\u0639 \u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0627\u0644\u062c\u0647\u0627\u0632.'),
	'Classic: full screen. Floating: cards over live TV. Edge: channels in a sidebar, live picture beside them.': (u'Classic : plein \xe9cran. Floating : cartes sur la TV en direct. Edge : cha\xeenes dans une barre lat\xe9rale, image en direct \xe0 c\xf4t\xe9.', u'Classic: \u0645\u0644\u0621 \u0627\u0644\u0634\u0627\u0634\u0629. Floating: \u0628\u0637\u0627\u0642\u0627\u062a \u0641\u0648\u0642 \u0627\u0644\u0628\u062b \u0627\u0644\u0645\u0628\u0627\u0634\u0631. Edge: \u0627\u0644\u0642\u0646\u0648\u0627\u062a \u0641\u064a \u0634\u0631\u064a\u0637 \u062c\u0627\u0646\u0628\u064a \u0648\u0627\u0644\u0635\u0648\u0631\u0629 \u0627\u0644\u0645\u0628\u0627\u0634\u0631\u0629 \u0628\u062c\u0627\u0646\u0628\u0647\u0627.'),
	'Also changes the settings pages. LEFT / RIGHT or GREEN changes the style; it applies after the GUI restart.': (u"Change aussi les pages de r\xe9glages. GAUCHE / DROITE ou VERT change le style ; appliqu\xe9 apr\xe8s le red\xe9marrage de l'interface.", u'\u064a\u063a\u064a\u0651\u0631 \u0623\u064a\u0636\u0627\u064b \u0635\u0641\u062d\u0627\u062a \u0627\u0644\u0625\u0639\u062f\u0627\u062f\u0627\u062a. \u064a\u0633\u0627\u0631 / \u064a\u0645\u064a\u0646 \u0623\u0648 \u0627\u0644\u0623\u062e\u0636\u0631 \u0644\u062a\u063a\u064a\u064a\u0631 \u0627\u0644\u0646\u0645\u0637\u061b \u064a\u064f\u0637\u0628\u0651\u0642 \u0628\u0639\u062f \u0625\u0639\u0627\u062f\u0629 \u062a\u0634\u063a\u064a\u0644 \u0627\u0644\u0648\u0627\u062c\u0647\u0629.'),
	'Unable to apply the style. Check free space and file permissions.': (u"Impossible d'appliquer le style. V\xe9rifiez l'espace libre et les permissions.", u'\u062a\u0639\u0630\u0651\u0631 \u062a\u0637\u0628\u064a\u0642 \u0627\u0644\u0646\u0645\u0637. \u062a\u062d\u0642\u0651\u0642 \u0645\u0646 \u0627\u0644\u0645\u0633\u0627\u062d\u0629 \u0627\u0644\u062d\u0631\u0629 \u0648\u0635\u0644\u0627\u062d\u064a\u0627\u062a \u0627\u0644\u0645\u0644\u0641\u0627\u062a.'),
	'Permanent clock': (u'Horloge permanente', u'\u0633\u0627\u0639\u0629 \u062f\u0627\u0626\u0645\u0629'),
	'Time over live TV': (u"L'heure sur la TV en direct", u'\u0627\u0644\u0648\u0642\u062a \u0641\u0648\u0642 \u0627\u0644\u0628\u062b \u0627\u0644\u0645\u0628\u0627\u0634\u0631'),
	'Make the clock fit your screen': (u"Adaptez l'horloge \xe0 votre \xe9cran", u'\u0627\u0636\u0628\u0637 \u0627\u0644\u0633\u0627\u0639\u0629 \u062d\u0633\u0628 \u0634\u0627\u0634\u062a\u0643'),
	'Settings': (u'R\xe9glages', u'\u0627\u0644\u0625\u0639\u062f\u0627\u062f\u0627\u062a'),
	'Cancel': (u'Annuler', u'\u0625\u0644\u063a\u0627\u0621'),
	'Save': (u'Enregistrer', u'\u062d\u0641\u0638'),
	'Clock enabled': (u'Horloge activ\xe9e', u'\u062a\u0641\u0639\u064a\u0644 \u0627\u0644\u0633\u0627\u0639\u0629'),
	'Clock design': (u'Style de l\'horloge', u'\u062a\u0635\u0645\u064a\u0645 \u0627\u0644\u0633\u0627\u0639\u0629'),
	'Minimal': (u'Minimaliste', u'\u0628\u0633\u064a\u0637'),
	'Flip': (u'\xc0 volets', u'\u0628\u0637\u0627\u0642\u0627\u062a \u0645\u0642\u0633\u0645\u0629'),
	'Stacked': (u'Superpos\xe9e', u'\u0645\u062a\u0631\u0627\u0635\u0629'),
	'HOURS': (u'HEURES', u'\u0633\u0627\u0639\u0627\u062a'),
	'MINUTES': (u'MINUTES', u'\u062f\u0642\u0627\u0626\u0642'),
	'SECONDS': (u'SECONDES', u'\u062b\u0648\u0627\u0646\u064a'),
	'Clock color': (u"Couleur de l'horloge", u'\u0644\u0648\u0646 \u0627\u0644\u0633\u0627\u0639\u0629'),
	'White': (u'Blanc', u'\u0623\u0628\u064a\u0636'),
	'Yellow': (u'Jaune', u'\u0623\u0635\u0641\u0631'),
	'Position': (u'Position', u'\u0627\u0644\u0645\u0648\u0636\u0639'),
	'Right': (u'Droite', u'\u064a\u0645\u064a\u0646'),
	'Centre': (u'Centre', u'\u0648\u0633\u0637'),
	'Left': (u'Gauche', u'\u064a\u0633\u0627\u0631'),
	'Size': (u'Taille', u'\u0627\u0644\u062d\u062c\u0645'),
	'Small': (u'Petite', u'\u0635\u063a\u064a\u0631'),
	'Medium': (u'Moyenne', u'\u0645\u062a\u0648\u0633\u0637'),
	'Large': (u'Grande', u'\u0643\u0628\u064a\u0631'),
	'Show': (u'Afficher', u'\u0625\u0638\u0647\u0627\u0631'),
	'Hide': (u'Masquer', u'\u0625\u062e\u0641\u0627\u0621'),
	'The clock at the top right of the Halo and Glass infobars.': (u"L'horloge en haut \u00e0 droite des infobars Halo et Glass.", u'\u0627\u0644\u0633\u0627\u0639\u0629 \u0623\u0639\u0644\u0649 \u064a\u0645\u064a\u0646 \u0634\u0631\u064a\u0637 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a Halo \u0648 Glass.'),
	'Infobar clock': (u"Horloge de l'infobar", u'\u0627\u0644\u0633\u0627\u0639\u0629 \u0641\u064a \u0634\u0631\u064a\u0637 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a'),
	'Show seconds': (u'Afficher les secondes', u'\u0625\u0638\u0647\u0627\u0631 \u0627\u0644\u062b\u0648\u0627\u0646\u064a'),
	'Show date': (u'Afficher la date', u'\u0625\u0638\u0647\u0627\u0631 \u0627\u0644\u062a\u0627\u0631\u064a\u062e'),
	'Preview only. Green saves; Red or Exit discards changes.': (u'Aper\xe7u seulement. Vert enregistre ; Rouge ou Exit annule.', u'\u0645\u0639\u0627\u064a\u0646\u0629 \u0641\u0642\u0637. \u0627\u0644\u0623\u062e\u0636\u0631 \u0644\u0644\u062d\u0641\u0638\u060c \u0627\u0644\u0623\u062d\u0645\u0631 \u0623\u0648 \u062e\u0631\u0648\u062c \u0644\u0644\u0625\u0644\u063a\u0627\u0621.'),
	'Paused: the separate Permanent Clock plugin is enabled. Turn it off there to use this clock.': (u'En pause : le plugin Permanent Clock est activ\xe9. D\xe9sactivez-le pour utiliser cette horloge.', u'\u0645\u062a\u0648\u0642\u0641\u0629: \u0625\u0636\u0627\u0641\u0629 Permanent Clock \u0645\u0641\u0639\u0644\u0629. \u0639\u0637\u0651\u0644\u0647\u0627 \u0644\u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0647\u0630\u0647 \u0627\u0644\u0633\u0627\u0639\u0629.'),
	'Clock settings could not open.': (u"Les r\xe9glages de l'horloge n'ont pas pu s'ouvrir.", u'\u062a\u0639\u0630\u0631 \u0641\u062a\u062d \u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0627\u0644\u0633\u0627\u0639\u0629.'),
	'Clock settings could not be saved.': (u"Les r\xe9glages de l'horloge n'ont pas pu \xeatre enregistr\xe9s.", u'\u062a\u0639\u0630\u0631 \u062d\u0641\u0638 \u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0627\u0644\u0633\u0627\u0639\u0629.'),
}


def boxLanguage():
	try:
		from Components.Language import language
		return (language.getLanguage() or "")[:2]
	except Exception:
		return ""


def _(text):
	# French / Arabic from TRANSLATIONS, otherwise enigma2's own translation, otherwise English. UTF-8 str on Python 2.
	lang = boxLanguage()
	if lang in ("fr", "ar") and text in TRANSLATIONS:
		out = TRANSLATIONS[text][0 if lang == "fr" else 1]
		try:
			unicode
			return out.encode("utf-8")
		except NameError:
			return out
	text = text.split("|")[0]
	try:
		from gettext import gettext
		return gettext(text)
	except Exception:
		return text


def setFlag(path, on):
	# on=True -> the flag file exists.
	try:
		if on and not exists(path):
			open(path, "w").close()
		elif not on and exists(path):
			remove(path)
	except Exception as e:
		print("[ObsidianFHD] flag %s: %s" % (path, e))


def anyExists(paths):
	for p in paths:
		if exists(p):
			return True
	return False


# icon / preview index matches the order of the "pixmaps" lists in skin_apps.xml
APPS = [
	{"key": "weather", "image": 0, "name": "Weather", "short": "Forecast in the infobar",
		"desc": "Today's weather and the 5-day forecast at the top of the infobar.",
		"flag": NO_WEATHER, "flagMeansOn": False,
		"needs": [CONVERTERS + "OAWeather.pyc", CONVERTERS + "OAWeather.py"], "needsText": "OAWeather plugin",
		"package": "enigma2-plugin-extensions-oaweather",
		"usesText": "Internet, through OAWeather",
		"note": "City and units are set in the OAWeather plugin. Turning this off hides only the weather bar; OAWeather keeps working."},
	{"key": "bitrate", "image": 1, "name": "Bitrate", "page": "Bitrate|page", "short": "Video and audio bitrate",
		"desc": "Video and audio bitrate under the clock and in the second infobar.",
		"flag": NO_BITRATE, "flagMeansOn": False,
		"needs": ["/usr/lib/enigma2/python/Plugins/Extensions/BitrateViewer/bitratecalc.so"], "needsText": "BitrateViewer plugin",
		"package": "enigma2-plugin-extensions-bitrateviewer",
		"usesText": "Measured only while the infobar is shown",
		"note": "Shown on satellite, cable and terrestrial channels. IPTV streams have no tuner data, so nothing is shown there."},
	{"key": "styles", "image": 2, "name": "Styles", "short": "Classic, Floating, Edge or Nova", "group": True},
	{"key": "about", "image": 4, "name": "About & update", "short": "", "desc": "Dark 1080p skin for OpenATV and OpenPLi.",
		"flag": None},
	{"key": "clock", "image": 6, "name": "Permanent clock", "short": "Time over live TV"},
	{"key": "mawaqit", "appId": "mawaqit", "image": 7, "preview": 12, "name": "Mawaqit", "short": "Prayer times of your mosque",
		"desc": "Next prayer with countdown, the day's adhan and iqama times, Hijri date and a full-screen Display mode.",
		"note": "Your mosque's timetable from mawaqit.net (free account). Separate download with its own updates. Not made by MAWAQIT.",
		"uses": "Internet, a free mawaqit.net account", "display": True, "direct": True},
	{"key": "posters", "appId": "posters", "image": 8, "preview": 29, "previews": {"infobar": 31, "film": 32, "off": 33}, "name": "Posters", "short": "Film and series posters",
		"desc": "A poster, year and rating beside the infobar a few seconds after a zap, for films, series and documentaries.",
		"note": "Posters from TMDB, kept on your USB or HDD drive (never the flash). Separate download with its own updates. Not endorsed by TMDB.",
		"uses": "Internet, a free TMDB API key, a USB or HDD drive"},
	{"key": "cast", "appId": "cast", "image": 9, "preview": 30, "name": "Cast", "short": "Photos from your phone",
		"desc": "Scan a code with your phone and send a photo to the TV, with your name and a short message.",
		"note": "Works on your home network only; photos stay in your house. The photo on screen is kept in memory only, and Green saves it to your USB or HDD drive. Separate download with its own updates.",
		"uses": "A phone on the same home network", "direct": True},
]
# Infobar style: no grid tile of its own any more (set on the Look page), same flags and styles as before.
INFOBAR_APP = {"key": "infobar", "image": 5, "name": "Infobar style", "short": "Choose the look of the infobar",
		"desc": "Halo: soft teal light. Glass: see-through bars. Nova: floating capsule (Nova style pack).",
		"styles": [("halo", None, "Halo", 5), ("glass", INFOBAR_GLASS, "Glass", 6), ("nova", INFOBAR_NOVA, "Nova", 7, "nova"), ("k7", INFOBAR_K7, "K7", 17, "k7"),
			("synthwave", INFOBAR_SYNTHWAVE, "Synthwave", 23, "synthwave"), ("matchday", INFOBAR_MATCHDAY, "Matchday", 27, "matchday")],
		"note": "LEFT / RIGHT or GREEN changes the style; it applies after the GUI restart."}


def packOf(style):
	# pack key of a style (None for built-in styles)
	return style[4] if len(style) > 4 else None


def readVersion(path):
	try:
		with open(path) as f:
			return f.read().strip()
	except Exception:
		return ""


def packInstalled(key):
	# installed and usable: every file present and the pack from the same release as the skin
	if not all(exists(f) for f in PACKS[key]["files"]):
		return False
	version = readVersion(SKIN_DIR + key + "/version.txt")
	return bool(version) and version == readVersion(SKIN_DIR + "version.txt")


def styleUsable(style):
	return packOf(style) is None or packInstalled(packOf(style))


# Menu and channel list styles, managed together by the Styles app (Classic and Floating built in and mixable,
# Edge a downloadable full-look pack). Same flag files as before.
STYLE_SCREENS = [
	{"key": "menu", "image": 2, "name": "Menu style", "short": "Classic, Floating or Edge",
		"desc": "Classic: full screen. Floating: cards over live TV. Edge: sidebar with a hardware panel.",
		"styles": [("classic", None, "Classic", 8), ("floating", MENU_FLOATING, "Floating", 2), ("edge", MENU_EDGE, "Edge", 9, "edge"),
			("k7", MENU_K7, "K7", 15, "k7"), ("synthwave", MENU_SYNTHWAVE, "Synthwave", 21, "synthwave"),
			("matchday", MENU_MATCHDAY, "Matchday", 25, "matchday")],
		"note": "Also changes the settings pages. LEFT / RIGHT or GREEN changes the style; it applies after the GUI restart."},
	{"key": "chlist", "image": 3, "name": "Channel list style", "short": "Classic, Floating or Edge",
		"desc": "Classic: full screen. Floating: cards over live TV. Edge: channels in a sidebar, live picture beside them. Nova: capsules over live TV.",
		"styles": [("classic", None, "Classic", 10), ("floating", CHLIST_FLOATING, "Floating", 3), ("edge", CHLIST_EDGE, "Edge", 11, "edge"),
			("nova", CHLIST_NOVA, "Nova", 14, "nova"), ("k7", CHLIST_K7, "K7", 16, "k7"),
			("synthwave", CHLIST_SYNTHWAVE, "Synthwave", 22, "synthwave"), ("matchday", CHLIST_MATCHDAY, "Matchday", 26, "matchday")],
		"note": "Tip: for roomy rows set Channel Selection Settings > Number of rows to 10 (visible with the Advanced setup level)."},
]
# the parts a style can have, shown as badges on its Styles card
STYLE_COMPONENTS = [("menu", "MENUS"), ("chlist", "CHANNELS"), ("infobar", "INFOBAR")]
STYLES = [("classic", "Classic", "Full screen, live picture in a corner", 8),
	("floating", "Floating", "Cards floating over live TV", 2),
	("edge", "Edge", "Sidebar with a live hardware panel", 9),
	("nova", "Nova", "Capsule infobar, purple or Obsidian", 7),
	("k7", "K7", "Silver console with LCD readouts", 15),
	("synthwave", "Synthwave", "Neon 80s arcade", 24),
	("matchday", "Matchday", "Sports broadcast graphics", 28)]


def styleApps(key):
	# the screens (menus, channel list, infobar) that have this style
	return [a for a in STYLE_SCREENS + [INFOBAR_APP] if any(st[0] == key for st in a["styles"])]


def styleUsedEverywhere(key):
	# every screen that has this style uses it (for Nova: its channel list and its infobar)
	return all(currentStyle(a)[0] == key for a in styleApps(key))


def styleUse(key):
	# which screens use this style: (menus, channel list)
	return tuple(currentStyle(a)[0] == key for a in STYLE_SCREENS)


PACK_LOG = "/tmp/obsidian-pack.log"  # opkg output of the last pack install


def packCommand(pack, action):
	# Shell command for opkg in the background: download (release asset, repository fallback, package check) or remove.
	name = PACKS[pack]["package"]
	if action == "remove":
		return "opkg remove %s" % name
	# own temporary folder, network time limits, cleanup in every case
	urls = " ".join('"%s"' % (u % name) for u in PACK_URLS)
	return (': > %s; d=$(mktemp -d /tmp/obsidian-pack.XXXXXX) || { echo "cannot create a temporary folder in /tmp" >> %s; exit 2; }; f=$d/%s_all.ipk; ok=0; for u in %s; do rm -f $f; '
		'%s; '
		'if [ -s $f ] && [ "$(dd if=$f bs=7 count=1 2>/dev/null)" = "!<arch>" ]; then ok=1; break; else echo "no valid package from $u" >> %s; fi; done; '
		'if [ $ok = 1 ]; then opkg install --force-reinstall $f > %s 2>&1 && r=0 || r=3; else r=2; fi; rm -rf $d; exit $r'
		) % (PACK_LOG, PACK_LOG, name, urls, fetchShell('"$u"', "$f", 120, PACK_LOG), PACK_LOG, PACK_LOG)


def packFailMessage(pack, retval):
	# exit 2: no valid download from any URL; exit 3: opkg refused the package (its last lines come from the log)
	print("[ObsidianFHD] pack download %s failed (%s)" % (pack, retval))
	try:
		with open(PACK_LOG, errors="replace") as f:
			lines = [l.strip() for l in f.read().splitlines() if l.strip()]
	except Exception:
		lines = []
	if retval != 3:
		# the reasons only: no Python traceback or code lines
		lines = [l[:120] for l in lines if not l.startswith(("Traceback", "File ", "^", "import sys", "d=u."))]
		return _("Download failed. Check the internet connection and try again.") + "\n\n" + "\n".join(lines[-14:]) + "\n\n" + PACK_LOG
	lines = lines[-3:]
	return _("The style pack was downloaded but could not be installed:") + "\n\n" + ("\n".join(lines) or "opkg") + "\n\n" + PACK_LOG


def currentStyle(app):
	# style chooser apps: the style whose flag file exists (and whose pack is installed), otherwise the default one
	for style in app["styles"]:
		if style[1] and exists(style[1]) and styleUsable(style):
			return style
	return app["styles"][0]


def packApps(key):
	# the style apps that have a style from this pack
	return [a for a in APPS + STYLE_SCREENS + [INFOBAR_APP] if a.get("styles") and any(packOf(st) == key for st in a["styles"])]


def fallbackStyle(app):
	# style used when a pack is left or removed: Glass for the infobar (the Nova infobar is in the Nova pack), else the first
	return "glass" if app["key"] == "infobar" else app["styles"][0][0]


def novaColours():
	return "obsidian" if exists(NOVA_OBSIDIAN) else "purple"


def setNovaColours(name):
	setFlag(NOVA_OBSIDIAN, name == "obsidian")
	try:
		from .infobar import sync
		sync()
	except Exception as e:
		print("[ObsidianFHD] nova colours: %s" % e)


def writeStyleFlags(app, key):
	# exactly one style flag in this app (none for the default style)
	for style in app["styles"]:
		if style[1]:
			setFlag(style[1], style[0] == key)


def setStyle(app, key):
	previous = currentStyle(app)[0]
	style = [st for st in app["styles"] if st[0] == key][0]
	pack = packOf(style)
	oldPack = packOf(currentStyle(app))
	if pack:
		# full look: the pack's style on every screen it covers
		for other in packApps(pack):
			writeStyleFlags(other, [st for st in other["styles"] if packOf(st) == pack][0][0])
	else:
		writeStyleFlags(app, key)
		if oldPack:
			# leaving a full-look pack on one screen leaves it on all of them (back to Classic)
			for other in packApps(oldPack):
				if other is not app and packOf(currentStyle(other)) == oldPack:
					writeStyleFlags(other, fallbackStyle(other))
	if app["key"] != "infobar":
		if pack or oldPack:
			# a full-look pack may also have changed the infobar (Nova): rebuild its file now
			try:
				from .infobar import sync
				sync()
			except Exception as e:
				print("[ObsidianFHD] infobar selection: %s" % e)
		return True
	try:
		from .infobar import sync
		sync()
	except Exception as e:
		for style in app["styles"]:
			if style[1]:
				setFlag(style[1], style[0] == previous)
		print("[ObsidianFHD] infobar selection: %s" % e)
		return False
	return True



# ---- Look page (Obsidian Apps > Styles > Look): four settings, saved together. Style sets the three others (and the
# Nova colours); changing Menus, Channel list or Infobar makes the look "Custom". Nothing is written before Save, and
# Save writes the same flag files as before. Free of enigma2 imports so tools/test-look.py can check it offline.
# (key, name, menus, channel list, infobar, Nova colours or None, preview image)
LOOK_STYLES = [
	("classic", "Classic", "classic", "classic", "halo", None, 8),
	("floating", "Floating", "floating", "floating", "glass", None, 2),
	("edge", "Edge", "edge", "edge", "halo", None, 9),
	("k7", "K7", "k7", "k7", "k7", None, 15),
	("synthwave", "Synthwave", "synthwave", "synthwave", "synthwave", None, 24),
	("matchday", "Matchday", "matchday", "matchday", "matchday", None, 28),
]
LOOK_ROWS = ["style", "menu", "chlist", "infobar", "clock"]


def lookApp(key):
	return {"menu": STYLE_SCREENS[0], "chlist": STYLE_SCREENS[1], "infobar": INFOBAR_APP}.get(key)


def lookSaved():
	# the saved look, read only
	return {"menu": currentStyle(STYLE_SCREENS[0])[0], "chlist": currentStyle(STYLE_SCREENS[1])[0],
		"infobar": currentStyle(INFOBAR_APP)[0], "colours": novaColours(),
		"clock": "hide" if exists(NO_INFOBAR_CLOCK) else "show"}


def lookStyleOf(sel):
	# the Style a selection matches, or None ("Custom")
	for key, name, menu, chlist, infobar, colours, preview in LOOK_STYLES:
		if (sel["menu"], sel["chlist"], sel["infobar"]) == (menu, chlist, infobar) and colours in (None, sel["colours"]):
			return key
	return None


def lookWithStyle(sel, key):
	style = [st for st in LOOK_STYLES if st[0] == key][0]
	new = dict(sel, menu=style[2], chlist=style[3], infobar=style[4])
	if style[5]:
		new["colours"] = style[5]
	return new


def lookPreset(sel, key):
	# Customise opened from a style card: that style pre-selected on screen (nothing is saved). Styles that are not a
	# full look (Nova: channel list and infobar) set only the screens they have.
	if any(st[0] == key for st in LOOK_STYLES):
		return lookWithStyle(sel, key)
	new = dict(sel)
	for row in ("menu", "chlist", "infobar"):
		if any(st[0] == key for st in lookApp(row)["styles"]):
			new[row] = key
	return new


def lookValues(row):
	if row == "clock":
		return ["show", "hide"]
	if row == "style":
		return [st[0] for st in LOOK_STYLES]
	values = [st[0] for st in lookApp(row)["styles"]]
	# the Infobar row offers the Nova infobar in both colours (the colours are shared by every Nova screen)
	if row == "infobar":
		values.insert(values.index("nova") + 1, "novao")
	return values


def lookRowValue(sel, row):
	# the value a row shows for a selection ("novao" = Nova infobar in Obsidian colours)
	if row == "infobar" and sel["infobar"] == "nova" and sel["colours"] == "obsidian":
		return "novao"
	return sel[row]


def lookSetRow(sel, row, value):
	new = dict(sel)
	if row == "infobar" and value in ("nova", "novao"):
		new["infobar"], new["colours"] = "nova", "obsidian" if value == "novao" else "purple"
	else:
		new[row] = value
	return new


def lookLabel(row):
	return {"style": _("Style"), "menu": _("Menus"), "chlist": _("Channel list"), "infobar": _("Infobar"), "clock": _("Infobar clock")}[row]


def lookValueName(row, value):
	if row == "clock":
		return _("Show") if value == "show" else _("Hide")
	if row == "style":
		return _("Custom") if value is None else _([st[1] for st in LOOK_STYLES if st[0] == value][0])
	if row == "infobar" and value in ("nova", "novao"):
		return _("Nova Obsidian") if value == "novao" else _("Nova Purple")
	return _([st[2] for st in lookApp(row)["styles"] if st[0] == value][0])


# preview of the Nova infobar in Obsidian colours (skin_apps.xml "preview" pixmaps; the Nova channel list is purple only)
NOVAO_PREVIEWS = {"infobar": 20}
# Previews that come with their style pack (in its folder): the skin lists the pack's main preview at these indexes
# (always present), and the pack's own image is drawn over it once the pack is installed. Keeps them out of the skin package.
PACK_PREVIEWS = {
	11: "edge/preview_chlist.jpg",
	14: "nova/preview_chlist.jpg",
	16: "k7/preview_chlist.jpg",
	17: "k7/preview_infobar.jpg",
	18: "nova/preview_infobar_novao.jpg",
	19: "nova/preview_infobar_novao.jpg",
	20: "nova/preview_infobar_novao.jpg",
	21: "synthwave/preview_menu.jpg",
	22: "synthwave/preview_chlist.jpg",
	23: "synthwave/preview_infobar.jpg",
	25: "matchday/preview_menu.jpg",
	26: "matchday/preview_chlist.jpg",
	27: "matchday/preview_infobar.jpg",
}


def lookPreview(row, value, colours="purple"):
	if row == "clock":
		return 5  # the Halo infobar with its clock
	if row == "style":
		return [st[6] for st in LOOK_STYLES if st[0] == value][0] if value else 8
	if row == "infobar" and (value == "novao" or value == "nova" and colours == "obsidian"):
		return NOVAO_PREVIEWS[row]
	return [st[3] for st in lookApp(row)["styles"] if st[0] == value][0]


def lookPack(row, value):
	if row == "clock":
		return None
	if row == "style":
		style = [st for st in LOOK_STYLES if st[0] == value]
		return style and packOf([st for st in STYLE_SCREENS[0]["styles"] if st[0] == style[0][2]][0]) or None
	value = "nova" if value == "novao" else value
	return packOf([st for st in lookApp(row)["styles"] if st[0] == value][0])


def lookMissingPacks(sel):
	# packs a selection needs that are not installed (downloaded by Save first)
	need = []
	for row in ("menu", "chlist", "infobar"):
		pack = lookPack(row, sel[row])
		if pack and not packInstalled(pack) and pack not in need:
			need.append(pack)
	return need


def lookSave(sel):
	# writes the selection: one style flag per screen (none for the default style) and the Nova colours
	for row in ("menu", "chlist", "infobar"):
		writeStyleFlags(lookApp(row), sel[row])
	setFlag(NOVA_OBSIDIAN, sel["colours"] == "obsidian")
	setFlag(NO_INFOBAR_CLOCK, sel.get("clock") == "hide")
	return lookSaved() == sel


def leavePack(pack):
	# before removing a pack: the screens using it go back (Classic, Glass for the infobar)
	for app in packApps(pack):
		if packOf(currentStyle(app)) == pack:
			writeStyleFlags(app, fallbackStyle(app))


def isOn(app):
	if app["key"] == "clock":
		try:
			from .clock import settings
			return settings.enabled.value
		except Exception as e:
			print("[ObsidianFHD] clock settings: %s" % e)
			return False
	return exists(app["flag"]) == app["flagMeansOn"]


def setOn(app, on):
	setFlag(app["flag"], on == app["flagMeansOn"])
	if app["key"] == "weather":
		try:
			from .infobar import sync
			sync()
		except Exception as e:
			print("[ObsidianFHD] infobar weather: %s" % e)


def isAvailable(app):
	return not app.get("needs") or anyExists(app["needs"])


def appVersion(key):
	# installed version of a downloadable app, "" when it is not installed
	plugin = APP_PACKAGES[key]["plugin"]
	return readVersion(plugin + "version.txt") if exists(plugin + "plugin.py") else ""


def versionTuple(text):
	try:
		return tuple(int(x) for x in text.strip().lstrip("v").split("."))
	except Exception:
		return ()


def appEntry(key):
	# the catalogue entry of an app (None while loading or when unreachable)
	for entry in (Catalogue.data or {}).get("apps", []):
		if entry.get("id") == key and entry.get("package") == APP_PACKAGES[key]["package"]:
			return entry
	return None


def appState(key):
	"""("busy" / "installed" / "update" / "download" / "unknown", installed version, catalogue entry)"""
	installed, entry = appVersion(key), appEntry(key)
	if installed:
		if entry and versionTuple(entry.get("version", "")) > versionTuple(installed):
			return "update", installed, entry
		return "installed", installed, entry
	return ("download" if entry else "unknown"), "", entry


def appCommand(key, action, entry=None):
	# Shell command run in the background: install (download, check size and sha256, opkg) or remove.
	name = APP_PACKAGES[key]["package"]
	if action == "remove":
		return "opkg remove %s" % name
	import re
	sha, size, file = str(entry.get("sha256", "")).lower(), int(entry.get("size", 0)), str(entry.get("file", ""))
	if not re.match(r"^[0-9a-f]{64}$", sha) or size <= 0 or not re.match(r"^[A-Za-z0-9._+-]+\.ipk$", file):
		return None
	urls = " ".join('"%s"' % (u % file) for u in APP_RELEASE_URLS)
	return ('d=$(mktemp -d /tmp/obsidian-app.XXXXXX) || exit 1; f=$d/%s; ok=0; for u in %s; do rm -f $f; '
		'%s; '
		'if [ "$(wc -c < $f 2>/dev/null)" = "%d" ] && [ "$(sha256sum $f | cut -d" " -f1)" = "%s" ]; then ok=1; break; fi; done; '
		'r=1; [ $ok = 1 ] && opkg install --force-reinstall $f && r=0; rm -rf $d; exit $r') % (file, urls, fetchShell('"$u"', "$f", 180, "/tmp/obsidian-app.log"), size, sha)


def freeSpaceMB(path="/"):
	try:
		from os import statvfs
		st = statvfs(path)
		return st.f_bavail * st.f_frsize // (1024 * 1024)
	except Exception:
		return -1


def skinInfo():
	version, image = "", ""
	try:
		from Components.Converter.ObsidianSysInfo import imageInfo, skinVersion
		version, image = skinVersion(), imageInfo()
	except Exception:
		pass
	return version, image


def latestVersion():
	try:
		from Components.Converter.ObsidianSysInfo import updateAvailable
		return updateAvailable()
	except Exception:
		return ""


# Colours are fixed in the skin: every coloured text has one label per colour (suffix g green, a amber, c accent,
# m muted, "" normal text) and only the wanted one gets the text. Changing colours at run time is not redrawn on
# every image.
def colourText(screen, name, text, kind, kinds=("", "g", "a", "c", "m"), pills=False):
	# pills=True: the labels are pills with their own background, so the unused ones are hidden, not just emptied.
	for k in kinds:
		if (name + k) in screen:
			screen[name + k].setText(text if k == kind else "")
			if pills:
				if k == kind:
					screen[name + k].show()
				else:
					screen[name + k].hide()


CHANGELOG_URL = "https://raw.githubusercontent.com/dali44g/Obsidian-FHD/main/CHANGELOG.md"


class ChangelogFetch(object):
	# CHANGELOG.md from the public repository, read in a background thread (verified HTTPS, 8 s timeout, 64 KB max).
	# text is None while loading, "" after a failure.
	text = None
	running = False

	@classmethod
	def start(cls):
		if cls.running or cls.text:
			return
		cls.running = True
		cls.text = None
		try:
			from threading import Thread
			t = Thread(target=cls.run)
			t.daemon = True
			t.start()
		except Exception:
			cls.running = False
			cls.text = ""

	@classmethod
	def run(cls):
		result = ""
		try:
			try:
				from urllib.request import urlopen
			except ImportError:
				from urllib2 import urlopen
			data = urlopen(CHANGELOG_URL, timeout=8).read(65536)
			result = plainChangelog(data.decode("utf-8", "replace") if isinstance(data, bytes) else data)
		except Exception as e:
			print("[ObsidianFHD] changelog: %s" % e)
		cls.text = result
		cls.running = False


class Catalogue(object):
	# apps.json from the latest release (repository copy as fallback), read in a background thread.
	# data is None while loading or after a failure; the panel retries when it is opened again.
	data = None
	running = False

	@classmethod
	def start(cls):
		if cls.running or cls.data:
			return
		cls.running = True
		try:
			from threading import Thread
			t = Thread(target=cls.run)
			t.daemon = True
			t.start()
		except Exception:
			cls.running = False

	@classmethod
	def run(cls):
		import json
		try:
			from urllib.request import urlopen
		except ImportError:
			from urllib2 import urlopen
		for url in CATALOGUE_URLS:
			try:
				data = json.loads(urlopen(url, timeout=8).read(65536).decode("utf-8"))
				if isinstance(data, dict) and data.get("format") == 1 and isinstance(data.get("apps"), list):
					cls.data = data
					break
			except Exception as e:
				print("[ObsidianFHD] catalogue %s: %s" % (url, e))
		cls.running = False


def plainChangelog(md):
	# Markdown to plain TV text: "## 1.4.1" -> "VERSION 1.4.1", file title and bold markers removed, bullets as dots.
	import re
	bullet = u"\u00b7 "
	lines = []
	for line in md.replace(u"\r", u"").split(u"\n"):
		if line.startswith(u"# "):
			continue
		if not lines and not line.startswith(u"## "):
			continue  # intro text before the first version
		if line.startswith(u"## "):
			if lines:
				lines.append(u"")
			lines.append(u"VERSION " + line[3:].strip())
			continue
		line = re.sub(r"\*\*([^*]+)\*\*", r"\1", line).replace(u"`", u"")
		if line.lstrip().startswith(u"- "):
			indent = len(line) - len(line.lstrip())
			line = u"    " * (indent // 2) + bullet + line.lstrip()[2:]
		lines.append(line)
	text = u"\n".join(lines).strip()
	try:
		unicode
		return text.encode("utf-8")
	except NameError:
		return text


_screens = None


def appScreens():
	# Screens are defined on first use so that the enigma2 imports happen only when the panel is opened.
	global _screens
	if _screens:
		return _screens
	from Components.ActionMap import ActionMap
	from Components.Label import Label
	from Components.Pixmap import MultiPixmap, Pixmap
	from Tools.LoadPixmap import LoadPixmap

	def setPreview(screen, num):
		# fallback from the skin list, then the pack's own preview over it when that file is installed
		screen["preview"].setPixmapNum(num)
		path = SKIN_DIR + PACK_PREVIEWS[num] if num in PACK_PREVIEWS else None
		pix = None
		if path and exists(path):
			try:
				pix = LoadPixmap(path)
			except Exception:
				pix = None
		widget = screen["packpreview"]
		if pix and widget.instance:
			widget.instance.setPixmap(pix)
			widget.show()
		else:
			widget.hide()
	from Components.ScrollLabel import ScrollLabel
	from Components.Sources.StaticText import StaticText
	from Screens.MessageBox import MessageBox
	from Screens.Screen import Screen

	# Footer hints: up to three slots, each a key chip or colour marker (index into the "pixmaps" list of markN in
	# skin_apps.xml) followed by its text.
	KEY_OK, KEY_EXIT, KEY_UPDOWN, MARK_GREEN, MARK_YELLOW = 0, 1, 2, 3, 4
	MARK_BLUE = 5  # only in the Styles screen's marker list

	def addHintSlots(screen):
		for n in range(3):
			screen["mark%d" % n] = MultiPixmap()
			screen["hint%d" % n] = StaticText("")

	def addSettingSlots(screen):
		screen["rowsel"] = Label("")
		screen["scrolltrack"] = Label("")
		screen["scrollthumb"] = Label("")
		screen["help"] = StaticText("")
		for j in (4, 5):
			screen["rowbg%d" % j] = Label("")
			screen["label%d" % j] = StaticText("")
			for k in ("", "g", "a", "c", "m"):
				screen["value%d%s" % (j, k)] = Label("")

	def hideSettingSlots(screen):
		screen["rowsel"].hide()
		screen["scrolltrack"].hide()
		screen["scrollthumb"].hide()
		for j in (4, 5):
			screen["rowbg%d" % j].hide()

	def setScrollbar(screen, top, total, shown):
		# the track spans the six row slots (446 px); the thumb's size and place follow the visible part of the list
		from enigma import ePoint, eSize
		if total <= shown:
			screen["scrolltrack"].hide()
			screen["scrollthumb"].hide()
			return
		h = max(40, 446 * shown // total)
		y = 354 + (446 - h) * top // (total - shown)
		screen["scrollthumb"].instance.resize(eSize(6, h))
		screen["scrollthumb"].instance.move(ePoint(1814, y))
		screen["scrolltrack"].show()
		screen["scrollthumb"].show()

	def setHints(screen, hints):
		for n in range(3):
			if n < len(hints):
				screen["mark%d" % n].setPixmapNum(hints[n][0])
				screen["mark%d" % n].show()
				screen["hint%d" % n].setText(hints[n][1])
			else:
				screen["mark%d" % n].hide()
				screen["hint%d" % n].setText("")

	def restartPrompt(screen):
		screen.session.openWithCallback(lambda answer: restart(screen, answer), MessageBox, _("Restart the GUI now to apply the changes?"), MessageBox.TYPE_YESNO)

	def restart(screen, answer):
		if answer:
			try:
				from .infobar import sync
				sync()
			except Exception as e:
				print("[ObsidianFHD] infobar selection: %s" % e)
				screen.session.open(MessageBox, _("Unable to apply the infobar style. Check free space and file permissions."), MessageBox.TYPE_ERROR)
				return
			try:
				from Screens.Standby import TryQuitMainloop
				screen.session.open(TryQuitMainloop, 3)
				return
			except Exception as e:
				print("[ObsidianFHD] restart: %s" % e)
		screen.close()

	class ObsidianFHDApps(Screen):
		COLUMNS = 4
		SLOTS = 8  # tiles in skin_apps.xml; slots without an app are hidden (the skin may name more widgets than apps)

		def __init__(self, session):
			Screen.__init__(self, session)
			self.skinName = ["ObsidianFHDApps"]
			self.setTitle(_("Obsidian FHD"))
			self.index = 0
			self.initial = self.states()
			self.latest = ""
			self.polls = 0
			self["heading"] = StaticText(_("Apps"))
			self["summary"] = StaticText("")
			addHintSlots(self)
			for i in range(max(self.SLOTS, len(APPS))):
				app = APPS[i] if i < len(APPS) else None
				self["tile%d" % i] = MultiPixmap()
				self["icon%d" % i] = MultiPixmap()
				self["switch%d" % i] = MultiPixmap()
				for k in "gacm":
					self["status%d%s" % (i, k)] = Label("")
				self["name%d" % i] = StaticText(_(app["name"]) if app else "")
				self["desc%d" % i] = StaticText(_(app["short"]) if app else "")
			self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
				"ok": self.openApp, "cancel": self.exit, "yellow": self.openAppPage,
				"left": lambda: self.move(-1), "right": lambda: self.move(1),
				"up": lambda: self.move(-self.COLUMNS), "down": lambda: self.move(self.COLUMNS),
			}, -2)
			try:
				from enigma import eTimer
				self.updateTimer = eTimer()
				self.updateTimer.callback.append(self.pollUpdate)
			except Exception:
				self.updateTimer = None
			self.onLayoutFinish.append(self.layoutFinished)

		def layoutFinished(self):
			for i, app in enumerate(APPS):
				self["icon%d" % i].setPixmapNum(app["image"])
			for i in range(len(APPS), max(self.SLOTS, len(APPS))):
				for name in ("tile", "icon", "switch", "status%sg", "status%sa", "status%sc", "status%sm"):
					widget = self[name % i if "%s" in name else name + str(i)]
					widget.hide()
			setHints(self, [(KEY_OK, _("Open app")), (KEY_EXIT, _("Close"))])
			Catalogue.start()
			self.refresh()
			self.pollUpdate()

		def pollUpdate(self):
			# The update check runs in a background thread: look for its result once a second, for up to 10 s.
			self.latest = latestVersion()
			if self.latest or Catalogue.data:
				self.refresh()
			if (not self.latest or Catalogue.running) and self.updateTimer and self.polls < 10:
				self.polls += 1
				self.updateTimer.start(1000, True)

		def opensDirectly(self):
			# an app you use rather than configure, installed and current: OK opens it, YELLOW its page
			app = APPS[self.index]
			return bool(app.get("direct")) and appState(app["appId"])[0] == "installed"

		def openAppPage(self):
			if APPS[self.index].get("direct"):
				self.session.openWithCallback(self.appClosed, ObsidianFHDApp, APPS[self.index], self.latest)

		def refresh(self):
			setHints(self, [(KEY_OK, _("Open app")), (MARK_YELLOW, _("Settings")), (KEY_EXIT, _("Close"))] if self.opensDirectly()
				else [(KEY_OK, _("Open app")), (KEY_EXIT, _("Close"))])
			on = off = 0
			for i, app in enumerate(APPS):
				if app["key"] == "about":
					version = skinInfo()[0]
					if self.latest:
						text, col = _("UPDATE v%s") % self.latest, "a"
						self["desc%d" % i].setText(_("A new version is available"))
					else:
						text, col = version, "c"
						self["desc%d" % i].setText(_("Version, update, licence"))
				elif app.get("appId"):
					state, installed, entry = appState(app["appId"])
					text, col = {"installed": (_("INSTALLED"), "g"), "update": (_("UPDATE"), "a"), "download": (_("DOWNLOAD"), "c")}.get(state, ("", None))
				elif app.get("group"):
					menus, chlist = currentStyle(STYLE_SCREENS[0]), currentStyle(STYLE_SCREENS[1])
					text, col = (menus[2].upper() if menus[0] == chlist[0] else _("MIXED")), "c"
				elif app.get("styles"):
					text, col = currentStyle(app)[2].upper(), "c"
				elif isOn(app):
					on += 1
					text, col = "", None
					state = 1 if isAvailable(app) else 2  # switch on, or on with the plugin missing (amber)
				else:
					off += 1
					text, col, state = "", None, 0
				# apps show a toggle switch, About shows its version / update pill
				if app["key"] == "about" or app.get("styles") or app.get("group") or app.get("appId"):
					self["switch%d" % i].hide()
				else:
					self["switch%d" % i].setPixmapNum(state)
					self["switch%d" % i].show()
				colourText(self, "status%d" % i, text, col, "gacm", True)
				self["tile%d" % i].setPixmapNum(1 if i == self.index else 0)
			self["summary"].setText(_("%d on  -  %d off") % (on, off))

		def move(self, step):
			target = self.index + step
			if 0 <= target < len(APPS):
				self.index = target
			elif step == 1 or step == -1:
				return
			else:
				self.index = len(APPS) - 1 if step > 0 else self.index
			self.refresh()

		def openApp(self):
			if self.opensDirectly():
				try:
					from importlib import import_module
					import_module(APP_PACKAGES[APPS[self.index]["appId"]]["module"]).openScreen(self.session, False)
					return
				except Exception as e:  # a broken app must still reach its page, for update or removal
					print("[ObsidianFHD] open %s: %s" % (APPS[self.index]["appId"], e))
			if APPS[self.index]["key"] == "clock":
				try:
					from .clock import ObsidianClockSettings
					self.session.openWithCallback(self.appClosed, ObsidianClockSettings)
				except Exception as e:
					print("[ObsidianFHD] clock open: %s" % e)
					self.session.open(MessageBox, _("Clock settings could not open.") + "\n" + str(e), MessageBox.TYPE_ERROR)
				return
			if APPS[self.index].get("group"):
				self.session.openWithCallback(self.appClosed, ObsidianFHDStyles)
				return
			self.session.openWithCallback(self.appClosed, ObsidianFHDApp, APPS[self.index], self.latest)

		def states(self):
			return [currentStyle(app)[0] if app.get("styles") else isOn(app) for app in APPS if app.get("flag") or app.get("styles")] + \
				[currentStyle(app)[0] for app in STYLE_SCREENS] + [currentStyle(INFOBAR_APP)[0], novaColours()]

		def appClosed(self, changed=False):
			if changed == "installed":
				self.installed = True
			self.refresh()

		def exit(self):
			# Ask for a restart only if a setting really differs from when the panel was opened.
			if self.states() != self.initial or getattr(self, "installed", False):
				restartPrompt(self)
			else:
				self.close()

	class ObsidianFHDApp(Screen):
		def __init__(self, session, app, latest=""):
			Screen.__init__(self, session)
			self.skinName = ["ObsidianFHDApp"]
			self.setTitle(_("Obsidian FHD"))
			self.app = app
			self.latest = latest
			self.changed = False
			self.about = app["key"] == "about"
			self.installing = False
			self.installed = False
			self.container = None
			self.packBusy = ""  # "download" / "remove" while opkg runs for a style pack
			self.view = currentStyle(app)[0] if app.get("styles") else None  # style shown (may be a pack not installed yet)
			self["crumb"] = StaticText((_("APPS") + "  >  " + _(app["name"])).upper())
			self["icon"] = MultiPixmap()
			self["preview"] = MultiPixmap()
			self["packpreview"] = Pixmap()
			self["button"] = MultiPixmap()
			self["buttonTextDark"] = Label("")
			self["buttonTextLight"] = Label("")
			self["name"] = StaticText(_(app.get("page", app["name"])))
			self["desc"] = StaticText(_(app["desc"]))
			self["note"] = StaticText("")
			addHintSlots(self)
			self["previewLabel"] = StaticText(_("PREVIEW"))
			self["detailsLabel"] = StaticText(_("DETAILS"))
			for j in range(4):
				self["label%d" % j] = StaticText("")
				for k in ("", "g", "a", "c", "m"):
					self["value%d%s" % (j, k)] = Label("")
			addSettingSlots(self)
			self.row = 0  # selected settings row (apps with settings)
			self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
				"ok": self.ok, "green": self.press, "cancel": self.exit, "red": self.exit,
				"yellow": self.yellow, "left": lambda: self.cycle(-1), "right": lambda: self.cycle(1),
				"up": lambda: self.moveRow(-1), "down": lambda: self.moveRow(1),
			}, -2)
			self.onLayoutFinish.append(self.layoutFinished)

		def layoutFinished(self):
			hideSettingSlots(self)
			self["icon"].setPixmapNum(self.app["image"])
			self.showAppPreview()
			if self.app.get("appId"):
				Catalogue.start()
				self.catalogueTries = 0
				try:
					from enigma import eTimer
					self.catalogueTimer = eTimer()
					self.catalogueTimer.callback.append(self.pollCatalogue)
					self.catalogueTimer.start(1000, False)
				except Exception:
					self.catalogueTimer = None
			self.refresh()

		def pollCatalogue(self):
			self.catalogueTries += 1
			if not Catalogue.running or self.catalogueTries > 12:
				self.catalogueTimer.stop()
			self.refresh()

		def setRow(self, j, label, value, col=""):
			self["label%d" % j].setText(label)
			colourText(self, "value%d" % j, value, col)

		def setButton(self, text, primary):
			self["button"].setPixmapNum(0 if primary else 1)
			colourText(self, "buttonText", text, "Dark" if primary else "Light", ("Dark", "Light"))

		def viewStyle(self):
			for st in self.app["styles"]:
				if st[0] == self.view:
					return st
			return currentStyle(self.app)

		def refresh(self):
			if self.app.get("appId"):
				self.refreshApp()
				return
			if self.app.get("styles"):
				style = self.viewStyle()
				pack = packOf(style)
				setPreview(self, style[3])
				names = []
				for st in self.app["styles"]:
					names.append(st[2] if styleUsable(st) else st[2] + " (" + _("download") + ")")
				self.setRow(1, _("Styles"), "  /  ".join(names))
				self.setRow(3, _("Applies"), _("After a GUI restart"))
				if self.packBusy:
					self.setRow(0, _("Style"), _("Downloading...") if self.packBusy == "download" else _("Removing..."), "a")
					self.setRow(2, _("Uses"), _("Internet, %s") % PACKS[pack]["size"] if pack else _("Nothing extra"))
					setHints(self, [])  # no keys while opkg runs (EXIT waits for it)
					return
				if pack and not packInstalled(pack):
					self.setRow(0, _("Style"), style[2] + " - " + _("not installed"), "a")
					self.setRow(2, _("Uses"), _("Download, %s") % PACKS[pack]["size"])
					self["note"].setText(_("%s is a style pack. It is downloaded once and applies to menus, settings pages and channel list together.") % style[2])
					self.setButton(_("Download"), True)
					setHints(self, [(MARK_GREEN, _("Download")), (KEY_EXIT, _("Back to apps"))])
					return
				current = style[0] == currentStyle(self.app)[0]
				self.setRow(0, _("Style"), style[2] if current else style[2] + " - " + _("not selected"), "c" if current else "m")
				self.setRow(2, _("Uses"), _("Style pack, %s") % PACKS[pack]["size"] if pack else _("Built in"))
				if pack:
					self["note"].setText(_("%s applies to menus, settings pages and channel list together. YELLOW removes the pack.") % style[2])
				else:
					self["note"].setText(_(self.app["note"]))
				if current:
					self.setButton(_("Next style"), True)
				else:
					self.setButton(_("Use %s") % style[2], True)
				hints = [(MARK_GREEN, _("Change style") if current else _("Use %s") % style[2])]
				if pack:
					hints.append((MARK_YELLOW, _("Remove pack")))
				setHints(self, hints + [(KEY_EXIT, _("Back to apps"))])
				return
			if self.about:
				version, image = skinInfo()
				self.setRow(0, _("Version"), version or "-", "c")
				self.setRow(1, _("Receiver"), image or "-")
				if self.latest:
					self.setRow(2, _("Update"), _("v%s available") % self.latest, "a")
					self.setButton(_("Update now"), True)
					setHints(self, [(MARK_GREEN, _("Update now")), (MARK_YELLOW, _("What's new")), (KEY_EXIT, _("Back to apps"))])
				else:
					self.setRow(2, _("Update"), _("Up to date"), "g")
					self.setButton(_("Up to date"), False)
					setHints(self, [(MARK_YELLOW, _("What's new")), (KEY_EXIT, _("Back to apps"))])
				self.setRow(3, _("Licence"), "CC BY-NC-SA 4.0")
				self["note"].setText("github.com/dali44g/Obsidian-FHD")
				return
			on = isOn(self.app)
			available = isAvailable(self.app)
			if self.installing:
				self.setRow(0, _("Status"), _("Installing..."), "a")
				self.setRow(1, _("Needs"), _(self.app["needsText"]), "a")
				setHints(self, [])  # no keys while opkg runs (EXIT waits for it)
				return
			if on and available:
				status, col = _("On"), "g"
			elif on:
				status, col = _("On - waiting for the plugin"), "a"
			else:
				status, col = _("Off"), "m"
			self.setRow(0, _("Status"), status, col)
			needsCol = "" if available else "a"
			needs = _(self.app["needsText"]) if available or not self.app["needs"] else _(self.app["needsText"]) + " - " + _("not installed")
			self.setRow(1, _("Needs"), needs, needsCol)
			self.setRow(2, _("Uses"), _(self.app["usesText"]))
			self.setRow(3, _("Applies"), _("After a GUI restart"))
			self["note"].setText(_("Installed - restart the GUI to apply") if self.installed and available else _(self.app["note"]))
			self.setButton(_("Turn off") if on else _("Turn on"), not on)
			if self.canInstall():
				setHints(self, [(MARK_GREEN, _("Turn on / off")), (MARK_YELLOW, _("Install plugin")), (KEY_EXIT, _("Back to apps"))])
			else:
				setHints(self, [(MARK_GREEN, _("Turn on / off")), (KEY_EXIT, _("Back to apps"))])

		def appSettings(self):
			# the settings API of an installed app (None when absent or broken: the page shows the details instead)
			if not appVersion(self.app["appId"]) or self.packBusy:
				return None
			try:
				from importlib import import_module
				screens = import_module(APP_PACKAGES[self.app["appId"]]["module"])
				screens.settingRows()
				return screens
			except Exception as e:
				print("[ObsidianFHD] %s settings: %s" % (self.app["appId"], e))
				return None

		def refreshSettings(self, api):
			from enigma import ePoint
			rows = api.settingRows()
			self.row = max(0, min(self.row, len(rows) - 1))
			# six rows on screen; longer lists scroll with the selection
			top = min(max(0, self.row - 5), max(0, len(rows) - 6))
			for j in range(6):
				k = top + j
				if k < len(rows):
					self.setRow(j, rows[k]["label"], rows[k]["value"], "c" if k == self.row else "")
				else:
					self.setRow(j, "", "")
			for j in (4, 5):
				if top + j < len(rows):
					self["rowbg%d" % j].show()
				else:
					self["rowbg%d" % j].hide()
			self["rowsel"].instance.move(ePoint(1080, 354 + 76 * (self.row - top)))
			self["rowsel"].show()
			setScrollbar(self, top, len(rows), 6)
			self["note"].setText("")
			self["help"].setText(rows[self.row]["help"] if rows else "")
			self["desc"].setText(api.statusText())
			state, installed, entry = appState(self.app["appId"])
			more = (_("Update, Display mode") if self.app.get("display") else _("Update")) if state == "update" else _("More")
			ok = _("Change") if rows and rows[self.row]["kind"] == "action" else _("Open")
			self.setButton(_("Open"), True)
			setHints(self, [(KEY_OK, ok), (MARK_YELLOW, more), (KEY_EXIT, _("Back to apps"))])

		def ok(self):
			api = self.appSettings() if self.app.get("appId") else None
			if api:
				rows = api.settingRows()
				if rows and rows[self.row]["kind"] == "action":
					self.action = api.SettingAction(self.session, rows[self.row]["key"], self.refresh)
					return
			self.press()

		def moveRow(self, step):
			api = self.appSettings() if self.app.get("appId") else None
			if api:
				self.row = (self.row + step) % len(api.settingRows())
				self.refresh()

		def refreshApp(self):
			key = self.app["appId"]
			api = self.appSettings()
			if api:
				try:
					self.refreshSettings(api)
					return
				except Exception as e:
					print("[ObsidianFHD] %s settings page: %s" % (key, e))
			hideSettingSlots(self)
			self["help"].setText("")
			self["desc"].setText(_(self.app["desc"]))
			for j in (4, 5):
				self.setRow(j, "", "")
			state, installed, entry = appState(key)
			self.setRow(1, _("Uses"), _(self.app.get("uses", "Internet")))
			self.setRow(2, _("Size"), (_("%d KB") % int(entry.get("installedKb", 0))) if entry else "-")
			self.setRow(3, _("Needs"), (_("Obsidian FHD %s or newer") % entry["minCore"]) if entry and entry.get("minCore") else "Obsidian FHD")
			self["note"].setText(_(self.app["note"]))
			if self.packBusy:
				self.setRow(0, _("Status"), _("Downloading...") if self.packBusy == "download" else _("Removing..."), "a")
				setHints(self, [])  # no keys while opkg runs (EXIT waits for it)
				return
			if state == "installed":
				self.setRow(0, _("Status"), _("Installed - v%s") % installed, "g")
			elif state == "update":
				self.setRow(0, _("Status"), _("v%s - update v%s available") % (installed, entry["version"]), "a")
			elif state == "download":
				self.setRow(0, _("Status"), _("Not installed - v%s available") % entry["version"], "c")
			else:
				self.setRow(0, _("Status"), _("Checking...") if Catalogue.running else _("Not installed - catalogue unreachable"), "m")
			if installed:
				self.setButton(_("Open"), True)
				setHints(self, [(MARK_GREEN, _("Open")), (MARK_YELLOW, _("More")), (KEY_EXIT, _("Back to apps"))])
			elif state == "download":
				self.setButton(_("Download"), True)
				setHints(self, [(MARK_GREEN, _("Download")), (KEY_EXIT, _("Back to apps"))])
			else:
				self.setButton(_("Download"), False)
				setHints(self, [(KEY_EXIT, _("Back to apps"))])

		def appPress(self):
			state, installed, entry = appState(self.app["appId"])
			if self.packBusy:
				return
			if installed:
				self.openInstalledApp(False)
			elif state == "download":
				minCore = entry.get("minCore", "")
				if minCore and versionTuple(skinInfo()[0]) < versionTuple(minCore):
					self.session.open(MessageBox, _("Update Obsidian FHD first (About & update): %s needs version %s.") % (self.app["name"], minCore), MessageBox.TYPE_INFO)
					return
				self.session.openWithCallback(lambda answer: self.runApp(answer, "install"), MessageBox,
					_("Download %s (%d KB)?") % (self.app["name"], int(entry.get("installedKb", 0))), MessageBox.TYPE_YESNO)

		def appMore(self):
			state, installed, entry = appState(self.app["appId"])
			if not installed or self.packBusy:
				return
			from Screens.ChoiceBox import ChoiceBox
			items = [(_("Start Display mode"), "display")] if self.app.get("display") else []
			if state == "update":
				items.append((_("Update to v%s") % entry["version"], "update"))
			items.append((_("Remove %s") % self.app["name"], "remove"))
			self.session.openWithCallback(self.appChoice, ChoiceBox, title=self.app["name"], list=items)

		def appChoice(self, choice):
			if not choice:
				return
			if choice[1] == "display":
				self.openInstalledApp(True)
			elif choice[1] == "update":
				self.runApp(True, "install")
			elif choice[1] == "remove":
				self.session.openWithCallback(lambda answer: self.runApp(answer, "remove"), MessageBox,
					_("Remove %s and its settings?") % self.app["name"], MessageBox.TYPE_YESNO)

		def openInstalledApp(self, display):
			try:
				from importlib import import_module
				import_module(APP_PACKAGES[self.app["appId"]]["module"]).openScreen(self.session, display)
			except Exception as e:
				print("[ObsidianFHD] open %s: %s" % (self.app["appId"], e))
				self.session.open(MessageBox, _("%s could not open. Restart the GUI and try again.") % self.app["name"], MessageBox.TYPE_ERROR)

		def runApp(self, answer, action):
			if not answer or self.packBusy:
				return
			key = self.app["appId"]
			entry = appEntry(key)
			if action == "install":
				if not entry:
					return
				if 0 <= freeSpaceMB() < 10:
					self.session.open(MessageBox, _("Not enough free space on the receiver to install %s.") % self.app["name"], MessageBox.TYPE_ERROR)
					return
			cmd = appCommand(key, action, entry)
			if not cmd:
				self.session.open(MessageBox, _("The app catalogue is not valid. Try again later."), MessageBox.TYPE_ERROR)
				return
			try:
				from enigma import eConsoleAppContainer
				self.container = eConsoleAppContainer()
				self.container.appClosed.append(lambda retval: self.appDone(retval, action))
				self.packBusy = "download" if action == "install" else "remove"
				self.refresh()
				if self.container.execute("/bin/sh", "/bin/sh", "-c", cmd):
					self.appDone(-1, action)
			except Exception as e:
				print("[ObsidianFHD] app %s %s: %s" % (key, action, e))
				self.packBusy = ""
				self.refresh()

		def appDone(self, retval, action):
			self.packBusy = ""
			self.container = None
			installed = appVersion(self.app["appId"])
			if action == "install" and (retval != 0 or not installed):
				print("[ObsidianFHD] app install failed (%s)" % retval)
				self.session.open(MessageBox, _("Download failed or the file did not match the catalogue. Nothing was changed."), MessageBox.TYPE_ERROR)
			elif action == "remove" and installed:
				self.session.open(MessageBox, _("%s could not be removed.") % self.app["name"], MessageBox.TYPE_ERROR)
			else:
				self.installed = True  # a GUI restart starts (or stops) the app's background service
			self.refresh()

		def canInstall(self):
			return bool(self.app.get("package")) and not isAvailable(self.app) and not self.installing

		def yellow(self):
			if self.app.get("appId"):
				self.appMore()
				return
			if self.app.get("styles"):
				pack = packOf(self.viewStyle())
				if pack and packInstalled(pack) and not self.packBusy:
					self.session.openWithCallback(lambda answer: self.runPack(answer, pack, "remove"), MessageBox,
						_("Remove the %s style pack? Screens using it go back to Classic.") % PACKS[pack]["name"], MessageBox.TYPE_YESNO)
				return
			if self.about:
				self.whatsNew()
			elif self.canInstall():
				if 0 <= freeSpaceMB() < 10:
					self.session.open(MessageBox, _("Not enough free space on the receiver to install the plugin."), MessageBox.TYPE_ERROR)
					return
				self.session.openWithCallback(self.confirmInstall, MessageBox, _("Install %s now?") % _(self.app["needsText"]), MessageBox.TYPE_YESNO)

		def confirmInstall(self, answer):
			# Runs opkg in the background (the page stays usable); the package list is refreshed only when needed.
			if not answer or self.installing:
				return
			pkg = self.app["package"]
			cmd = "opkg install %s || (opkg update && opkg install %s)" % (pkg, pkg)
			try:
				from enigma import eConsoleAppContainer
				self.container = eConsoleAppContainer()
				self.container.appClosed.append(self.installDone)
				self.installing = True
				self.refresh()
				if self.container.execute("/bin/sh", "/bin/sh", "-c", cmd):
					self.installDone(-1)
			except Exception as e:
				print("[ObsidianFHD] install %s: %s" % (pkg, e))
				self.installing = False
				self.refresh()

		def installDone(self, retval):
			self.installing = False
			self.container = None
			if isAvailable(self.app):
				self.installed = True
			else:
				print("[ObsidianFHD] install %s failed (%s)" % (self.app["package"], retval))
				self.session.open(MessageBox, _("Installation failed. Check the internet connection and try again."), MessageBox.TYPE_ERROR)
			self.refresh()

		def showAppPreview(self):
			# an app may show the preview of its current mode (Posters: in the infobar, slide-in card, film card)
			num = self.app.get("preview", self.app["image"])
			try:
				api = self.appSettings() if self.app.get("previews") else None
				if api and hasattr(api, "previewKey"):
					num = self.app["previews"].get(api.previewKey(), num)
			except Exception as e:
				print("[ObsidianFHD] app preview: %s" % e)
			setPreview(self, num)

		def cycle(self, step):
			if self.app.get("appId"):
				api = self.appSettings()
				if api:
					rows = api.settingRows()
					if rows and rows[self.row]["kind"] == "choice":
						api.changeSetting(rows[self.row]["key"], step)
						self.showAppPreview()
						self.refresh()
				return
			# LEFT / RIGHT: show the previous / next style; built-in styles and installed packs apply at once,
			# a pack that is not installed is only shown (GREEN downloads it).
			styles = self.app.get("styles")
			if not styles or self.packBusy:
				return
			keys = [st[0] for st in styles]
			self.view = keys[(keys.index(self.view) + step) % len(keys)]
			target = self.viewStyle()
			if styleUsable(target) and target[0] != currentStyle(self.app)[0]:
				self.apply(target[0])
			else:
				self.refresh()

		def apply(self, key):
			old = currentStyle(self.app)
			oldPack = packOf(old)
			if oldPack and packOf([st for st in self.app["styles"] if st[0] == key][0]) != oldPack and len(packApps(oldPack)) > 1:
				self.session.openWithCallback(lambda answer: self.applyConfirmed(answer, key), MessageBox,
					_("Leave %s for all screens?") % PACKS[oldPack]["name"], MessageBox.TYPE_YESNO)
				return
			self.applyConfirmed(True, key)

		def applyConfirmed(self, answer, key):
			if not answer:
				self.view = currentStyle(self.app)[0]
				self.refresh()
				return
			if not setStyle(self.app, key):
				self.session.open(MessageBox, _("Unable to apply the style. Check free space and file permissions."), MessageBox.TYPE_ERROR)
				return
			self.view = currentStyle(self.app)[0]
			self.changed = True
			self.refresh()

		def runPack(self, answer, pack, action):
			# Runs in the background like the plugin install; the page stays open.
			if not answer or self.packBusy:
				return
			name = PACKS[pack]["package"]
			if action == "download":
				if 0 <= freeSpaceMB() < 10:
					self.session.open(MessageBox, _("Not enough free space on the receiver to download the style pack."), MessageBox.TYPE_ERROR)
					return
				cmd = packCommand(pack, "download")  # same safe download as the Styles app (own folder, time limits)
			else:
				# screens using the pack go back to Classic first, so the next start never needs the removed files
				for other in packApps(pack):
					if packOf(currentStyle(other)) == pack:
						writeStyleFlags(other, fallbackStyle(other))
				self.changed = True
				cmd = packCommand(pack, "remove")
			try:
				from enigma import eConsoleAppContainer
				self.container = eConsoleAppContainer()
				self.container.appClosed.append(lambda retval: self.packDone(retval, pack, action))
				self.packBusy = action
				self.refresh()
				if self.container.execute("/bin/sh", "/bin/sh", "-c", cmd):
					self.packDone(-1, pack, action)
			except Exception as e:
				print("[ObsidianFHD] pack %s %s: %s" % (action, name, e))
				self.packBusy = ""
				self.refresh()

		def packDone(self, retval, pack, action):
			self.packBusy = ""
			self.container = None
			if action == "download":
				if retval == 0 and packInstalled(pack):
					self.installed = True
					self.applyConfirmed(True, [st for st in self.app["styles"] if packOf(st) == pack][0][0])
					return
				self.session.open(MessageBox, packFailMessage(pack, retval), MessageBox.TYPE_ERROR)
			elif packInstalled(pack):
				print("[ObsidianFHD] pack remove %s failed (%s)" % (pack, retval))
				self.session.open(MessageBox, _("The style pack could not be removed."), MessageBox.TYPE_ERROR)
			self.view = currentStyle(self.app)[0]
			self.refresh()

		def press(self):
			if self.app.get("appId"):
				self.appPress()
				return
			if self.app.get("styles"):
				if self.packBusy:
					return
				style = self.viewStyle()
				pack = packOf(style)
				if pack and not packInstalled(pack):
					if self.latest:
						self.session.open(MessageBox, _("Update Obsidian FHD first (About & update), then download %s.") % style[2], MessageBox.TYPE_INFO)
						return
					self.session.openWithCallback(lambda answer: self.runPack(answer, pack, "download"), MessageBox,
						_("Download the %s style pack (%s)?") % (style[2], PACKS[pack]["size"]), MessageBox.TYPE_YESNO)
				elif style[0] != currentStyle(self.app)[0]:
					self.apply(style[0])
				else:
					self.cycle(1)
				return
			if self.about:
				if self.latest:
					self.session.openWithCallback(self.confirmUpdate, MessageBox, _("Install Obsidian FHD v%s now?") % self.latest, MessageBox.TYPE_YESNO)
				return
			setOn(self.app, not isOn(self.app))
			self.changed = not self.changed
			self.refresh()

		def whatsNew(self):
			if self.about:
				self.session.open(ObsidianFHDChangelog)

		def confirmUpdate(self, answer):
			if answer:
				try:
					from Screens.Console import Console
					self.session.openWithCallback(self.updated, Console, title=_("Updating Obsidian FHD"), cmdlist=[INSTALL_CMD])
				except Exception as e:
					print("[ObsidianFHD] update: %s" % e)

		def updated(self, *args):
			restartPrompt(self)

		def exit(self):
			if self.installing or self.packBusy:
				return  # wait for opkg to finish
			if getattr(self, "catalogueTimer", None):
				self.catalogueTimer.stop()
			self.close("installed" if self.installed else self.changed)

	class ObsidianFHDStyles(Screen):
		# Grid of 4 columns (layout from tools/styles-screen.py): the Customise card first, then one card per style.
		# Styles are only browsed and downloaded here; they are chosen on the Customise page. OK on a style opens
		# Customise with it pre-selected (a pack that is not installed opens its download page first); BLUE opens
		# Customise as saved. One row is visible and the tops of the next row peek out (a short background and a
		# cropped preview, since widgets are not clipped); moving to another row scrolls by moving the card widgets.
		COLS, PITCH, CARD_H, PEEK_H, ROWS_SHOWN = 4, 468, 448, 214, 1.4

		def __init__(self, session):
			Screen.__init__(self, session)
			self.skinName = ["ObsidianFHDStyles"]
			self.setTitle(_("Obsidian FHD"))
			self.index = 0  # 0 = Customise card, 1.. = STYLES
			self.top = 0  # first visible row
			self.changed = False
			self["crumb"] = StaticText((_("APPS") + "  >  " + _("Styles")).upper())
			self["heading"] = StaticText(_("Styles"))
			self["summary"] = StaticText("")
			addHintSlots(self)
			self["ccard"] = Label("")
			self["cbg"] = Pixmap()
			self["cname"] = Label(_("Customise"))
			self["cdesc"] = Label(_("Style, menus, channel list and infobar on one page."))
			self["copen"] = Label(_("Open").upper() + "  >")
			self["cpeek"] = Pixmap()
			# per card: all widgets, the background (shortened while peeking), the peek image, the always-shown parts
			self.widgets = [["ccard", "cbg", "cname", "cdesc", "copen", "cpeek"]]
			self.cardBg, self.peek, self.static = [None], ["cpeek"], [("cbg", "cname", "cdesc", "copen")]
			for i, (key, name, desc, preview) in enumerate(STYLES):
				self["cardbg%d" % i] = Label("")
				self["card%d" % i] = Label("")
				self["prev%d" % i] = Pixmap()
				self["peek%d" % i] = Pixmap()
				self["name%d" % i] = Label(_(name))
				self["desc%d" % i] = Label(_(desc))
				self["inuse%d" % i] = Pixmap()
				names = ["cardbg%d" % i, "card%d" % i, "prev%d" % i, "peek%d" % i, "inuse%d" % i, "name%d" % i, "desc%d" % i]
				self.cardBg.append("cardbg%d" % i)
				self.peek.append("peek%d" % i)
				self.static.append(("cardbg%d" % i, "prev%d" % i, "name%d" % i, "desc%d" % i))
				for k in "cmg":
					self["badge%d%s" % (i, k)] = Label("")
					names.append("badge%d%s" % (i, k))
				for comp, text in STYLE_COMPONENTS:
					self["comp%d%son" % (i, comp)] = Label(_(text))
					self["comp%d%soff" % (i, comp)] = Label(_(text))
					names += ["comp%d%son" % (i, comp), "comp%d%soff" % (i, comp)]
				self.widgets.append(names)
			self["strack"] = Label("")
			self["sthumb"] = Label("")
			self.home = {}
			self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
				"ok": self.open, "cancel": self.exit, "red": self.exit, "blue": self.customise,
				"left": lambda: self.move(-1), "right": lambda: self.move(1),
				"up": lambda: self.move(-self.COLS), "down": lambda: self.move(self.COLS),
			}, -2)
			self.onLayoutFinish.append(self.layoutFinished)

		def layoutFinished(self):
			# skin positions are for the first rows; scrolling moves every widget of a card up by whole rows
			for names in self.widgets:
				for name in names:
					pos = self[name].instance.position()
					self.home[name] = (pos.x(), pos.y())
			self.refresh()

		def rows(self):
			return (len(self.widgets) + self.COLS - 1) // self.COLS

		def refresh(self):
			from enigma import ePoint, eSize
			for i, (key, name, desc, preview) in enumerate(STYLES):
				self["card%d" % i].setVisible(i + 1 == self.index)
				pack = PACKS.get(key)
				self["inuse%d" % i].setVisible(any(currentStyle(a)[0] == key for a in styleApps(key)))
				if pack is None:
					colourText(self, "badge%d" % i, _("BUILT IN"), "m", "cmg", True)
				elif packInstalled(key):
					colourText(self, "badge%d" % i, _("INSTALLED"), "g", "cmg", True)
				else:
					colourText(self, "badge%d" % i, _("DOWNLOAD %s") % pack["size"], "c", "cmg", True)
				# badges of the parts this style has: filled when in use, outlined when only available
				for comp, text in STYLE_COMPONENTS:
					app = {"menu": STYLE_SCREENS[0], "chlist": STYLE_SCREENS[1], "infobar": INFOBAR_APP}[comp]
					has = any(st[0] == key for st in app["styles"])
					used = has and currentStyle(app)[0] == key
					self["comp%d%son" % (i, comp)].setVisible(used)
					self["comp%d%soff" % (i, comp)].setVisible(has and not used)
			self["ccard"].setVisible(self.index == 0)
			menus, chlist = currentStyle(STYLE_SCREENS[0]), currentStyle(STYLE_SCREENS[1])
			self["summary"].setText("%s: %s  -  %s: %s" % (_("Menus"), _(menus[2]), _("Channel list"), _(chlist[2])))
			# scroll: the focused row is always fully visible
			row = self.index // self.COLS
			if row < self.top or row > self.top:
				self.top = row
			for n, names in enumerate(self.widgets):
				r = n // self.COLS - self.top  # 0: the visible row, 1: the row peeking out
				for name in names:
					x, y = self.home[name]
					self[name].instance.move(ePoint(x, y - self.top * self.PITCH))
					if r == 0 and name in self.static[n]:
						self[name].show()
					elif r != 0 and name != self.cardBg[n] and not (r == 1 and name == self.peek[n]):
						self[name].hide()
				if self.cardBg[n]:
					self[self.cardBg[n]].instance.resize(eSize(404, self.CARD_H if r == 0 else self.PEEK_H))
					self[self.cardBg[n]].setVisible(r in (0, 1))
				self[self.peek[n]].setVisible(r == 1)
				if r == 1 and n:
					self["card%d" % (n - 1)].hide()
			if self.rows() > 1:
				h = int(672 * min(1.0, self.ROWS_SHOWN / self.rows()))
				self["sthumb"].instance.resize(eSize(4, h))
				self["sthumb"].instance.move(ePoint(1812, 248 + (672 - h) * self.top // (self.rows() - 1)))
				self["strack"].show()
				self["sthumb"].show()
			else:
				self["strack"].hide()
				self["sthumb"].hide()
			if self.index == 0:
				setHints(self, [(KEY_OK, _("Customise")), (KEY_EXIT, _("Back to apps"))])
				return
			key = STYLES[self.index - 1][0]
			if key in PACKS and not packInstalled(key):
				setHints(self, [(KEY_OK, _("Download")), (MARK_BLUE, _("Customise")), (KEY_EXIT, _("Back to apps"))])
			elif key in PACKS:
				setHints(self, [(KEY_OK, _("Details")), (MARK_BLUE, _("Customise")), (KEY_EXIT, _("Back to apps"))])
			else:
				setHints(self, [(KEY_OK, _("Choose")), (MARK_BLUE, _("Customise")), (KEY_EXIT, _("Back to apps"))])

		def move(self, step):
			total = len(self.widgets)
			if step in (-1, 1):
				self.index = (self.index + step) % total
			elif step > 0:
				# down: the card below, or the last card when the next row is shorter
				if self.index // self.COLS < self.rows() - 1:
					self.index = min(self.index + step, total - 1)
			elif self.index + step >= 0:
				self.index += step
			self.refresh()

		def open(self):
			if self.index == 0:
				self.customise()
				return
			key = STYLES[self.index - 1][0]
			if key in PACKS:
				# a style pack: its own page only downloads / removes it; styles are chosen in Customise
				self.session.openWithCallback(self.pageClosed, ObsidianFHDStylePage, key)
			else:
				self.customise(key)

		def customise(self, preset=None):
			self.session.openWithCallback(self.pageClosed, ObsidianFHDLook, preset)

		def pageClosed(self, result=False):
			if isinstance(result, tuple):
				# the download page finished: continue on Customise with that style pre-selected
				self.changed = self.changed or result[2]
				self.refresh()
				self.customise(result[1])
				return
			if result:
				self.changed = True
			self.refresh()

		def exit(self):
			self.close(self.changed)

	class ObsidianFHDStylePage(Screen):
		# Page of a style pack in the app page layout (skin "ObsidianFHDApp"): preview, details, Download / Remove.
		# Nothing is chosen here: styles (and the Nova colours) are set in Customise.
		TARGETS = ("both", "menus", "chlist")

		def __init__(self, session, key):
			Screen.__init__(self, session)
			self.skinName = ["ObsidianFHDApp"]
			self.setTitle(_("Obsidian FHD"))
			addSettingSlots(self)
			self.key = key
			self.style = [st for st in STYLES if st[0] == key][0]
			self.pack = key if key in PACKS else None
			self.changed = False
			self.busy = ""
			self.container = None
			self.target = 0
			self["crumb"] = StaticText((_("APPS") + "  >  " + _("Styles") + "  >  " + _(self.style[1])).upper())
			self["icon"] = MultiPixmap()
			self["preview"] = MultiPixmap()
			self["packpreview"] = Pixmap()
			self["button"] = MultiPixmap()
			self["buttonTextDark"] = Label("")
			self["buttonTextLight"] = Label("")
			self["name"] = StaticText(_(self.style[1]))
			self["desc"] = StaticText(_(self.style[2]))
			self["note"] = StaticText("")
			addHintSlots(self)
			self["previewLabel"] = StaticText(_("PREVIEW"))
			self["detailsLabel"] = StaticText(_("DETAILS"))
			for j in range(4):
				self["label%d" % j] = StaticText("")
				for k in ("", "g", "a", "c", "m"):
					self["value%d%s" % (j, k)] = Label("")
			self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
				"ok": self.press, "green": self.press, "cancel": self.exit, "red": self.exit, "yellow": self.yellow,
				"left": lambda: self.cycle(-1), "right": lambda: self.cycle(1),
			}, -2)
			self.onLayoutFinish.append(self.layoutFinished)

		def layoutFinished(self):
			hideSettingSlots(self)  # the app page layout's settings rows are not used here
			self["icon"].setPixmapNum(2)
			setPreview(self, self.style[3])
			self.refresh()

		def setRow(self, j, label, value, col=""):
			self["label%d" % j].setText(label)
			colourText(self, "value%d" % j, value, col)

		def setButton(self, text, primary):
			self["button"].setPixmapNum(0 if primary else 1)
			colourText(self, "buttonText", text, "Dark" if primary else "Light", ("Dark", "Light"))

		def refresh(self):
			installed = self.pack is None or packInstalled(self.pack)
			menus, chlist = styleUse(self.key)
			used = (menus and chlist and _("Menus and channel list")) or (menus and _("Menus")) or (chlist and _("Channel list")) or _("Not used")
			self.setRow(1, _("Used for"), used, "g" if (menus or chlist) else "m")
			self.setRow(3, _("Applies"), _("After a GUI restart"))
			if self.busy:
				self.setRow(0, _("Status"), _("Downloading...") if self.busy == "download" else _("Removing..."), "a")
				self.setRow(2, _("Size"), PACKS[self.pack]["size"])
				setHints(self, [])  # no keys while opkg runs (EXIT waits for it)
				return
			if self.pack is None:
				self.setRow(0, _("Status"), _("Built in"), "c")
				target = self.TARGETS[self.target]
				names = {"both": _("Menus and channel list"), "menus": _("Menus only"), "chlist": _("Channel list only")}
				self.setRow(2, _("Use for"), "<  %s  >" % names[target], "c")
				self["note"].setText(_("LEFT / RIGHT chooses where to use it; GREEN applies. Menus and channel list can use different built-in styles."))
				done = (menus, chlist) == ((True, True) if target == "both" else (True, chlist) if target == "menus" else (menus, True))
				self.setButton(_("In use") if done else _("Use it"), not done)
				setHints(self, [(MARK_GREEN, _("Use it")), (KEY_EXIT, _("Back"))])
				return
			self.setRow(2, _("Size"), PACKS[self.pack]["size"])
			if not installed:
				self.setRow(0, _("Status"), _("Not installed"), "a")
				self["note"].setText(_("%s is a style pack: it is downloaded once and applies to menus, settings pages and channel list together.") % _(self.style[1]))
				self.setButton(_("Download"), True)
				setHints(self, [(MARK_GREEN, _("Download")), (KEY_EXIT, _("Back"))])
				return
			self.setRow(0, _("Status"), _("Installed"), "g")
			self["note"].setText(_("%s is installed. Choose where it is used in Styles > Customise. YELLOW removes the pack.") % _(self.style[1]))
			if self.pack == "nova":
				setPreview(self, NOVAO_PREVIEWS["infobar"] if novaColours() == "obsidian" else self.style[3])
				self.setRow(1, _("Used for"), _("Channel list and infobar") if styleUsedEverywhere("nova") else _("Not used"), "g" if styleUsedEverywhere("nova") else "m")
			self.setButton(_("Installed"), False)
			setHints(self, [(MARK_YELLOW, _("Remove pack")), (KEY_EXIT, _("Back"))])

		def cycle(self, step):
			if self.pack is None and not self.busy:
				self.target = (self.target + step) % len(self.TARGETS)
				self.refresh()

		def press(self):
			if self.busy:
				return
			if self.pack and not packInstalled(self.pack):
				self.session.openWithCallback(lambda answer: self.run(answer, "download"), MessageBox,
					_("Download the %s style pack (%s)?") % (_(self.style[1]), PACKS[self.pack]["size"]), MessageBox.TYPE_YESNO)
				return

		def yellow(self):
			if self.pack and packInstalled(self.pack) and not self.busy:
				self.session.openWithCallback(lambda answer: self.run(answer, "remove"), MessageBox,
					_("Remove the %s style pack? Screens using it go back to Classic.") % PACKS[self.pack]["name"], MessageBox.TYPE_YESNO)

		def run(self, answer, action):
			if not answer or self.busy:
				return
			if action == "download" and 0 <= freeSpaceMB() < 10:
				self.session.open(MessageBox, _("Not enough free space on the receiver to download the style pack."), MessageBox.TYPE_ERROR)
				return
			if action == "remove":
				for app in packApps(self.pack):
					if packOf(currentStyle(app)) == self.pack:
						writeStyleFlags(app, fallbackStyle(app))
				self.changed = True
			try:
				from enigma import eConsoleAppContainer
				self.container = eConsoleAppContainer()
				self.container.appClosed.append(lambda retval: self.done(retval, action))
				self.busy = action
				self.refresh()
				if self.container.execute("/bin/sh", "/bin/sh", "-c", packCommand(self.pack, action)):
					self.done(-1, action)
			except Exception as e:
				print("[ObsidianFHD] pack %s %s: %s" % (action, self.pack, e))
				self.busy = ""
				self.refresh()

		def done(self, retval, action):
			self.busy = ""
			self.container = None
			if action == "download":
				if retval == 0 and packInstalled(self.pack):
					self.changed = True
					self.refresh()
					return
				self.session.open(MessageBox, packFailMessage(self.pack, retval), MessageBox.TYPE_ERROR)
			elif packInstalled(self.pack):
				print("[ObsidianFHD] pack remove %s failed (%s)" % (self.pack, retval))
				self.session.open(MessageBox, _("The style pack could not be removed."), MessageBox.TYPE_ERROR)
			self.refresh()

		def exit(self):
			if self.busy:
				return  # wait for opkg to finish
			self.close(self.changed)

	class ObsidianFHDLook(Screen):
		# Look page (layout of the app page, skin "ObsidianFHDApp", with its settings rows). Four settings: Style sets
		# Menus, Channel list and Infobar together (Nova Purple / Nova Obsidian also set the Nova colours); changing one
		# of those three makes the Style "Custom" (greyed). LEFT / RIGHT change the values on screen only; GREEN saves
		# them (downloading a missing style pack first) and offers the GUI restart. EXIT asks before dropping unsaved
		# changes. Saving writes the same flag files as before; opening the page writes nothing.
		HELP = {
			"style": "Sets menus, channel list and infobar together.",
			"menu": "Menus and settings pages.",
			"chlist": "Channel list.",
			"infobar": "Infobar. Nova comes with the Nova style pack; its colours apply to every Nova screen.",
			"clock": "The clock at the top right of the Halo and Glass infobars.",
		}

		def __init__(self, session, preset=None):
			Screen.__init__(self, session)
			self.skinName = ["ObsidianFHDApp"]
			self.setTitle(_("Obsidian FHD"))
			self.changed = False  # something was saved (the Apps panel then asks for the restart again on exit)
			self.busy = ""  # "download" / "remove" while opkg runs for a style pack
			self.container = None
			self.queue = []  # packs still to download before saving
			self.row = 0
			self["crumb"] = StaticText((_("APPS") + "  >  " + _("Styles") + "  >  " + _("Customise")).upper())
			self["icon"] = MultiPixmap()
			self["preview"] = MultiPixmap()
			self["packpreview"] = Pixmap()
			self["button"] = MultiPixmap()
			self["buttonTextDark"] = Label("")
			self["buttonTextLight"] = Label("")
			self["name"] = StaticText(_("Customise"))
			self["desc"] = StaticText("")
			self["note"] = StaticText("")
			addHintSlots(self)
			self["previewLabel"] = StaticText(_("PREVIEW"))
			self["detailsLabel"] = StaticText(_("SETTINGS"))
			for j in range(4):
				self["label%d" % j] = StaticText("")
				for k in ("", "g", "a", "c", "m"):
					self["value%d%s" % (j, k)] = Label("")
			addSettingSlots(self)
			self.saved = lookSaved()
			self.sel = lookPreset(self.saved, preset) if preset else dict(self.saved)
			self.lastStyle = lookStyleOf(self.sel) or LOOK_STYLES[0][0]
			self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
				"ok": self.save, "green": self.save, "cancel": self.exit, "red": self.exit, "yellow": self.yellow,
				"left": lambda: self.cycle(-1), "right": lambda: self.cycle(1),
				"up": lambda: self.moveRow(-1), "down": lambda: self.moveRow(1),
			}, -2)
			self.onLayoutFinish.append(self.layoutFinished)

		def layoutFinished(self):
			self["icon"].setPixmapNum(2)
			# five settings rows: the note goes below them (it is a StaticText; move its rendered label)
			from enigma import ePoint, eSize
			for renderer in self["note"].downstream_elements:
				if getattr(renderer, "instance", None) is not None:
					renderer.instance.move(ePoint(1080, 740))
					renderer.instance.resize(eSize(720, 64))
			self.refresh()

		def dirty(self):
			return self.sel != self.saved

		def value(self, row):
			return lookStyleOf(self.sel) if row == "style" else lookRowValue(self.sel, row)

		def setRow(self, j, label, value, col=""):
			self["label%d" % j].setText(label)
			colourText(self, "value%d" % j, value, col)

		def setButton(self, text, primary):
			self["button"].setPixmapNum(0 if primary else 1)
			colourText(self, "buttonText", text, "Dark" if primary else "Light", ("Dark", "Light"))

		def refresh(self):
			from enigma import ePoint
			for j in range(6):
				if j < len(LOOK_ROWS):
					row = LOOK_ROWS[j]
					value = self.value(row)
					text = lookValueName(row, value)
					pack = lookPack(row, value) if value else None
					if row == "style" and value is None:
						col = "m"  # Custom: greyed
					elif pack and not packInstalled(pack):
						text, col = text + " - " + _("download"), "a"
					elif row != "style" and value != lookRowValue(self.saved, row) or row == "style" and value != lookStyleOf(self.saved):
						col = "g"  # changed, not saved yet
					else:
						col = "c"
					self.setRow(j, lookLabel(row), ("<  %s  >" % text) if j == self.row else text, col)
				else:
					self.setRow(j, "", "")
			for j in (4, 5):
				if j < len(LOOK_ROWS):
					self["rowbg%d" % j].show()
				else:
					self["rowbg%d" % j].hide()
			self["rowsel"].instance.move(ePoint(1080, 354 + 76 * self.row))
			self["rowsel"].show()
			setScrollbar(self, 0, len(LOOK_ROWS), 6)
			row = LOOK_ROWS[self.row]
			setPreview(self, lookPreview(row, self.value(row), self.sel["colours"]))
			self["help"].setText(_(self.HELP[row]))
			self["desc"].setText(_("In use: %s") % lookValueName("style", lookStyleOf(self.saved)))
			if self.busy:
				self["note"].setText(_("Downloading...") if self.busy == "download" else _("Removing..."))
				self.setButton(_("Please wait"), False)
				setHints(self, [])  # no keys while opkg runs (EXIT waits for it)
				return
			missing = lookMissingPacks(self.sel)
			if self.dirty():
				if missing:
					self["note"].setText(_("Save downloads the %s style pack (%s) first.") % (PACKS[missing[0]]["name"], PACKS[missing[0]]["size"]))
				else:
					self["note"].setText(_("Not saved yet. GREEN saves, then the GUI restarts to apply."))
				self.setButton(_("Save"), True)
				hints = [(MARK_GREEN, _("Save"))]
			else:
				self["note"].setText(_("LEFT / RIGHT changes a setting, GREEN saves."))
				self.setButton(_("Saved"), False)
				hints = []
			pack = lookPack(row, self.value(row)) if self.value(row) else None
			if pack and packInstalled(pack):
				hints.append((MARK_YELLOW, _("Remove pack")))
			setHints(self, hints + [(KEY_EXIT, _("Back"))])

		# ---- keys: change on screen only ----
		def moveRow(self, step):
			if not self.busy:
				self.row = (self.row + step) % len(LOOK_ROWS)
				self.refresh()

		def cycle(self, step):
			if self.busy:
				return
			row = LOOK_ROWS[self.row]
			if row == "style":
				keys = lookValues("style")
				start = lookStyleOf(self.sel) or self.lastStyle
				# from Custom, the first press shows the last style used instead of skipping it
				key = start if lookStyleOf(self.sel) is None else keys[(keys.index(start) + step) % len(keys)]
				self.lastStyle = key
				self.sel = lookWithStyle(self.sel, key)
			else:
				values = lookValues(row)
				self.sel = lookSetRow(self.sel, row, values[(values.index(self.value(row)) + step) % len(values)])
			self.refresh()

		# ---- Save: download missing packs, write the flags, offer the restart ----
		def save(self):
			if self.busy or not self.dirty():
				return
			missing = lookMissingPacks(self.sel)
			if missing:
				if latestVersion():
					self.session.open(MessageBox, _("Update Obsidian FHD first (About & update), then download %s.") % PACKS[missing[0]]["name"], MessageBox.TYPE_INFO)
					return
				names = ", ".join("%s (%s)" % (PACKS[p]["name"], PACKS[p]["size"]) for p in missing)
				self.session.openWithCallback(lambda answer: answer and self.download(missing), MessageBox,
					_("Download the style pack %s and save?") % names, MessageBox.TYPE_YESNO)
				return
			self.write()

		def write(self):
			ok = lookSave(self.sel)
			try:
				from .infobar import sync
				sync()
			except Exception as e:
				print("[ObsidianFHD] infobar selection: %s" % e)
				ok = False
			self.saved = lookSaved()
			self.sel = dict(self.saved)
			self.changed = True
			self.refresh()
			if not ok:
				self.session.open(MessageBox, _("Unable to apply the style. Check free space and file permissions."), MessageBox.TYPE_ERROR)
				return
			self.session.openWithCallback(self.restartAnswer, MessageBox, _("Restart the GUI now to apply the changes?"), MessageBox.TYPE_YESNO)

		def restartAnswer(self, answer):
			if answer:
				try:
					from Screens.Standby import TryQuitMainloop
					self.session.open(TryQuitMainloop, 3)
				except Exception as e:
					print("[ObsidianFHD] restart: %s" % e)

		def download(self, packs):
			if 0 <= freeSpaceMB() < 10:
				self.session.open(MessageBox, _("Not enough free space on the receiver to download the style pack."), MessageBox.TYPE_ERROR)
				return
			self.queue = list(packs)
			self.run(self.queue.pop(0), "download")

		def yellow(self):
			if self.busy:
				return
			row = LOOK_ROWS[self.row]
			pack = lookPack(row, self.value(row)) if self.value(row) else None
			if pack and packInstalled(pack):
				self.session.openWithCallback(lambda answer: answer and self.remove(pack), MessageBox,
					_("Remove the %s style pack? Screens using it go back to Classic.") % PACKS[pack]["name"], MessageBox.TYPE_YESNO)

		def remove(self, pack):
			leavePack(pack)  # screens go back first, so the next start never needs the removed files
			self.changed = True
			self.run(pack, "remove")

		def run(self, pack, action):
			try:
				from enigma import eConsoleAppContainer
				self.container = eConsoleAppContainer()
				self.container.appClosed.append(lambda retval: self.runDone(retval, pack, action))
				self.busy = action
				self.refresh()
				if self.container.execute("/bin/sh", "/bin/sh", "-c", packCommand(pack, action)):
					self.runDone(-1, pack, action)
			except Exception as e:
				print("[ObsidianFHD] pack %s %s: %s" % (action, pack, e))
				self.busy = ""
				self.queue = []
				self.refresh()

		def runDone(self, retval, pack, action):
			self.busy = ""
			self.container = None
			if action == "download":
				if retval == 0 and packInstalled(pack):
					if self.queue:
						self.run(self.queue.pop(0), "download")
					else:
						self.write()  # all packs there: save the selection
					return
				self.queue = []
				self.session.open(MessageBox, packFailMessage(pack, retval), MessageBox.TYPE_ERROR)
			else:
				if packInstalled(pack):
					print("[ObsidianFHD] pack remove %s failed (%s)" % (pack, retval))
					self.session.open(MessageBox, _("The style pack could not be removed."), MessageBox.TYPE_ERROR)
				self.saved = lookSaved()
				self.sel = dict(self.saved)
			self.refresh()

		def exit(self):
			if self.busy:
				return  # wait for opkg to finish
			if self.dirty():
				self.session.openWithCallback(lambda answer: answer and self.close(self.changed), MessageBox,
					_("Leave without saving the changes?"), MessageBox.TYPE_YESNO)
				return
			self.close(self.changed)

	class ObsidianFHDChangelog(Screen):
		def __init__(self, session):
			Screen.__init__(self, session)
			self.skinName = ["ObsidianFHDChangelog"]
			self.setTitle(_("Obsidian FHD"))
			self["crumb"] = StaticText((_("APPS") + "  >  " + _("About & update") + "  >  " + _("What's new")).upper())
			self["heading"] = StaticText(_("What's new"))
			self["state"] = StaticText(_("Loading..."))
			addHintSlots(self)
			self["text"] = ScrollLabel("")
			self["actions"] = ActionMap(["OkCancelActions", "DirectionActions"], {
				"cancel": self.close, "ok": self.close,
				"up": self["text"].pageUp, "down": self["text"].pageDown,
				"left": self["text"].pageUp, "right": self["text"].pageDown,
			}, -2)
			self.polls = 0
			try:
				from enigma import eTimer
				self.timer = eTimer()
				self.timer.callback.append(self.poll)
			except Exception:
				self.timer = None
			# onLayoutFinish entries must be bound methods: OpenATV runs anything else through exec().
			self.onLayoutFinish.append(self.layoutFinished)
			ChangelogFetch.start()

		def layoutFinished(self):
			setHints(self, [(KEY_UPDOWN, _("Scroll")), (KEY_EXIT, _("Back"))])
			self.poll()

		def poll(self):
			# The download runs in a background thread: show its result when ready (checked twice a second, up to 15 s).
			text = ChangelogFetch.text
			if text:
				self["text"].setText(text)
				self["state"].setText("github.com/dali44g/Obsidian-FHD")
			elif text == "" or self.polls >= 30 or not self.timer:
				self["state"].setText("")
				self["text"].setText(_("The list of changes could not be loaded. Check the internet connection and try again later."))
			else:
				self.polls += 1
				self.timer.start(500, True)

	_screens = (ObsidianFHDApps, ObsidianFHDApp)
	return _screens


def openSettings(session, **kwargs):
	try:
		session.open(appScreens()[0])
	except Exception as e:
		# Never fail silently: full traceback in the log, short reason on screen.
		print("[ObsidianFHD] open: %s" % e)
		try:
			import traceback
			traceback.print_exc()
		except Exception:
			pass
		try:
			from Screens.MessageBox import MessageBox
			session.open(MessageBox, _("Obsidian Apps could not open.") + "\n\n%s\n\n" % e + _("Restart the GUI and try again. If it persists, send the log (search for ObsidianFHD)."), MessageBox.TYPE_ERROR)
		except Exception as e2:
			print("[ObsidianFHD] message: %s" % e2)


def obsidianActive():
	try:
		from Components.config import config
		return config.skin.primary_skin.value.startswith("Obsidian-FHD/")
	except Exception:
		return False


def menuEntry(menuid, **kwargs):
	# Main menu entry (key obsidian_apps = icon mainmenu/obsidian_apps.png), only while Obsidian is the active skin.
	if menuid == "mainmenu" and obsidianActive():
		return [(_("Obsidian Apps"), openSettings, "obsidian_apps", 45)]
	return []


def Plugins(**kwargs):
	return [PluginDescriptor(name="Obsidian Apps", description="Obsidian FHD apps and options", where=PluginDescriptor.WHERE_MENU, fnc=menuEntry),
		PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART, fnc=clockSession)]


def clockSession(reason, session=None, **kwargs):
	if reason == 0 and session is not None and obsidianActive():
		try:
			from .infobar import refresh
			refresh()
		except Exception as e:
			print("[ObsidianFHD] infobar startup: %s" % e)
	try:
		if reason == 0 and session is not None:
			from .clock import start
			start(session)
		elif reason == 1:
			from .clock import controller
			if controller is not None:
				controller.stop()
	except Exception as e:
		print("[ObsidianFHD] clock startup: %s" % e)
