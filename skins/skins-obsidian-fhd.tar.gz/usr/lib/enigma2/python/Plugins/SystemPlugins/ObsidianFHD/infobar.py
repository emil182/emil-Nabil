"""Materialize infobar choices for loaders that ignore conditional includes."""
import os
import xml.etree.ElementTree as ET


def sync(skin_dir="/usr/share/enigma2/Obsidian-FHD", config_dir="/etc/enigma2",
         python_dir="/usr/lib/enigma2/python"):
    def flag(name):
        return os.path.isfile(os.path.join(config_dir, "obsidian_" + name))

    def component(name):
        return any(os.path.isfile(os.path.join(python_dir, "Components", name + ext))
                   for ext in (".py", ".pyc", ".pyo"))

    def weather_ready():
        # OAWeather installed and set up: before a location is chosen it has no settings and every value reads
        # "n/a", so the weather widgets stay out until the user configures it
        if flag("noweather") or not (component("Converter/OAWeather") and component("Renderer/OAWeatherPixmap")):
            return False
        try:
            with open(os.path.join(config_dir, "settings")) as stream:
                return any(line.startswith("config.plugins.OAWeather.") for line in stream)
        except Exception:
            return False

    def version(path):
        try:
            with open(path) as stream:
                return stream.read().strip()
        except Exception:
            return ""

    def pack_installed(key, infobar_file):
        # a pack's infobar is usable when the pack is installed and from the same release as the skin
        pack = version(os.path.join(skin_dir, key, "version.txt"))
        return (os.path.isfile(os.path.join(skin_dir, infobar_file))
                and bool(pack) and pack == version(os.path.join(skin_dir, "version.txt")))

    nova_installed = lambda: pack_installed("nova", "skin_infobar_nova.xml")
    k7_installed = lambda: pack_installed("k7", "skin_infobar_k7.xml") and component("Renderer/ObsidianK7LCD")
    synthwave_installed = lambda: pack_installed("synthwave", "skin_infobar_synthwave.xml")
    matchday_installed = lambda: pack_installed("matchday", "skin_infobar_matchday.xml")

    for name, installed in (("nova", nova_installed), ("k7", k7_installed), ("synthwave", synthwave_installed),
                            ("matchday", matchday_installed)):
        if flag("infobar_" + name) and not installed():
            # a pack infobar chosen but its pack is missing (removed, or an update from a skin that had Nova built
            # in): Glass instead
            try:
                os.remove(os.path.join(config_dir, "obsidian_infobar_" + name))
                open(os.path.join(config_dir, "obsidian_infobar_glass"), "w").close()
            except Exception:
                pass

    files = []
    poster_ready = component("Converter/ObsidianPoster") and component("Renderer/ObsidianPosterImage")
    if flag("infobar_glass"):
        files.append("skin_infobar_glass.xml")
    elif flag("infobar_nova") and nova_installed():
        # Obsidian colours: the generated *_o.xml copies (novao/ images)
        suffix = "_o" if flag("nova_obsidian") and os.path.isfile(os.path.join(skin_dir, "skin_infobar_nova_o.xml")) else ""
        files.append("skin_infobar_nova%s.xml" % suffix)
        if weather_ready():
            files.append("skin_infobar_nova_weather%s.xml" % suffix)
        if component("Converter/ObsidianSysInfo"):
            files.append("skin_infobar_nova_sysinfo%s.xml" % suffix)
        if poster_ready and os.path.isfile(os.path.join(skin_dir, "skin_infobar_nova_poster%s.xml" % suffix)):
            # poster mode (Obsidian Posters app installed): the medallion becomes a portrait poster card
            files.append("skin_infobar_nova_poster%s.xml" % suffix)
    elif flag("infobar_k7") and k7_installed():
        files.append("skin_infobar_k7.xml")
        if weather_ready():
            files.append("skin_infobar_k7_weather.xml")
        if poster_ready and os.path.isfile(os.path.join(skin_dir, "skin_infobar_k7_poster.xml")):
            # the film card of the Obsidian Posters app in the K7 look
            files.append("skin_infobar_k7_poster.xml")
    elif flag("infobar_synthwave") and synthwave_installed():
        files.append("skin_infobar_synthwave.xml")
        if poster_ready and os.path.isfile(os.path.join(skin_dir, "skin_infobar_synthwave_poster.xml")):
            # poster mode (Obsidian Posters app installed): poster in the channel column, TMDB row and plot
            files.append("skin_infobar_synthwave_poster.xml")
    elif flag("infobar_matchday") and matchday_installed():
        files.append("skin_infobar_matchday.xml")
        if poster_ready and os.path.isfile(os.path.join(skin_dir, "skin_infobar_matchday_poster.xml")):
            # poster mode (Obsidian Posters app installed): poster on the clock card, rating, STORY strip
            files.append("skin_infobar_matchday_poster.xml")
    if poster_ready and not any(name.startswith(("skin_infobar_nova", "skin_infobar_k7", "skin_infobar_synthwave",
                                                   "skin_infobar_matchday")) for name in files):
        # poster mode of the Obsidian Posters app: Glass and Halo share InfoBarTemplate, so one file serves both
        files.append("skin_infobar_glass_poster.xml")
    if flag("noclock"):
        # no clock in the infobar (Obsidian Apps > Permanent clock); replaces the ClockCard defined earlier
        files.append("skin_infobar_noclock.xml")

    root = ET.Element("skin")
    for name in files:
        root.extend(ET.parse(os.path.join(skin_dir, name)).getroot())
    if not component("Renderer/ObsidianRing"):
        for screen in root.findall("screen"):
            for widget in screen.findall("widget[@render='ObsidianRing']"):
                screen.remove(widget)
    data = ET.tostring(root, encoding="utf-8")
    target = os.path.join(skin_dir, "skin_infobar_selected.xml")
    if os.path.isfile(target):
        with open(target, "rb") as stream:
            if stream.read() == data:
                return
    temporary = target + ".tmp"
    try:
        with open(temporary, "wb") as stream:
            stream.write(data)
        getattr(os, "replace", os.rename)(temporary, target)
    finally:
        if os.path.exists(temporary):
            os.remove(temporary)


if __name__ == "__main__":
    sync()


def refresh():
    """Refresh before InfoBar construction, including after external plugin changes."""
    sync()
    from skin import loadSkin
    loadSkin("/usr/share/enigma2/Obsidian-FHD/skin_infobar_selected.xml")
