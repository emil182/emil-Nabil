# -*- coding: utf-8 -*-
"""Optional Obsidian clock. No patches to the infobar, skin loader or other plugins."""
from time import localtime, strftime, time

from Components.config import config, configfile, ConfigSubsection, ConfigYesNo, ConfigSelection, getConfigListEntry
from Components.ConfigList import ConfigListScreen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Sources.StaticText import StaticText
from Screens.Screen import Screen
from enigma import eTimer, getDesktop, iPlayableService

from .plugin import _, obsidianActive


# Private settings; edits use separate elements until Green / Save is pressed.
# All designs use native labels/shapes, the existing fonts and one shared timer.
FIELDS = (
	('enabled', 'Clock enabled', False),
	('design', 'Clock design', [('minimal', 'Minimal'), ('flip', 'Flip'), ('stacked', 'Stacked')]),
	('color', 'Clock color', [('white', 'White'), ('yellow', 'Yellow')]),
	('position', 'Position', [('right', 'Right'), ('centre', 'Centre'), ('left', 'Left')]),
	('size', 'Size', [('medium', 'Medium'), ('small', 'Small'), ('large', 'Large')]),
	('seconds', 'Show seconds', False),
)
COLORS = {'white': 'ffffff', 'yellow': 'ffcc00'}


def elements(values=None):
	out = {}
	for key, label, choices in FIELDS:
		if isinstance(choices, bool):
			item = ConfigYesNo(default=choices)
		else:
			item = ConfigSelection(default=choices[0][0], choices=[(value, _(text)) for value, text in choices])
		if values is not None:
			item.value = values[key]
		out[key] = item
	return out


if not hasattr(config.plugins, 'obsidianclock'):
	config.plugins.obsidianclock = ConfigSubsection()
for _key, _item in elements().items():
	if not hasattr(config.plugins.obsidianclock, _key):
		setattr(config.plugins.obsidianclock, _key, _item)
settings = config.plugins.obsidianclock


def values():
	return {key: getattr(settings, key).value for key, label, choices in FIELDS}


def legacySetting():
	return getattr(getattr(config.plugins, 'PermanentClock', None), 'enabled', None)


def legacyEnabled():
	item = legacySetting()
	return bool(item is not None and item.value)


def geometry(options, width, height, preview=False):
	"""One layout for the TV overlay and its scaled settings preview."""
	scale = {'small': .8, 'medium': 1., 'large': 1.2}[options['size']] * width / 1920.
	design = options['design']
	w, h = {'minimal': (220 if options['seconds'] else 176, 60),
		'flip': (312 if options['seconds'] else 204, 100),
		'stacked': (144, 176 if options['seconds'] else 140)}[design]
	w, h = int(w * scale), int(h * scale)
	margin = int(60 * width / 1920.)
	x = {'left': margin, 'centre': (width - w) // 2, 'right': width - margin - w}[options['position']]
	y = int(52 * height / 1080.)
	if preview:
		x, y = 120 + int(x * 896. / width), 354 + int(y * 504. / height)
		scale *= 896. / width
		w, h = int(w * 896. / width), int(h * 504. / height)
	return x, y, max(1, w), max(1, h), scale


class ObsidianClockOverlay(Screen):
	def __init__(self, session, options, preview=False):
		self.options = options
		self.formats = {}
		self.lastText = {}
		desktop = getDesktop(0).size()
		x, y, w, h, scale = geometry(options, desktop.width(), desktop.height(), preview)
		def px(n):
			return max(1, int(n * scale))
		ox, oy = (x - 120, y - 354) if preview else (0, 0)
		def pos(a, b):
			return '%d,%d' % (ox + (px(a) if a else 0), oy + (px(b) if b else 0))
		color = COLORS[options['color']]
		sx, sy, sw, sh = (120, 354, 896, 504) if preview else (x, y, w, h)
		parts = ['<screen name="ObsidianClockOverlay" position="%d,%d" size="%d,%d" zPosition="%d" flags="wfNoBorder" backgroundColor="transparent">' % (sx, sy, sw, sh, 5 if preview else -1)]
		# Transparent top-level windows expose the video plane, so the preview carries its own background picture.
		if preview:
			parts.append('<ePixmap pixmap="/usr/share/enigma2/Obsidian-FHD/apps/preview_bg.jpg" position="0,0" size="896,504" zPosition="-1" />')
		def label(name, a, b, width, height, size, fmt):
			self.formats[name] = fmt
			parts.append('<widget name="%s" position="%s" size="%d,%d" font="MonoBold;%d" foregroundColor="#00%s" backgroundColor="transparent" transparent="1" halign="center" valign="center" borderWidth="0" noWrap="1" zPosition="3" />' % (name, pos(a, b), px(width), px(height), px(size), color))
		def rect(a, b, width, height, fill, radius=0, z=0, alpha='00'):
			parts.append('<eLabel position="%s" size="%d,%d" backgroundColor="#%s%s" cornerRadius="%d" zPosition="%d" />' % (pos(a, b), px(width), px(height), alpha, fill, px(radius) if radius else 0, z))
		design = options['design']
		if design == 'flip':
			for i, (name, fmt) in enumerate((('hours', '%H'), ('minutes', '%M'), ('seconds', '%S'))):
				if i == 2 and not options['seconds']:
					break
				a = i * 108
				rect(a, 0, 96, 100, '55565a', 13, 1, alpha='59')
				rect(a + 1, 1, 94, 98, '202124', 12, 2, alpha='59')
				rect(a + 1, 1, 94, 49, '353639', 12, 2, alpha='59')
				rect(a + 1, 38, 94, 12, '353639', z=2, alpha='59')
				label(name, a, 0, 96, 100, 66, fmt)
				rect(a + 1, 50, 94, 2, '090a0c', z=4, alpha='59')
		elif design == 'stacked':
			a = 18
			label('hours', a, 0, 108, 64, 60, '%H')
			label('minutes', a, 70, 108, 64, 60, '%M')
			rect(a + 14, 66, 80, 1, color)
			if options['seconds']:
				rect(52, 134, 40, 1, color)
				label('seconds', 36, 138, 72, 36, 28, '%S')
		else:
			label('time', 0, 0, 176, 60, 46, '%H:%M')
			if options['seconds']:
				label('separator', 152, 0, 28, 60, 46, ':')
				label('seconds', 176, 12, 44, 48, 30, '%S')
		self.skin = ''.join(parts) + '</screen>'
		Screen.__init__(self, session)
		self.skinName = 'ObsidianClockOverlay'
		for name in self.formats:
			self[name] = Label('')
		self.onLayoutFinish.append(self.updateTime)

	def updateTime(self, now=None):
		now = localtime() if now is None else now
		for name, fmt in self.formats.items():
			text = strftime(fmt, now)
			if self.lastText.get(name) != text:
				self[name].setText(text)
				self.lastText[name] = text


class ClockController(object):
	def __init__(self, session):
		self.session = session
		self.dialog = self.preview = None
		self.previewOptions = None
		self.notifiers = []
		self.standby = None
		self.serviceEnded = False
		self.timer = eTimer()
		self.timer.callback.append(self.tick)
		self.session.nav.event.append(self.serviceEvent)
		self.watch(config.misc.standbyCounter, self.enterStandby)
		self.watch(config.skin.primary_skin, self.changed)
		self.watch(legacySetting(), self.changed)
		self.refresh()

	def watch(self, item, callback):
		if item is not None and not any(entry[0] is item for entry in self.notifiers):
			item.addNotifier(callback, initial_call=False)
			self.notifiers.append((item, callback))

	def changed(self, item=None):
		self.refresh()

	def serviceEvent(self, event):
		if event in (iPlayableService.evStart, iPlayableService.evEnd):
			self.serviceEnded = event == iPlayableService.evEnd
			self.refresh()

	def enterStandby(self, item):
		from Screens.Standby import inStandby
		self.standby = inStandby
		if self.standby is not None:
			self.standby.onClose.append(self.leaveStandby)
		self.refresh()

	def leaveStandby(self):
		self.standby = None
		self.refresh()

	def discard(self, name):
		dialog = getattr(self, name)
		if dialog is not None:
			dialog.hide()
			self.session.deleteDialog(dialog)
			setattr(self, name, None)

	def setPreview(self, options=None):
		try:
			self.discard('preview')
			self.previewOptions = options
			if options is not None:
				self.preview = self.session.instantiateDialog(ObsidianClockOverlay, options, True)
				self.preview.show()
		except Exception as error:
			print('[ObsidianFHD] clock preview: %s' % error)
		self.refresh()

	def apply(self):
		self.discard('dialog')
		self.refresh()

	def refresh(self):
		# Callback failures stop only this optional overlay, never the receiver UI.
		try:
			self.timer.stop()
			self.watch(legacySetting(), self.changed)
			visible = settings.enabled.value and obsidianActive() and not legacyEnabled() and self.standby is None and not self.serviceEnded and self.session.nav.getCurrentlyPlayingServiceReference() is not None
			if visible:
				if self.dialog is None:
					self.dialog = self.session.instantiateDialog(ObsidianClockOverlay, values())
					self.dialog.show()
			else:
				self.discard('dialog')
			self.tick()
		except Exception as error:
			self.timer.stop()
			print('[ObsidianFHD] clock: %s' % error)

	def tick(self):
		# Time updates never rebuild screens, recheck service state or redraw unchanged labels.
		try:
			self.timer.stop()
			now = localtime()
			for dialog in (self.dialog, self.preview):
				if dialog is not None:
					dialog.updateTime(now)
			if self.dialog is not None or self.preview is not None:
				seconds = (self.dialog is not None and settings.seconds.value) or (self.previewOptions is not None and self.previewOptions['seconds'])
				period = 1 if seconds else 60
				self.timer.start(max(100, int((period - time() % period) * 1000) + 10), True)
		except Exception as error:
			self.timer.stop()
			print('[ObsidianFHD] clock: %s' % error)

	def stop(self):
		self.timer.stop()
		self.discard('preview')
		self.discard('dialog')
		if self.serviceEvent in self.session.nav.event:
			self.session.nav.event.remove(self.serviceEvent)
		for item, callback in self.notifiers:
			item.removeNotifier(callback)
		self.notifiers = []
		if self.standby is not None and self.leaveStandby in self.standby.onClose:
			self.standby.onClose.remove(self.leaveStandby)


controller = None


def start(session):
	global controller
	if controller is None:
		controller = ClockController(session)
	return controller


class ObsidianClockSettings(Screen, ConfigListScreen):
	def __init__(self, session):
		Screen.__init__(self, session)
		self.skinName = 'ObsidianClockSettings'
		self.setTitle(_('Permanent clock'))
		self.draft = elements(values())
		self['heading'] = StaticText(_('Permanent clock'))
		self['subtitle'] = StaticText(_('Make the clock fit your screen'))
		self['previewLabel'] = StaticText(_('PREVIEW'))
		self['settingsLabel'] = StaticText(_('Settings'))
		self['status'] = Label('')
		self['key_red'] = StaticText(_('Cancel'))
		self['key_green'] = StaticText(_('Save'))
		entries = [getConfigListEntry(_(label), self.draft[key]) for key, label, choices in FIELDS]
		ConfigListScreen.__init__(self, entries, session=session, on_change=self.updatePreview)
		self['clockActions'] = ActionMap(['OkCancelActions', 'ColorActions'], {
			'cancel': self.keyCancel, 'red': self.keyCancel, 'green': self.keySave,
		}, -2)
		self.manager = start(session)
		self.onLayoutFinish.append(self.updatePreview)
		self.onExecBegin.append(self.updatePreview)
		self.onExecEnd.append(self.closePreview)
		self.onClose.append(self.closePreview)

	def updatePreview(self):
		if not self.instance:
			return
		self.manager.setPreview({key: item.value for key, item in self.draft.items()})
		self['status'].setText(_('Paused: the separate Permanent Clock plugin is enabled. Turn it off there to use this clock.') if legacyEnabled() else _('Preview only. Green saves; Red or Exit discards changes.'))

	def keySave(self):
		old = values()
		try:
			for key, item in self.draft.items():
				getattr(settings, key).value = item.value
			settings.save()
			configfile.save()
		except Exception as error:
			for key, value in old.items():
				getattr(settings, key).value = value
			settings.save()
			from Screens.MessageBox import MessageBox
			self.session.open(MessageBox, _('Clock settings could not be saved.') + '\n' + str(error), MessageBox.TYPE_ERROR)
			return
		self.manager.apply()
		self.close()

	def keyCancel(self, *args):
		self.close()

	def closePreview(self):
		self.manager.setPreview()
