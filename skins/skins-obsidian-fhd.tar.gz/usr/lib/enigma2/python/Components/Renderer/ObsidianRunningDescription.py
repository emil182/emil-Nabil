# -*- coding: utf-8 -*-
"""EPG description that scrolls slowly upward when it does not fit.

Scrolling starts only after the selection has rested a few seconds, so browsing the
channel list costs nothing; the timer stops as soon as the screen is hidden. While the screen
is hidden (the channel list and second infobar stay built in the background) a new text is only
kept, and measured when the screen is shown, so zapping does no text layout for hidden screens.
"""
from enigma import eLabel, eWidget, eTimer, ePoint, eSize
from Components.Renderer.Renderer import Renderer
from skin import parseColor, parseFont

START = 4000  # ms of rest before scrolling
STEP = 120  # ms per move: PIXELS every STEP, about one text line every two seconds
PIXELS = 2  # pixels per move (2 px / 120 ms: the same speed as 1 px / 60 ms with half the redraws)
END = 3000  # ms on the last line before starting again


class ObsidianRunningDescription(Renderer):
	GUI_WIDGET = eWidget

	def __init__(self):
		Renderer.__init__(self)
		self.label = None
		self.offset = self.overflow = 0
		self.startDelay = START
		self.pending = None  # change received while the screen was hidden
		self.timer = eTimer()
		self.timer.callback.append(self.step)

	def postWidgetCreate(self, instance):
		self.label = eLabel(instance)

	def preWidgetRemove(self, instance):
		self.timer.stop()
		self.label = None

	def applySkin(self, desktop, parent):
		# position and size go to the clipping container, the text attributes to the label inside
		keep = []
		for attrib, value in self.skinAttributes:
			if attrib == "startDelay":  # ms of rest before scrolling, for screens that close by themselves
				self.startDelay = int(value)
			elif attrib == "font":
				self.label.setFont(parseFont(value, ((1, 1), (1, 1))))
			elif attrib == "foregroundColor":
				self.label.setForegroundColor(parseColor(value))
			elif attrib == "backgroundColor":
				self.label.setBackgroundColor(parseColor(value))
			elif attrib not in ("valign", "halign", "noWrap"):
				# transparent stays on the container, so nothing shows when the label is hidden
				keep.append((attrib, value))
		self.skinAttributes = keep
		return Renderer.applySkin(self, desktop, parent)

	def screenShown(self):
		"""The screen holding this widget is visible (any doubt counts as visible)."""
		try:
			widget, depth = self.instance.getParent(), 0
			while widget is not None and depth < 20:
				if not widget.isVisible():
					return False
				widget, depth = widget.getParent(), depth + 1
		except Exception:
			pass
		return True

	def changed(self, what, force=False):
		self.timer.stop()
		if not self.instance or not self.label:
			return
		if not force and not self.screenShown():
			self.pending = what  # laid out in onShow
			return
		self.pending = None
		text = self.source.text or "" if what[0] != self.CHANGED_CLEAR else ""
		if isinstance(text, bytes):
			text = text.decode("utf-8", "replace")
		width, height = self.instance.size().width(), self.instance.size().height()
		self.label.resize(eSize(width, 4000))
		self.label.setText(" ".join(text.split()))
		self.overflow = self.label.calculateSize().height() - height
		self.label.resize(eSize(width, max(height, height + self.overflow)))
		self.offset = 0
		self.label.move(ePoint(0, 0))
		# no description (no EPG): hide, or the label's own background shows over the hidden card
		if text.strip():
			self.label.show()
		else:
			self.label.hide()
		if self.overflow > 0:
			self.timer.start(self.startDelay, True)

	def step(self):
		if self.offset >= self.overflow:
			# rest on the last line, then back to the top and wait again
			self.offset = -1
			self.timer.start(END, True)
			return
		if self.offset < 0:
			self.offset = 0
			self.label.move(ePoint(0, 0))
			self.timer.start(self.startDelay, True)
			return
		self.offset = min(self.overflow, self.offset + PIXELS)
		self.label.move(ePoint(0, -self.offset))
		self.timer.start(STEP, True)

	def onHide(self):
		self.timer.stop()
		Renderer.onHide(self)

	def onShow(self):
		Renderer.onShow(self)
		if self.pending is not None:
			what, self.pending = self.pending, None
			self.changed(what, True)  # the screen is being shown: lay out now
		elif self.overflow > 0 and not self.timer.isActive():
			self.timer.start(self.startDelay, True)
