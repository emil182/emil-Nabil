"""Full menu breadcrumb, independent of the image's title-path display preference."""
from Components.Renderer.Label import Label


def menuPath(screen, fallback=''):
    if screen is None:
        return fallback
    parent = getattr(screen, 'screenPath', '') or ''
    title = screen.getTitle() or ''
    return ' > '.join(part for part in (parent, title) if part) or fallback


def pathText(screen, fallback='', mode='Full'):
    if mode == 'Heading':
        from Components.Language import language
        return {'fr': 'CHEMIN DU MENU', 'ar': '\u0645\u0633\u0627\u0631 \u0627\u0644\u0642\u0627\u0626\u0645\u0629'}.get(language.getLanguage()[:2], 'MENU PATH')
    if mode == 'Current':
        return screen.getTitle() if screen is not None else fallback
    if mode == 'Parents' and screen is not None:
        parent = getattr(screen, 'screenPath', '') or ''
        parts = [part.strip() for part in parent.split(' > ') if part.strip()]
        spacing = '\n\n' if len(parts) <= 3 else '\n'
        return spacing.join('\u203a  ' + part for part in parts)
    return menuPath(screen, fallback)


class ObsidianMenuPath(Label):
    def __init__(self):
        Label.__init__(self)
        self.pathMode = 'Full'

    def applySkin(self, desktop, parent):
        self.menuScreen = parent
        if self.skinAttributes:
            attributes = []
            for key, value in self.skinAttributes:
                if key == 'pathMode':
                    self.pathMode = value
                else:
                    attributes.append((key, value))
            self.skinAttributes = attributes
        result = Label.applySkin(self, desktop, parent)
        self.updatePath()
        return result

    def updatePath(self):
        self.text = pathText(getattr(self, 'menuScreen', None), self.source.text or '', self.pathMode)

    def changed(self, what):
        Label.changed(self, what)
        self.updatePath()

    def onShow(self):
        Label.onShow(self)
        self.updatePath()
