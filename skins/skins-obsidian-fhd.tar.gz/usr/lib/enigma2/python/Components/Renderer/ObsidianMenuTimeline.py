"""Connected vertical menu breadcrumb, rendered once per title change; no timer."""
from enigma import eWidget, eLabel, ePoint, eSize, gRGB
from skin import parseFont
from Components.Renderer.Renderer import Renderer


def timelineRows(screen, fallback=''):
    if screen is None:
        return [], fallback
    path = getattr(screen, 'screenPath', '') or ''
    return [part.strip() for part in path.split(' > ') if part.strip()], screen.getTitle() or fallback


def rowLayout(parents, current, measure):
    """Keep text sizes and row gaps fixed; wrapped labels add height."""
    rows, top = [], 0
    for name in parents:
        height = max(32, measure(name, False))
        rows.append((name, top, height, False))
        top += height + 20
    height = max(36, measure(current, True))
    rows.append((current, top, height, True))
    return rows, top + height


class ObsidianMenuTimeline(Renderer):
    GUI_WIDGET = eWidget

    def __init__(self):
        Renderer.__init__(self)
        self.children = []
        self.menuScreen = None
        self.lastRows = None
        self.used = 0
        self.flow = ''
        self.followers = None
        self.measureLabel = None
        self.pathHeight = 0

    def applySkin(self, desktop, parent):
        self.menuScreen = parent
        self.regular = parseFont('Regular;23', parent.scale)
        self.current = parseFont('SemiBold;28', parent.scale)
        self.nodeFont = parseFont('Regular;17', parent.scale)
        if self.skinAttributes:
            attributes = []
            for key, value in self.skinAttributes:
                if key == 'flow':
                    self.flow = value
                else:
                    attributes.append((key, value))
            self.skinAttributes = attributes
        result = Renderer.applySkin(self, desktop, parent)
        if self.layoutFinished not in parent.onLayoutFinish:
            parent.onLayoutFinish.append(self.layoutFinished)
        self.drawPath()
        return result

    def preWidgetRemove(self, instance):
        callbacks = getattr(self.menuScreen, 'onLayoutFinish', [])
        if self.layoutFinished in callbacks:
            callbacks.remove(self.layoutFinished)
        self.children = []
        self.measureLabel = None
        self.followers = None
        self.lastRows = None
        self.menuScreen = None

    def element(self, x, y, w, h, color, text=None, font=None):
        if self.used == len(self.children):
            self.children.append(eLabel(self.instance))
        label = self.children[self.used]
        self.used += 1
        label.move(ePoint(x, y))
        label.resize(eSize(w, h))
        if text is None:
            label.setText('')
            label.setTransparent(0)
            label.setBackgroundColor(gRGB(color))
        else:
            label.setTransparent(1)
            label.setForegroundColor(gRGB(color))
            label.setFont(font)
            label.setText(text)
        label.show()
        return label

    def measure(self, text, current):
        if self.measureLabel is None:
            self.measureLabel = eLabel(self.instance)
            self.measureLabel.hide()
        self.measureLabel.resize(eSize(self.instance.size().width() - 36, 2000))
        self.measureLabel.setFont(self.current if current else self.regular)
        # setWrap is missing on some images (OpenBH has only setNoWrap): a crash there closed every Edge submenu
        if hasattr(self.measureLabel, 'setWrap'):
            self.measureLabel.setWrap(1)
        elif hasattr(self.measureLabel, 'setNoWrap'):
            self.measureLabel.setNoWrap(0)
        self.measureLabel.setText(text)
        try:
            return self.measureLabel.calculateSize().height() + 4
        except Exception:
            return 32 if not current else 40

    def layoutFinished(self):
        if self.followers is None:
            self.followers = []
            screen = self.menuScreen
            components = list(getattr(screen, 'renderer', [])) + list(screen.values()) + list(getattr(screen, 'additionalWidgets', []))
            seen = set()
            for component in components:
                widget = getattr(component, 'instance', None)
                if widget is None or widget is self.instance or id(widget) in seen:
                    continue
                seen.add(id(widget))
                pos, size = widget.position(), widget.size()
                if pos.x() < 464:
                    self.followers.append((widget, pos.x(), pos.y(), size.width(), size.height()))
        self.flowBelow()

    def flowBelow(self):
        if self.followers is None or not self.flow:
            return
        base = self.instance.position().y() + self.pathHeight + 20
        for widget, x, y, width, height in self.followers:
            newY, newHeight = y, height
            if self.flow == 'menu':
                card = base + 36
                divider = card + 112
                about = divider + 18
                description = about + 40
                if 336 <= y <= 362:
                    newY = base + y - 336
                elif 382 <= y <= 470:
                    newY = card + y - 382
                elif y == 510:
                    newY = divider
                elif y == 532:
                    newY = about
                elif y == 578:
                    newY, newHeight = description, max(0, 722 - description)
            elif self.flow == 'settings':
                if y == 556:
                    newY = base
                elif y == 578:
                    newY = base + 22
                elif y == 624:
                    newY, newHeight = base + 68, max(0, 864 - base - 68)
            widget.move(ePoint(x, newY))
            widget.resize(eSize(width, newHeight))

    def drawPath(self):
        if not self.instance or self.menuScreen is None:
            return
        rows = timelineRows(self.menuScreen, self.source.text or '')
        if rows == self.lastRows:
            return
        for child in self.children:
            child.hide()
        # Reuse the widgets when a title changes, keeping child ownership bounded.
        self.used = 0
        self.lastRows = rows
        parents, current = rows
        width = self.instance.size().width()
        layout, self.pathHeight = rowLayout(parents, current, self.measure)
        self.instance.resize(eSize(width, self.pathHeight))
        currentTop = layout[-1][1]
        centers = [top + 16 for name, top, height, active in layout[:-1]]
        if centers:
            self.element(11, centers[0], 1, centers[-1] - centers[0] + 1, 0x30414a)
            self.element(11, centers[-1], 1, currentTop + 20 - centers[-1], 0x00aabd)
        for (name, top, height, active), center in zip(layout[:-1], centers):
            self.element(3, center - 12, 20, 27, 0x849495, '\u25cb', self.nodeFont)
            self.element(36, top, width - 36, height, 0xcdd3dc, name, self.regular)
        self.element(3, currentTop + 8, 20, 27, 0x00d8e8, '\u25cf', self.nodeFont)
        self.element(36, currentTop, width - 36, layout[-1][2], 0x00d8e8, current, self.current)
        self.flowBelow()

    def changed(self, what):
        self.drawPath()

    def onShow(self):
        Renderer.onShow(self)
        self.drawPath()
        self.flowBelow()
