# -*- coding: utf-8 -*-
"""A normal wrapped label, shortened to its actual widget bounds. No timer.

Shortening measures the text several times (binary search), so results are kept per widget by
(text, width, height): moving back over a channel, or the same text again, measures nothing."""
from Components.Renderer.Label import Label


def shorten(text, fits):
	# Flatten EPG paragraphs so blank lines do not consume the small synopsis area.
	text = ' '.join(text.split())
	if fits(text):
		return text
	low, high = 0, min(len(text), 8192)
	while low < high:
		middle = (low + high + 1) // 2
		if fits(text[:middle].rstrip() + '..'):
			low = middle
		else:
			high = middle - 1
	cut = text[:low].rstrip()
	# Prefer ending at a word; still handle a single very long word or unspaced scripts.
	space = cut.rfind(' ')
	if space > len(cut) * 3 // 4:
		cut = cut[:space]
	return cut + '..' if fits(cut + '..') else ''


CACHE_SIZE = 64  # shortened texts kept per widget (its font never changes)


class ObsidianDescription(Label):
	fitted = None  # {(text, width, height): shortened}
	def applySkin(self, desktop, parent):
		result = Label.applySkin(self, desktop, parent)
		self.fitText()
		return result

	def changed(self, what):
		Label.changed(self, what)
		if what[0] != self.CHANGED_CLEAR:
			self.fitText()

	def fitText(self):
		if not self.instance:
			return
		original = getattr(self, 'text', self.source.text or '')
		try:
			text = self.source.text or ''
			if isinstance(text, bytes):
				text = text.decode('utf-8', 'replace')
			bounds = self.instance.size()
			key = (text, bounds.width(), bounds.height())
			if self.fitted is None:
				self.fitted = {}
			hit = self.fitted.get(key)
			if hit is not None:
				self.text = hit
				self.instance.setText(hit)
				return

			def fits(value):
				self.instance.setText(value)
				size = self.instance.calculateSize()
				return size.height() <= bounds.height() and size.width() <= bounds.width()
			self.text = shorten(text, fits)
			# VariableText may skip identical values; measurement changed the native label.
			self.instance.setText(self.text)
			if len(self.fitted) >= CACHE_SIZE:
				self.fitted.clear()
			self.fitted[key] = self.text
		except Exception:
			# Missing measurement API on an older image must not prevent the screen opening.
			self.text = original
			self.instance.setText(original)
