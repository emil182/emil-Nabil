# -*- coding: utf-8 -*-
# ObsidianRing: shows one of N ring images for a value, on every image (no OpenATV-only "pixmaps" list needed).
# Skin attributes (both optional): rings="icons/ring/ram_" (image prefix in the skin folder, files <prefix>00.png ..)
# and steps="21" (number of images). Defaults: the Nova progress ring, nova/ring_00..23.png.
# The value is read as source.value out of source.range (EventTime Progress: 0..1000, ObsidianSysInfo: 0..100).
# Hidden when there is no value (e.g. no programme). Only the image shown is loaded, once per enigma2 session and
# shared by every widget (menus open faster); Python 2 / 3, no timer.
from enigma import ePixmap
from Components.Renderer.Renderer import Renderer
from Tools.LoadPixmap import LoadPixmap
from Tools import Directories

# Newer images name the skin folder SCOPE_GUISKIN, older ones (PurE2, older OpenPLi) SCOPE_CURRENT_SKIN.
SCOPE = getattr(Directories, "SCOPE_GUISKIN", None) or getattr(Directories, "SCOPE_CURRENT_SKIN")
PIXMAPS = {}  # ring image path -> pixmap (or None when it cannot be loaded)


class ObsidianRing(Renderer):
	GUI_WIDGET = ePixmap

	def __init__(self):
		Renderer.__init__(self)
		self.prefix = "nova/ring_"
		self.steps = 24

	def applySkin(self, desktop, parent):
		if self.skinAttributes:
			attribs = []
			for (attrib, value) in self.skinAttributes:
				if attrib == "rings":
					self.prefix = value
				elif attrib == "steps":
					self.steps = max(1, int(value))
				else:
					attribs.append((attrib, value))
			self.skinAttributes = attribs
		return Renderer.applySkin(self, desktop, parent)

	def pixmap(self, step):
		path = "%s%02d.png" % (self.prefix, step)
		if path not in PIXMAPS:
			try:
				PIXMAPS[path] = LoadPixmap(Directories.resolveFilename(SCOPE, path))
			except Exception:
				PIXMAPS[path] = None
		return PIXMAPS[path]

	def changed(self, what):
		if not self.instance:
			return
		try:
			value = self.source.value
			top = getattr(self.source, "range", 1000) or 1000
			step = None if value is None else min(self.steps - 1, max(0, int(value) * self.steps // int(top)))
		except Exception:
			step = None
		if step is None:
			self.instance.hide()
			return
		png = self.pixmap(step)
		if png:
			self.instance.setPixmap(png)
			self.instance.show()
		else:
			self.instance.hide()

	def onShow(self):
		self.changed(None)
