# -*- coding: utf-8 -*-
# Obsidian FHD system information for the menu dashboard (skin_sysinfo.xml).
# Reads /proc and statvfs (no shell); network use only for the online badge and the update check, see their classes.
# Every value falls back to "" / 0, so a missing sensor or file can never raise into enigma2. Refreshes every 10 s while a screen using it is shown.
#
#   <convert type="ObsidianSysInfo">Temp</convert>        text  "31 degrees C"
#   CpuLoad, Fan, Uptime, Ip                              text
#   RamText, FlashText, SsdText, UsbText                          text  "355 / 560 MB", "22 MB free"
#   RamPercent "27%", RamStep "0".."20" (ring image index)
#   RamUsed, FlashUsed, SsdUsed, UsbUsed                         value 0..100 for render="Progress"
#   CpuUsed, TempUsed                                     value 0..100 (CPU busy %, degrees C) for render="ObsidianRing"
#   CpuPercent "42%", TempShort "30 degrees" (no unit)    text
#   Tuners "A DVB-S2  B DVB-S2", NetLink "100 Mbit/s"     text
#   NetDown, NetUp                                        text  "5.2 Mbit/s" (average since the previous sample)
#   NetIface                                              text  "Ethernet - eth0"
#   NetHist0..14 (value 0..100, oldest..newest download sample, scaled to the highest), NetPeak "peak 8.1 Mbit/s"
#   FlashPercent "90%", DiskPercent1..3 "5%", FanRpm "1876 rpm"   text
#   Disk1..3 (boolean, row present), DiskName1..3 "SSD" / "USB 2" / "+2 more", DiskText1..3 "54 GB free",
#   DiskModel1..3 "Kingston DataTraveler 3.0", DiskUsed1..3 (value 0..100): local disks under /media, internal first
#   SkinVersion"v1.4", ImageInfo "OpenATV 8.0.1 - Vu+ Solo2", ImageName "OpenATV 8.0.1", Model "Vu+ Solo2"  text
#   Online, Offline                                      boolean (internet reachable / not; both False until checked)
#   Update (boolean, newer release on GitHub), UpdateText "Update v1.4.1 available"
#   Short (chained after PliExtraInfo): raw tuner numbers shortened, "12558000" -> "12558"
#   FlashLow                                              boolean (free flash < 15 MB) for ConditionalShowHide
from os import statvfs
from os.path import exists, ismount

from Components.Converter.Converter import Converter
from Components.Converter.Poll import Poll
from Components.Element import cached

SSD = "/media/hdd"

# Non-ASCII text built from escapes so the file stays plain ASCII; Python 2 images (OpenATV 6, OpenPLi 7) need UTF-8 str.
try:
	unicode
	DOT = u"\u00b7".encode("utf-8")
	DEG = u"\u00b0".encode("utf-8")
except NameError:
	DOT = "\u00b7"
	DEG = "\u00b0"

USB = "/media/usb"


def readFirst(paths):
	for path in paths:
		try:
			with open(path) as f:
				value = f.read().strip()
			if value:
				return value
		except Exception:
			pass
	return ""


def receiverModel():
	# Image metadata knows the marketed model; legacy /proc aliases may describe another box.
	def clean(value):
		try:
			return value.strip().strip("\"'").replace("\x00", "") if value else ""
		except (AttributeError, TypeError):
			return ""

	def joined(brand, model):
		brand, model = clean(brand), clean(model)
		return (brand + " " + model).strip() if brand and not model.lower().startswith(brand.lower()) else model

	try:
		from Components.SystemInfo import BoxInfo
		model = clean(BoxInfo.getItem("displaymodel"))
		if model:
			return joined(BoxInfo.getItem("displaybrand"), model)
	except Exception:
		pass
	try:
		from boxbranding import getMachineBrand, getMachineName
		model = clean(getMachineName())
		if model:
			return joined(getMachineBrand(), model)
	except Exception:
		pass
	data = readFirst(("/usr/lib/enigma.info",))
	info = dict(line.split("=", 1) for line in data.splitlines() if "=" in line)
	if clean(info.get("displaymodel")):
		return joined(info.get("displaybrand"), info["displaymodel"])
	# Prefer generic identifiers to Vu compatibility nodes. Never infer a brand from node existence.
	return clean(readFirst(("/proc/stb/info/boxtype", "/proc/stb/info/model", "/proc/device-tree/model", "/sys/firmware/devicetree/base/model", "/proc/stb/info/vumodel")))


class HardwareSensors(object):
	# Discover local sensor nodes once; reuse paths at the existing 10-second polling rate.
	paths = None

	@classmethod
	def discover(cls):
		if cls.paths is None:
			from glob import glob
			temps = ["/proc/stb/sensors/temp0/value", "/proc/stb/sensors/temp/value", "/proc/stb/fp/temp_sensor",
				"/proc/stb/fp/temp_sensor_avs", "/proc/stb/power/avs"]
			for pattern in ("/proc/stb/sensors/temp*/value", "/sys/class/thermal/thermal_zone*/temp",
				"/sys/devices/virtual/thermal/thermal_zone*/temp", "/sys/class/hwmon/hwmon*/temp*_input"):
				temps.extend(sorted(glob(pattern)))
			fans = ["/proc/stb/fp/fan_speed", "/proc/stb/fp/fan_speed_rpm"]
			fans.extend(sorted(glob("/sys/class/hwmon/hwmon*/fan*_input")))
			def unique(paths):
				result = []
				for path in paths:
					if path not in result and exists(path):
						result.append(path)
				return result
			cls.paths = (unique(temps), unique(fans))
		return cls.paths

	@staticmethod
	def number(raw):
		from re import match
		m = match(r"^\s*([-+]?\d+(?:\.\d+)?)", raw)
		return float(m.group(1)) if m else None

	@classmethod
	def celsius(cls):
		# Degrees C as a number, or None when the box has no readable sensor.
		for path in cls.discover()[0]:
			value = cls.number(readFirst((path,)))
			if value is None:
				continue
			if path.startswith("/sys/") or abs(value) > 1000:
				value /= 1000.0
			if -30 <= value <= 150:
				return value
		# HiSilicon exposes temperature inside a multi-line CPU status file.
		from re import search
		m = search(r"temperature\s*=\s*([-+]?\d+(?:\.\d+)?)", readFirst(("/proc/hisi/msp/pm_cpu",)))
		if m and -30 <= float(m.group(1)) <= 150:
			return float(m.group(1))
		return None

	@classmethod
	def temperature(cls):
		value = cls.celsius()
		return "N/A" if value is None else "%d %sC" % (round(value), DEG)

	@classmethod
	def fan(cls):
		for path in cls.discover()[1]:
			value = cls.number(readFirst((path,)))
			if value is not None and 0 <= value <= 100000:
				return "%d" % value
		# Do not interpret fan PWM/voltage/control settings as an RPM reading.
		return "N/A"


_mem = (0.0, (0, 0))


def memInfo():
	# Read once for all the RAM widgets of a screen (ring, percent, text): /proc/meminfo at most every 2 s.
	global _mem
	from time import time
	now = time()
	if now - _mem[0] < 2:
		return _mem[1]
	_mem = (now, readMem())
	return _mem[1]


def readMem():
	data = {}
	try:
		with open("/proc/meminfo") as f:
			for line in f:
				parts = line.split()
				if len(parts) >= 2:
					data[parts[0].rstrip(":")] = int(parts[1])
	except Exception:
		pass
	total = data.get("MemTotal", 0)
	avail = data.get("MemAvailable", data.get("MemFree", 0) + data.get("Cached", 0))
	return total // 1024, max(0, total - avail) // 1024


def diskInfo(path):
	try:
		st = statvfs(path)
		total = st.f_blocks * st.f_frsize
		free = st.f_bavail * st.f_frsize
		return total, free
	except Exception:
		return 0, 0


def sizeText(size):
	mb = size / 1048576.0
	return "%.1f GB" % (mb / 1024) if mb >= 1024 else "%d MB" % mb


class NetSampler(object):
	# Byte counters of the busiest real interface from /proc/net/dev. One shared sample per poll interval,
	# so every widget shows the same, exact average rate (bytes difference / elapsed time).
	last = None  # (time, iface, rx, tx)
	rate = (0.0, 0.0)  # bit/s down, up
	iface = ""
	history = []  # download bit/s, newest last, at most HISTORY samples
	HISTORY = 15
	IDLE = 120  # s without a dashboard asking: the background sampling stops (it restarts with the next dashboard)
	timer = None
	used = 0.0

	@classmethod
	def start(cls):
		# Sample every 10 s while a dashboard uses the values, and a little after, so the chart is filled when it
		# opens again soon; stops after IDLE s without use (it used to run until the next restart).
		from time import time
		cls.used = time()
		if cls.timer is None:
			try:
				from enigma import eTimer
				cls.timer = eTimer()
				try:
					cls.timer.callback.append(cls.tick)
				except AttributeError:
					cls.timer_conn = cls.timer.timeout.connect(cls.tick)
			except Exception:
				cls.timer = False
		if cls.timer and not cls.timer.isActive():
			cls.timer.start(10000, False)

	@classmethod
	def tick(cls):
		from time import time
		if time() - cls.used > cls.IDLE:
			cls.timer.stop()
			cls.history = []  # a gap: an old chart would mislead
			cls.last = None
			return
		cls.sample()

	@classmethod
	def bar(cls, index):
		# Value 0..100 of bar <index> (0 oldest, HISTORY - 1 newest); empty until that many samples exist.
		cls.start()
		pos = len(cls.history) - cls.HISTORY + index
		if pos < 0:
			return 0
		top = max(cls.history)
		value = cls.history[pos]
		return max(3, int(value * 100 / top)) if top > 0 and value > 0 else 0

	@classmethod
	def counters(cls):
		best = None
		try:
			with open("/proc/net/dev") as f:
				for line in f.readlines()[2:]:
					name, data = line.split(":", 1)
					name = name.strip()
					if name == "lo" or name.startswith(("sit", "tun", "docker")):
						continue
					values = data.split()
					rx, tx = int(values[0]), int(values[8])
					if best is None or rx + tx > best[1] + best[2]:
						best = (name, rx, tx)
		except Exception:
			pass
		return best

	@classmethod
	def sample(cls):
		from time import time
		now = time()
		if cls.last and now - cls.last[0] < 5:
			return cls.rate
		cur = cls.counters()
		if cur:
			name, rx, tx = cur
			if cls.last and cls.last[1] == name and rx >= cls.last[2] and tx >= cls.last[3]:
				dt = now - cls.last[0]
				cls.rate = ((rx - cls.last[2]) * 8 / dt, (tx - cls.last[3]) * 8 / dt)
			else:
				cls.rate = (0.0, 0.0)  # first sample, interface change or counter reset
			if cls.last:
				cls.history = (cls.history + [cls.rate[0]])[-cls.HISTORY:]
			cls.last = (now, name, rx, tx)
			cls.iface = name
		return cls.rate


class InternetCheck(object):
	# Internet reachability for the network badge: a TCP connection attempt to public DNS servers (no data is
	# sent) at most once a minute, in a background thread so the screen never waits. None until the first result.
	state = None
	checked = 0.0
	running = False

	@classmethod
	def get(cls):
		from time import time
		if not cls.running and time() - cls.checked > 60:
			cls.running = True
			try:
				from threading import Thread
				t = Thread(target=cls.run)
				t.daemon = True
				t.start()
			except Exception:
				cls.running = False
		return cls.state

	@classmethod
	def run(cls):
		import socket
		from time import time
		result = False
		for host in ("1.1.1.1", "8.8.8.8"):
			try:
				s = socket.create_connection((host, 53), timeout=3)
				s.close()
				result = True
				break
			except Exception:
				pass
		cls.state = result
		cls.checked = time()
		cls.running = False


class UpdateCheck(object):
	# Latest released version, read from a one-line file in the public repository (only that small file is fetched,
	# nothing is sent). Background thread, 5 s timeout; at most every 6 hours, 30 minutes after a failure. Runs only
	# while the Floating main menu or Obsidian FHD Settings is open. latest is "" until a result exists.
	URL = "https://raw.githubusercontent.com/dali44g/Obsidian-FHD/main/release/version.txt"
	latest = ""
	checked = 0.0
	wait = 0
	running = False

	@classmethod
	def get(cls):
		from time import time
		if not cls.running and time() - cls.checked > cls.wait:
			cls.running = True
			try:
				from threading import Thread
				t = Thread(target=cls.run)
				t.daemon = True
				t.start()
			except Exception:
				cls.running = False
		return cls.latest

	@classmethod
	def run(cls):
		import re
		from time import time
		ok = False
		try:
			try:
				from urllib.request import urlopen
			except ImportError:
				from urllib2 import urlopen
			# Verified HTTPS only; on an image without CA certificates the check simply stays silent.
			data = urlopen(cls.URL, timeout=5).read(64)
			m = re.match(r"\s*([0-9]+(\.[0-9]+){0,3})\s*$", data.decode("ascii", "ignore") if isinstance(data, bytes) else data)
			if m:
				cls.latest = m.group(1)
				ok = True
		except Exception:
			pass
		cls.checked = time()
		cls.wait = 21600 if ok else 1800
		cls.running = False


def shortNumbers(text):
	# PliExtraInfo on OpenATV prints raw tuner values ("12558000", "27500000"); OpenPLi prints "12558", "27500".
	# Stand-alone numbers of 6+ digits (not inside URLs) become MHz / ksym/s (Hz -> MHz on DVB-T); PLS / MIS codes are left as they are.
	import re
	dvbt = "DVB-T" in text

	def short(m):
		before = text[max(0, m.start() - 8):m.start()].lower()
		if "gold" in before or "root" in before or "combo" in before or "pls" in before or "mis" in before:
			return m.group(0)
		n = int(m.group(0))
		return str(n // 1000000 if dvbt or n >= 100000000 else n // 1000)
	return re.sub(r"(?<!\S)\d{6,}(?!\S)", short, text)


def eventServiceName(source):
	# Name of the channel selected in the channel list (ServiceEvent source), only when it has a programme: bouquets
	# and channels without EPG give "", so nothing shows in the bouquet view.
	try:
		if not getattr(source, "event", None):
			return ""
		ref = source.service if hasattr(source, "service") else source.getCurrentService()
		from enigma import eServiceCenter
		info = ref and eServiceCenter.getInstance().info(ref)
		name = info and info.getName(ref) or ""
		for marker in ("\xc2\x86", "\xc2\x87", "\x86", "\x87"):
			name = name.replace(marker, "")
		return name
	except Exception:
		return ""


def versionTuple(text):
	try:
		parts = [int(x) for x in text.lstrip("v").split(".")]
		return tuple(parts + [0] * (4 - len(parts)))
	except Exception:
		return ()


def updateAvailable():
	# Newer release than the installed skin: its version ("1.4.1"), otherwise "".
	latest = UpdateCheck.get()
	current = versionTuple(skinVersion())
	return latest if latest and current and versionTuple(latest) > current else ""


class Disks(object):
	# Local disks mounted under /media (USB sticks, internal HDD/SSD, SD cards), one entry per device, the internal
	# /media/hdd first. Network shares, RAM disks and autofs are skipped: statvfs on them can block or is meaningless.
	cache = (0.0, [])
	about = {}  # device -> (kind, model): fixed for a plugged device, read from /sys once
	PREFIXES = ("/dev/sd", "/dev/mmcblk", "/dev/nvme", "/dev/hd")

	@classmethod
	def kind(cls, device):
		try:
			from os.path import realpath
			name = device.split("/")[-1]
			disk = name.rstrip("0123456789")
			if disk.startswith(("mmcblk", "nvme")) and "p" in name:
				disk = name.rsplit("p", 1)[0]
			if disk.startswith("mmcblk"):
				return "SD"
			path = realpath("/sys/block/%s/device" % disk)  # works whether /sys/block/sdX is a link or a directory
			if "/usb" in path:
				return "USB"
			return "SSD" if readFirst(("/sys/block/%s/queue/rotational" % disk,)) == "0" else "HDD"
		except Exception:
			return "DISK"

	@classmethod
	def model(cls, device):
		# "Kingston DataTraveler 3.0" from /sys/block/<disk>/device/{vendor,model}. The vendor "ATA" (internal SATA)
		# and generic placeholders are dropped; all-caps brand words are tidied ("KINGSTON" -> "Kingston").
		try:
			name = device.split("/")[-1]
			disk = name.rstrip("0123456789")
			if disk.startswith(("mmcblk", "nvme")) and "p" in name:
				disk = name.rsplit("p", 1)[0]
			vendor = readFirst(("/sys/block/%s/device/vendor" % disk,))
			model = readFirst(("/sys/block/%s/device/model" % disk, "/sys/block/%s/device/name" % disk))
			words = []
			for part in (vendor, model):
				for w in part.split():
					if w.upper() in ("ATA", "GENERIC", "USB", "MASS", "STORAGE", "DEVICE", "DISK", "FLASH"):
						continue
					if w.isalpha() and w.isupper() and len(w) > 3:
						w = w.capitalize()
					if w.lower() not in [x.lower() for x in words]:
						words.append(w)
			return " ".join(words)
		except Exception:
			return ""

	@classmethod
	def get(cls):
		from time import time
		now = time()
		if now - cls.cache[0] < 5:
			return cls.cache[1]
		found, seen = [], set()
		try:
			with open("/proc/mounts") as f:
				for line in f:
					parts = line.split()
					if len(parts) < 3:
						continue
					device, mount = parts[0], parts[1]
					if not device.startswith(cls.PREFIXES) or not mount.startswith("/media/") or mount.startswith(("/media/net", "/media/autofs")):
						continue
					if device in seen:
						continue
					seen.add(device)
					found.append((device, mount))
		except Exception:
			pass
		found.sort(key=lambda d: (d[1] != "/media/hdd", d[1]))
		disks, counts = [], {}
		if set(cls.about) != seen:  # a disk was plugged or removed: read every model again
			cls.about = {}
		for device, mount in found:
			if device not in cls.about:
				cls.about[device] = (cls.kind(device), cls.model(device))
			kind, model = cls.about[device]
			counts[kind] = counts.get(kind, 0) + 1
			total, free = diskInfo(mount)
			if total:
				disks.append([kind, counts[kind], total, free, model])
		for d in disks:  # number only kinds that appear more than once: USB 1, USB 2
			d[0] = "%s %d" % (d[0], d[1]) if counts[d[0]] > 1 else d[0]
		cls.cache = (now, disks)
		return disks

	@classmethod
	def row(cls, index):
		disks = cls.get()
		return disks[index] if index < len(disks) else None



# Dashboard labels in French and Arabic (English is the key). Escaped so the source stays ASCII.
class CpuSampler(object):
	# Busy share of all CPUs from /proc/stat, between two samples at least 5 s apart (shared by every widget).
	last = None  # (time, idle, total)
	percent = 0

	@classmethod
	def sample(cls):
		from time import time
		now = time()
		if cls.last and now - cls.last[0] < 5:
			return cls.percent
		try:
			values = [int(v) for v in readFirst(("/proc/stat",)).split("\n")[0].split()[1:]]
			idle, total = values[3] + (values[4] if len(values) > 4 else 0), sum(values)
		except Exception:
			return cls.percent
		if cls.last and total > cls.last[2]:
			cls.percent = int(round(100.0 * (1 - float(idle - cls.last[1]) / (total - cls.last[2]))))
			cls.percent = min(100, max(0, cls.percent))
		cls.last = (now, idle, total)
		return cls.percent


CpuSampler.sample()  # first reading at skin load, so the first value shown on a screen is already real


def tunersText():
	# "A DVB-S2  B DVB-S2" from /proc/bus/nim_sockets (empty when the file is missing, e.g. IPTV-only boxes).
	tuners, slot = [], None
	for line in readFirst(("/proc/bus/nim_sockets",)).split("\n"):
		line = line.strip()
		if line.startswith("NIM Socket"):
			try:
				slot = int(line.split()[2].rstrip(":"))
			except Exception:
				slot = None
		elif line.startswith("Type:") and slot is not None:
			kind = line[5:].strip()
			if kind and kind.lower() != "none":
				tuners.append("%s %s" % (chr(65 + slot), kind))
			slot = None
	return "  ".join(tuners)


def linkText():
	# Wired link speed of the busiest interface, "100 Mbit/s"; "" for Wi-Fi or an unknown speed.
	try:
		speed = int(readFirst(("/sys/class/net/%s/speed" % (NetSampler.iface or "eth0"),)))
	except Exception:
		return ""
	return "%d Mbit/s" % speed if speed > 0 else ""


TRANSLATIONS = {
	"MAIN MENU": (u"MENU PRINCIPAL", u"\u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0631\u0626\u064a\u0633\u064a\u0629"),
	"HELP": (u"AIDE", u"\u0645\u0633\u0627\u0639\u062f\u0629"),
	"OPTIONS": (u"OPTIONS", u"\u062e\u064a\u0627\u0631\u0627\u062a"),
	"SELECT": (u"CHOISIR", u"\u0627\u062e\u062a\u064a\u0627\u0631"),
	"CHANNEL": (u"CHA\u00ceNE", u"\u0627\u0644\u0642\u0646\u0627\u0629"),
	"TEMP": (u"TEMP", u"\u0627\u0644\u062d\u0631\u0627\u0631\u0629"),
	"Board sensor": (u"Capteur carte", u"\u0645\u0633\u062a\u0634\u0639\u0631 \u0627\u0644\u0644\u0648\u062d\u0629"),
	"Load, 1 min": (u"Charge, 1 min", u"\u0627\u0644\u062d\u0645\u0644\u060c \u062f\u0642\u064a\u0642\u0629"),
	"FAN": (u"VENTILO", u"\u0627\u0644\u0645\u0631\u0648\u062d\u0629"),
	"UPTIME": (u"EN MARCHE", u"\u0645\u062f\u0629 \u0627\u0644\u062a\u0634\u063a\u064a\u0644"),
	"Since boot": (u"Depuis d\u00e9marrage", u"\u0645\u0646\u0630 \u0627\u0644\u0625\u0642\u0644\u0627\u0639"),
	"SYSTEM": (u"SYST\u00c8ME", u"\u0627\u0644\u0646\u0638\u0627\u0645"),
	"NETWORK": (u"R\u00c9SEAU", u"\u0627\u0644\u0634\u0628\u0643\u0629"),
	"STORAGE": (u"STOCKAGE", u"\u0627\u0644\u062a\u062e\u0632\u064a\u0646"),
	"RECEIVER": (u"R\u00c9CEPTEUR", u"\u0627\u0644\u062c\u0647\u0627\u0632"),
	"RAM": (u"RAM", u"\u0627\u0644\u0630\u0627\u0643\u0631\u0629"),
	"CPU": (u"CPU", u"\u0627\u0644\u0645\u0639\u0627\u0644\u062c"),
	"Model": (u"Mod\u00e8le", u"\u0627\u0644\u0637\u0631\u0627\u0632"),
	"Image": (u"Image", u"\u0627\u0644\u0646\u0638\u0627\u0645"),
	"Tuners": (u"Tuners", u"\u0627\u0644\u0645\u0648\u0627\u0644\u0641\u0627\u062a"),
	"Skin": (u"Skin", u"\u0627\u0644\u0633\u0643\u064a\u0646"),
	"DOWNLOAD": (u"DESCENDANT", u"\u062a\u0646\u0632\u064a\u0644"),
	"UPLOAD": (u"MONTANT", u"\u0631\u0641\u0639"),
	"USED": (u"UTILISÉ", u"مستخدم"),
	"LOAD AVG": (u"CHARGE", u"الحمل"),
	"peak %s": (u"pic %s", u"الذروة %s"),
	"now": (u"maintenant", u"الآن"),
	"2.5 min": (u"2.5 min", u"2.5 د"),
	"Average, 10 s": (u"Moyenne, 10 s", u"\u0645\u062a\u0648\u0633\u0637 10 \u062b"),
	"ONLINE": (u"EN LIGNE", u"\u0645\u062a\u0635\u0644"),
	"OFFLINE": (u"HORS LIGNE", u"\u063a\u064a\u0631 \u0645\u062a\u0635\u0644"),
	"LOW": (u"BAS", u"\u0645\u0646\u062e\u0641\u0636"),
	"free": (u"libre", u"\u0645\u062a\u0627\u062d"),
	"not mounted": (u"non mont\u00e9", u"\u063a\u064a\u0631 \u0645\u0648\u0635\u0648\u0644"),
	"more": (u"autres", u"\u0623\u062e\u0631\u0649"),
	"Update %s available": (u"Mise \u00e0 jour %s disponible", u"\u062a\u062d\u062f\u064a\u062b %s \u0645\u062a\u0627\u062d"),
	"d": (u"j", u"\u064a"),
	"h": (u"h", u"\u0633"),
	"m": (u"min", u"\u062f"),
	"HINTS_OK": (u"Ouvrir", u"\u0641\u062a\u062d"),
	"HINTS_EXIT": (u"Retour", u"\u0631\u062c\u0648\u0639"),
	"HINTS_MENU": (u"Fermer", u"\u0625\u063a\u0644\u0627\u0642"),
	"HINTS_SELECT": (u"Choisir", u"\u0627\u062e\u062a\u064a\u0627\u0631"),
}


def language():
	try:
		from Components.Language import language as lang
		return (lang.getLanguage() or "")[:2]
	except Exception:
		return ""


def tr(key):
	# Translated label for the box language (fr / ar), otherwise the English key. UTF-8 str on Python 2.
	lang = language()
	text = key
	if lang in ("fr", "ar") and key in TRANSLATIONS:
		text = TRANSLATIONS[key][0 if lang == "fr" else 1]
	elif key.startswith("HINTS_"):
		text = {"HINTS_OK": "Open", "HINTS_EXIT": "Back", "HINTS_MENU": "Close", "HINTS_SELECT": "Select"}.get(key, key)
	try:
		unicode
		return text.encode("utf-8") if isinstance(text, unicode) else text
	except NameError:
		return text
_skinVersion = None


def skinVersion():
	# Read once from the "OBSIDIAN FHD  vX.Y" header text, the single place the version is written.
	global _skinVersion
	if _skinVersion is None:
		_skinVersion = ""
		try:
			import re
			with open("/usr/share/enigma2/Obsidian-FHD/skin_templates.xml") as f:
				m = re.search(r"OBSIDIAN FHD\s+v([0-9][0-9.]*)", f.read())
			if m:
				_skinVersion = "v" + m.group(1)
		except Exception:
			pass
	return _skinVersion


def imageName():
	info = {}
	try:
		with open("/etc/image-version") as f:
			for line in f:
				if "=" in line:
					k, v = line.strip().split("=", 1)
					info[k] = v
	except Exception:
		pass
	distro, version = info.get("distro", ""), info.get("version", "")
	if not distro:
		parts = readFirst(("/etc/issue",)).splitlines()
		words = parts[-1].split() if parts else []
		distro, version = (words[0], words[1]) if len(words) >= 2 else ("", "")
	names = {"openatv": "OpenATV", "openpli": "OpenPLi", "openvix": "OpenViX", "openbh": "OpenBH", "egami": "EGAMI"}
	return ("%s %s" % (names.get(distro.lower(), distro), version)).strip()


def imageInfo():
	return ("  " + DOT + "  ").join(x for x in (imageName(), receiverModel()) if x)


def rateText(bits):
	if bits >= 1000000:
		return "%.1f Mbit/s" % (bits / 1000000.0)
	if bits >= 1000:
		return "%d kbit/s" % (bits / 1000)
	return "0 kbit/s"


# Values that cannot change while enigma2 runs: computed once, never polled.
STATIC = ("Model", "ImageName", "ImageInfo", "Tuners", "SkinVersion", "Hints")
STATIC_VALUES = {}
STATE_LABELS = ("Label:ONLINE", "Label:OFFLINE", "Label:LOW")  # labels shown / hidden by a state: polled


def onScreen(element):
	"""True when a widget fed by this converter is on a visible screen. enigma2 keeps polling converters of screens
	built hidden at boot (channel list, second infobar, infobar), so each poll checks this first and does nothing
	while hidden. Any doubt counts as visible."""
	try:
		for down in element.downstream_elements:
			widget = getattr(down, "instance", None)
			if widget is None:
				if getattr(down, "downstream_elements", None) is not None and onScreen(down):
					return True  # chained converter
				continue
			# the widget's own flag is left out: ConditionalShowHide hides it, and only a poll can show it again
			widget, depth = widget.getParent(), 0
			while widget is not None and depth < 20:
				if not widget.isVisible():
					break
				widget, depth = widget.getParent(), depth + 1
			else:
				return True
		return False
	except Exception:
		return True


class ObsidianSysInfo(Poll, Converter):
	# One screen holds many of these (83 on the Edge main menu). To keep menus fast: static values are not polled,
	# a poll redraws its widget only when the value really changed, and the instances of one type share one
	# computation per 2 s (every type here is global, not tied to the widget's source).
	shared = {}

	def __init__(self, type):
		Converter.__init__(self, type)
		Poll.__init__(self)
		self.type = type
		self.last = None
		self.poll_interval = 10000
		static = type in STATIC or (type.startswith("Label:") and type not in STATE_LABELS)
		# "Short" and "EventServiceName" follow their source's updates, no polling needed.
		self.poll_enabled = not static and type not in ("Short", "EventServiceName", "IfEvent")

	def output(self):
		from time import time
		now = time()
		hit = ObsidianSysInfo.shared.get(self.type)
		if hit and now - hit[0] < 2:
			return hit[1]
		out = (self.getText(), self.getValue(), self.getBoolean())
		ObsidianSysInfo.shared[self.type] = (now, out)
		return out

	def poll(self):
		try:
			out = self.output()
		except Exception:
			out = None
		if out != self.last:
			self.last = out
			self.changed((self.CHANGED_POLL,))

	def ssdMounted(self):
		return ismount(SSD)

	@cached
	def getText(self):
		if self.type in STATIC:
			value = STATIC_VALUES.get(self.type)
			if not value:  # an empty result is retried (e.g. the image metadata not ready yet)
				value = STATIC_VALUES[self.type] = self.textOf()
			return value
		return self.textOf()

	def textOf(self):
		try:
			t = self.type
			if t == "Short":
				return shortNumbers(self.source.text or "")
			if t == "EventServiceName":
				return eventServiceName(self.source)
			if t == "IfEvent":
				# Chained after another converter on ServiceEvent: its text only when the entry has a programme.
				root = self.source
				while root is not None and not hasattr(root, "event") and getattr(root, "source", None) is not None:
					root = root.source
				return (self.source.text or "") if getattr(root, "event", None) else ""
			if t.startswith("Label:"):
				return tr(t[6:])
			if t == "Hints":
				return "OK  %s     EXIT  %s     MENU  %s" % (tr("HINTS_OK"), tr("HINTS_EXIT"), tr("HINTS_MENU"))
			if t == "Temp":
				return HardwareSensors.temperature()
			if t == "CpuPercent":
				return "%d%%" % CpuSampler.sample()
			if t == "TempShort":
				value = HardwareSensors.celsius()
				return "" if value is None else "%d%s" % (round(value), DEG)
			if t == "Tuners":
				return tunersText()
			if t == "NetLink":
				return linkText()
			if t == "CpuLoad":
				raw = readFirst(("/proc/loadavg",))
				return raw.split()[0] if raw else ""
			if t == "Fan":
				return HardwareSensors.fan()
			if t == "FanRpm":
				rpm = HardwareSensors.fan()
				return rpm + " rpm" if rpm.isdigit() else rpm
			if t == "NetPeak":
				NetSampler.start()
				return tr("peak %s") % rateText(max(NetSampler.history)) if NetSampler.history and max(NetSampler.history) > 0 else ""
			if t == "FlashPercent":
				total, free = diskInfo("/")
				return "%d%%" % ((total - free) * 100 // total) if total else ""
			if t[:11] == "DiskPercent" and t[11:].isdigit():
				index = int(t[11:]) - 1
				if index == 2 and len(Disks.get()) > 3:
					return ""
				row = Disks.row(index)
				return "%d%%" % ((row[2] - row[3]) * 100 // row[2]) if row and row[2] else ""
			if t == "Uptime":
				raw = readFirst(("/proc/uptime",))
				if not raw:
					return ""
				secs = int(float(raw.split()[0]))
				days, rest = divmod(secs, 86400)
				return "%d%s %d%s" % (days, tr("d"), rest // 3600, tr("h")) if days else "%d%s %d%s" % (rest // 3600, tr("h"), (rest % 3600) // 60, tr("m"))
			if t == "Ip":
				return self.ip()
			if t[:9] == "DiskModel" and t[9:].isdigit():
				index = int(t[9:]) - 1
				if index == 2 and len(Disks.get()) > 3:
					return ""
				row = Disks.row(index)
				return row[4] if row else ""
			if t[:8] in ("DiskName", "DiskText") and t[8:].isdigit():
				index = int(t[8:]) - 1
				disks = Disks.get()
				if index == 2 and len(disks) > 3 and t.startswith("DiskName"):
					return "+%d %s" % (len(disks) - 2, tr("more"))
				if index == 2 and len(disks) > 3:
					return ""
				row = Disks.row(index)
				if not row:
					return ""
				return row[0] if t.startswith("DiskName") else "%s %s" % (sizeText(row[3]), tr("free"))
			if t == "UpdateText":
				latest = updateAvailable()
				return tr("Update %s available") % ("v" + latest) if latest else ""
			if t == "SkinVersion":
				return skinVersion()
			if t == "ImageInfo":
				return imageInfo()
			if t == "ImageName":
				return imageName()
			if t == "Model":
				return receiverModel()
			if t == "NetDown":
				NetSampler.start()
				return rateText(NetSampler.sample()[0])
			if t == "NetUp":
				NetSampler.start()
				return rateText(NetSampler.sample()[1])
			if t == "NetIface":
				NetSampler.start()
				NetSampler.sample()
				name = NetSampler.iface
				return ("Wi-Fi" if name.startswith(("wlan", "wl", "ra")) else "Ethernet") + ("  " + DOT + "  " + name if name else "") if name else ""
			if t == "RamStep":
				total, used = memInfo()
				return str(min(20, int(round(used * 20.0 / total)))) if total else "0"
			if t == "RamPercent":
				total, used = memInfo()
				return "%d%%" % (used * 100 // total) if total else ""
			if t == "RamText":
				total, used = memInfo()
				return "%d / %d MB" % (used, total) if total else ""
			if t == "FlashText":
				total, free = diskInfo("/")
				return "%s %s" % (sizeText(free), tr("free")) if total else ""
			if t == "UsbText":
				if not ismount(USB):
					return tr("not mounted")
				total, free = diskInfo(USB)
				return "%s %s" % (sizeText(free), tr("free")) if total else ""
			if t == "SsdText":
				if not self.ssdMounted():
					return tr("not mounted")
				total, free = diskInfo(SSD)
				return "%s %s" % (sizeText(free), tr("free")) if total else ""
		except Exception:
			pass
		return ""

	text = property(getText)

	@cached
	def getValue(self):
		try:
			t = self.type
			if t == "CpuUsed":
				return CpuSampler.sample()
			if t[:7] == "NetHist" and t[7:].isdigit():
				return NetSampler.bar(int(t[7:]))
			if t == "TempUsed":
				value = HardwareSensors.celsius()
				return None if value is None else min(100, max(0, int(round(value))))
			if t == "RamUsed":
				total, used = memInfo()
				return used * 100 // total if total else 0
			if t == "FlashUsed":
				total, free = diskInfo("/")
				return (total - free) * 100 // total if total else 0
			if t.startswith("DiskUsed") and t[8:].isdigit():
				index = int(t[8:]) - 1
				if index == 2 and len(Disks.get()) > 3:
					return 0
				row = Disks.row(index)
				return (row[2] - row[3]) * 100 // row[2] if row and row[2] else 0
			if t == "UsbUsed":
				if not ismount(USB):
					return 0
				total, free = diskInfo(USB)
				return (total - free) * 100 // total if total else 0
			if t == "SsdUsed":
				if not self.ssdMounted():
					return 0
				total, free = diskInfo(SSD)
				return (total - free) * 100 // total if total else 0
		except Exception:
			pass
		return 0

	value = property(getValue)
	range = 100

	def booleanFor(self, t):
		if t.startswith("Disk") and t[4:].isdigit():
			return Disks.row(int(t[4:]) - 1) is not None
		if t == "Online":
			return InternetCheck.get() is True
		if t == "Offline":
			return InternetCheck.get() is False
		if t in ("Update", "UpdateText"):
			return updateAvailable() != ""
		if t == "FlashLow":
			total, free = diskInfo("/")
			return bool(total) and free < 15 * 1048576
		return False

	@cached
	def getBoolean(self):
		try:
			# Translated badge texts ("Label:ONLINE") show only in their state.
			t = {"Label:ONLINE": "Online", "Label:OFFLINE": "Offline", "Label:LOW": "FlashLow"}.get(self.type, self.type)
			return self.booleanFor(t)
		except Exception:
			return False

	boolean = property(getBoolean)

	def ip(self):
		# Address of the first non-loopback IPv4 route (no packets are sent).
		try:
			import socket
			s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
			try:
				s.connect(("10.255.255.255", 1))
				return s.getsockname()[0]
			finally:
				s.close()
		except Exception:
			return ""

	def changed(self, what):
		try:
			Converter.changed(self, what)
		except Exception:
			pass
