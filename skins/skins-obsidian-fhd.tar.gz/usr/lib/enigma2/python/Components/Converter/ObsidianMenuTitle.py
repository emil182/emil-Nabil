# Obsidian FHD: last part of a menu title such as "Main Menu > Setup > Usage & GUI" -> "Usage & GUI".
# Used for the submenu card header of the Floating menu style (skin_sysinfo.xml).
# <convert type="ObsidianMenuTitle">Parent</convert>: the path before it, "Main Menu > Setup" ("" for a top-level title);
# used for the Edge breadcrumb.
# <convert type="ObsidianMenuTitle">Bouquet</convert>: a channel list title without its mode, "TV - Sports - HD" -> "Sports - HD".
# <convert type="ObsidianMenuTitle">Stacked</convert>: the whole path, one level per line (Matchday menu panel).
from gettext import gettext

from Components.Converter.Converter import Converter
from Components.Element import cached


class ObsidianMenuTitle(Converter):
	def __init__(self, type):
		Converter.__init__(self, type)
		self.parent = type == "Parent"
		self.bouquet = type == "Bouquet"
		self.stacked = type == "Stacked"

	@cached
	def getText(self):
		try:
			text = self.source.text or ""
			if self.bouquet:
				mode, sep, rest = text.partition(" - ")
				return rest.strip() if sep and mode in ("TV", "Radio", gettext("TV"), gettext("Radio")) else text.strip()
			for sep in (" > ", " / ", " - "):
				if sep in text:
					parts = text.split(sep)
					if self.stacked:
						return u"\n\u203a ".join(x.strip() for x in parts)
					return sep.join(parts[:-1]).strip() if self.parent else parts[-1].strip()
			return "" if self.parent else text.strip()
		except Exception:
			return ""

	text = property(getText)
