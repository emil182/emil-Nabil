# -*- coding: utf-8 -*-
"""Selected-service guide. Local EPG only; bounded queries, no downloads or hooks."""
import re
from time import localtime, mktime, strftime, time
from enigma import eEPGCache, eServiceReference, iServiceInformation
from Components.Converter.Converter import Converter
from Components.Converter.Poll import Poll
from Components.Element import cached


def displayStreamUrl(url):
	# Display only: never change the reference used for playback or request the URL.
	try:
		try:
			from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
		except ImportError:
			from urlparse import urlsplit, urlunsplit, parse_qsl
			from urllib import urlencode
		parts = urlsplit(url)
		host = parts.netloc.rsplit('@', 1)[-1]
		if '@' in parts.netloc:
			host = '***@' + host
		path = parts.path.split('/')
		# Common Xtream URLs contain account credentials as path segments.
		if len(path) >= 5 and path[1].lower() in ('live', 'movie', 'series'):
			path[2:] = ['***']
		elif parts.path:
			# Unknown paths may contain account names, passwords or signed tokens.
			path = ['', '***']
		query = urlencode([(key, '***' if value else '') for key, value in parse_qsl(parts.query, keep_blank_values=True)])
		query = query.replace('%2A%2A%2A', '***')
		return urlunsplit((parts.scheme, host, '/'.join(path), query, '***' if parts.fragment else ''))
	except Exception:
		return 'Stream URL unavailable'


def channelTechnical(source):
	"""Selected-service metadata only; no tuning and no inferred IPTV host/provider."""
	service = source.service
	static = isinstance(service, eServiceReference)
	info = source.info if static else service.info()
	ref = service if static else getattr(source, 'serviceref', None)
	try:
		from ServiceReference import resolveAlternate
		resolved = resolveAlternate(ref) if ref else None
		if resolved:
			from enigma import eServiceCenter
			ref = resolved
			info = eServiceCenter.getInstance().info(ref)
	except Exception:
		pass
	path = ref.getPath() if ref and hasattr(ref, 'getPath') else ''
	if '://' in path:
		return 'STREAM', displayStreamUrl(path)
	try:
		raw = info.getInfoObject(ref, iServiceInformation.sTransponderData) if static else info.getInfoObject(iServiceInformation.sTransponderData)
	except Exception:
		raw = None
	if not isinstance(raw, dict) or not raw:
		return ('VIDEO' if path else 'Service information unavailable'), ''
	try:
		from Tools.Transponder import ConvertToHumanReadable
		data = ConvertToHumanReadable(dict(raw))
	except Exception:
		data = {}
	kind = str(raw.get('tuner_type') or '')
	header = [str(data.get('system') or kind or 'DVB')]
	if 'DVB-S' in kind and raw.get('orbital_position') is not None:
		position = int(raw['orbital_position'])
		satellite = data.get('orbital_position')
		header.append(satellite.strip() if hasattr(satellite, 'strip') and satellite.strip() else '%.1f%s %s' % ((3600 - position if position > 1800 else position) / 10.0, u'\u00b0', 'W' if position > 1800 else 'E'))
	# The tuner belongs to the playing service, so include it only on an exact match.
	try:
		from NavigationInstance import instance as nav
		playing = nav.getCurrentlyPlayingServiceReference()
		if ref and playing and ref.toString() == playing.toString():
			frontend = nav.getCurrentService().frontendInfo().getFrontendData()
			tuner = frontend.get('tuner_number')
			if isinstance(tuner, int) and 0 <= tuner < 26:
				header.append('Tuner ' + chr(65 + tuner))
	except Exception:
		pass
	details = []
	frequency = raw.get('frequency')
	if frequency:
		# DVB-S/C use kHz here; terrestrial and ATSC expose Hz.
		details.append('%g MHz' % (float(frequency) / (1000 if 'DVB-S' in kind or 'DVB-C' in kind else 1000000)))
	for key in ('polarization_abbreviation',):
		if data.get(key):
			details.append(str(data[key]))
	if raw.get('symbol_rate'):
		details.append('%g kSym/s' % (float(raw['symbol_rate']) / 1000))
	for key in ('fec_inner', 'modulation'):
		if data.get(key) is not None:
			details.append(str(data[key]))
	return ' / '.join(header), ' / '.join(details)


def channelCompact(source):
	"""Short frequency line of the selected service for small spaces: "16.0°E · 11595 V 30000" (satellite),
	"346 MHz" (cable / terrestrial), "STREAM" for IPTV. Same data as channelTechnical, no tuning."""
	service = source.service
	static = isinstance(service, eServiceReference)
	info = source.info if static else service.info()
	ref = service if static else getattr(source, 'serviceref', None)
	try:
		from ServiceReference import resolveAlternate
		resolved = resolveAlternate(ref) if ref else None
		if resolved:
			from enigma import eServiceCenter
			ref = resolved
			info = eServiceCenter.getInstance().info(ref)
	except Exception:
		pass
	path = ref.getPath() if ref and hasattr(ref, 'getPath') else ''
	if '://' in path:
		return 'STREAM'
	try:
		raw = info.getInfoObject(ref, iServiceInformation.sTransponderData) if static else info.getInfoObject(iServiceInformation.sTransponderData)
	except Exception:
		raw = None
	if not isinstance(raw, dict) or not raw:
		return ''
	kind = str(raw.get('tuner_type') or '')
	frequency = raw.get('frequency')
	if 'DVB-S' in kind:
		parts = []
		if raw.get('orbital_position') is not None:
			position = int(raw['orbital_position'])
			parts.append('%.1f%s%s' % ((3600 - position if position > 1800 else position) / 10.0, u'\u00b0', 'W' if position > 1800 else 'E'))
		line = []
		if frequency:
			line.append('%d' % round(float(frequency) / 1000))
		if raw.get('polarization') in (0, 1, 2, 3):
			line.append('HVLR'[raw['polarization']])
		if raw.get('symbol_rate'):
			line.append('%d' % round(float(raw['symbol_rate']) / 1000))
		parts.append(' '.join(line))
		return u' \u00b7 '.join(x for x in parts if x)
	if frequency:
		return '%g MHz' % (float(frequency) / (1000 if 'DVB-C' in kind else 1000000))
	return ''


LAMEDB = {"mtime": None, "providers": {}}


def lamedbProvider(ref):
	# Provider from the channel database (/etc/enigma2/lamedb or lamedb5): many images return no provider for a
	# service that is not playing. Read once and again only when the file changes.
	try:
		import os
		path = "/etc/enigma2/lamedb5" if os.path.isfile("/etc/enigma2/lamedb5") else "/etc/enigma2/lamedb"
		mtime = os.path.getmtime(path)
		if LAMEDB["mtime"] != mtime:
			providers = {}
			with open(path, "rb") as f:
				lines = f.read().decode("utf-8", "ignore").splitlines()
			if path.endswith("5"):
				# s:sid:ns:tsid:onid:type:number,"name",p:Provider,...
				for line in lines:
					if line.startswith("s:"):
						head, _, rest = line.partition(",")
						parts = head[2:].split(":")
						match = re.search(r'(?:^|,)p:([^,]*)', rest)
						if len(parts) >= 4 and match:
							providers[tuple(int(x, 16) for x in parts[:4])] = match.group(1)
			else:
				# services section: "sid:ns:tsid:onid:type:number", name, "p:Provider,c:..."
				inside = False
				i = 0
				while i < len(lines):
					line = lines[i]
					if line == "services":
						inside = True
					elif inside and line == "end":
						break
					elif inside and line.count(":") >= 4 and i + 2 < len(lines):
						parts = line.split(":")
						match = re.search(r'(?:^|,)p:([^,]*)', lines[i + 2])
						if match:
							providers[tuple(int(x, 16) for x in parts[:4])] = match.group(1)
						i += 3
						continue
					i += 1
			LAMEDB["providers"], LAMEDB["mtime"] = providers, mtime
		# reference 1:0:type:SID:TSID:ONID:NS:...
		parts = ref.toString().split(":")
		sid, tsid, onid, ns = (int(x, 16) for x in parts[3:7])
		return LAMEDB["providers"].get((sid, ns, tsid, onid), "").strip()
	except Exception:
		return ""


def providerName(source):
	# Prefer selected-service metadata; live information is safe only on an exact match.
	service = source.service
	static = isinstance(service, eServiceReference)
	info = source.info if static else service.info()
	refs = [service] if static else []
	sref = getattr(source, 'serviceref', None)
	if sref is not None and sref not in refs:
		refs.append(sref)
	for ref in refs:
		try:
			value = ref.getProvider()
			if value and value.strip():
				return value.strip()
		except Exception:
			pass
		try:
			value = info.getInfoString(ref, iServiceInformation.sProvider)
			if value and value.strip():
				return value.strip()
		except Exception:
			pass
		try:
			from ServiceReference import resolveAlternate
			from enigma import eServiceCenter
			resolved = resolveAlternate(ref)
			if resolved and resolved.toString() != ref.toString():
				value = eServiceCenter.getInstance().info(resolved).getInfoString(resolved, iServiceInformation.sProvider)
				if value and value.strip():
					return value.strip()
		except Exception:
			pass
	if not static:
		try:
			value = info.getInfoString(iServiceInformation.sProvider)
			if value and value.strip():
				return value.strip()
		except Exception:
			pass
	else:
		try:
			from NavigationInstance import instance as nav
			selected = service.toString()
			playing = nav.getCurrentlyPlayingServiceReference()
			if selected and playing and selected == playing.toString():
				live = nav.getCurrentService()
				liveInfo = live.info() if live else None
				value = liveInfo.getInfoString(iServiceInformation.sProvider) if liveInfo else ''
				# A zap may have started while reading the service information.
				playing = nav.getCurrentlyPlayingServiceReference()
				if playing and selected == playing.toString() and value and value.strip():
					return value.strip()
		except Exception:
			pass
		for ref in refs:
			value = lamedbProvider(ref)
			if value:
				return value
	return '-'


def guide(cache, ref, now):
	rows = []
	event = cache.lookupEventTime(ref, int(now), 0)
	cursor = int(now)
	if event:
		cursor = max(cursor, event.getBeginTime() + event.getDuration() - 1)
	for unused in range(5):
		event = cache.lookupEventTime(ref, cursor, 1)
		if not event or event.getBeginTime() <= cursor:
			break
		begin, duration = event.getBeginTime(), event.getDuration()
		if duration <= 0:
			break
		rows.append((begin, event.getEventName() or 'Untitled programme'))
		cursor = begin + duration - 1
	return rows


def primeTime(now):
	# Prime time from the image's EPG settings (graph_primetimehour / _mins), 20:15 otherwise; today, or tomorrow when past.
	hour, minute = 20, 15
	try:
		from Components.config import config
		hour = int(config.epgselection.graph_primetimehour.value)
		minute = int(config.epgselection.graph_primetimemins.value)
	except Exception:
		pass
	if not (0 <= hour < 24 and 0 <= minute < 60):
		hour, minute = 20, 15
	d = localtime(now)
	target = mktime((d.tm_year, d.tm_mon, d.tm_mday, hour, minute, 0, 0, 0, -1))
	if target < now:
		target = mktime((d.tm_year, d.tm_mon, d.tm_mday + 1, hour, minute, 0, 0, 0, -1))
	return int(target)


def noGuideRows(source):
	"""Rows (label, value) of the no-guide card for the selected service: stored data only, no tuning."""
	service = source.service
	static = isinstance(service, eServiceReference)
	info = source.info if static else service.info()
	ref = service if static else getattr(source, 'serviceref', None)
	try:
		from ServiceReference import resolveAlternate
		resolved = resolveAlternate(ref) if ref else None
		if resolved:
			from enigma import eServiceCenter
			ref = resolved
			info = eServiceCenter.getInstance().info(ref)
	except Exception:
		pass
	path = ref.getPath() if ref and hasattr(ref, 'getPath') else ''
	if '://' in path:
		return [('TYPE', 'IPTV stream'), ('ADDRESS', displayStreamUrl(path))]
	try:
		raw = info.getInfoObject(ref, iServiceInformation.sTransponderData) if static else info.getInfoObject(iServiceInformation.sTransponderData)
	except Exception:
		raw = None
	if not isinstance(raw, dict) or not raw:
		return []
	try:
		from Tools.Transponder import ConvertToHumanReadable
		data = ConvertToHumanReadable(dict(raw))
	except Exception:
		data = {}
	kind = str(raw.get('tuner_type') or '')
	system = str(data.get('system') or kind or 'DVB')
	rows = []
	if 'DVB-S' in kind and raw.get('orbital_position') is not None:
		position = int(raw['orbital_position'])
		rows.append(('SATELLITE', u'%.1f\u00b0%s  \u00b7  %s' % ((3600 - position if position > 1800 else position) / 10.0, 'W' if position > 1800 else 'E', system)))
	else:
		rows.append(('SYSTEM', system))
	frequency = raw.get('frequency')
	if frequency:
		value = '%g MHz' % (float(frequency) / (1000 if 'DVB-S' in kind or 'DVB-C' in kind else 1000000))
		if data.get('polarization_abbreviation'):
			value += u'  \u00b7  %s' % data['polarization_abbreviation']
		rows.append(('FREQUENCY', value))
	if raw.get('symbol_rate'):
		rows.append(('SYMBOL RATE', '%g kSym/s' % (float(raw['symbol_rate']) / 1000)))
	coding = [str(data[key]) for key in ('fec_inner', 'modulation') if data.get(key) is not None]
	if coding:
		rows.append(('FEC / MOD', u'  \u00b7  '.join(coding)))
	return rows[:4]


SIGNAL = [0, None, None]


def tunerSignal():
	"""Live (snr, agc) in percent of the playing service, read at most once a second; None when not reported."""
	now = int(time())
	if SIGNAL[0] != now:
		snr = agc = None
		try:
			from NavigationInstance import instance as nav
			from enigma import iFrontendInformation
			frontend = nav.getCurrentService().frontendInfo()
			if frontend:
				snr = frontend.getFrontendInfo(iFrontendInformation.signalQuality)
				agc = frontend.getFrontendInfo(iFrontendInformation.signalPower)
		except Exception:
			pass
		# Some frontends report a small bogus AGC (below 256) instead of none.
		SIGNAL[:] = [now, snr * 100 // 65536 if snr else None, agc * 100 // 65536 if agc and agc > 255 else None]
	return SIGNAL[1], SIGNAL[2]


def onScreen(element):
	"""True when a widget fed by this converter is on a visible screen. enigma2 keeps polling converters of screens
	built hidden at boot (channel list, second infobar, infobar), so each poll checks this first and does nothing
	while hidden. Any doubt counts as visible."""
	try:
		for down in element.downstream_elements:
			widget = getattr(down, "instance", None)
			if widget is None:
				if getattr(down, "downstream_elements", None) is not None and onScreen(down):
					return True  # chained converter
				continue
			# the widget's own flag is left out: ConditionalShowHide hides it, and only a poll can show it again
			widget, depth = widget.getParent(), 0
			while widget is not None and depth < 20:
				if not widget.isVisible():
					break
				widget, depth = widget.getParent(), depth + 1
			else:
				return True
		return False
	except Exception:
		return True


class ObsidianChannelInfo(Poll, Converter):
	# One shared snapshot, not an ever-growing cache of channels.
	snapshot = None
	noGuideSnapshot = None  # (key, no guide?, rows): one read per selection, shared by all the card's widgets

	def __init__(self, mode):
		Converter.__init__(self, mode)
		Poll.__init__(self)
		self.mode = mode
		self.poll_interval = 1000 if mode.startswith(('SNR', 'AGC')) else 60000
		self.poll_enabled = True

	def poll(self):
		# SNR / AGC poll every second: redraw only when the value really changed (the others poll once a minute)
		if self.mode.startswith(('SNR', 'AGC')):
			try:
				value = tunerSignal() if self.mode == 'SNRLive' else self.signalValue()
			except Exception:
				value = None
			if value == getattr(self, 'lastPolled', 'unset'):
				return
			self.lastPolled = value
		self.changed((self.CHANGED_POLL,))

	def isChannel(self):
		"""The selection is a channel: not a bouquet, folder, provider/satellite entry or marker, nor an empty list."""
		try:
			service = self.source.service
			if not service:
				return False
			if not isinstance(service, eServiceReference):
				return True  # a running service
			if not service.valid() or service.flags & (eServiceReference.isDirectory | eServiceReference.mustDescent | eServiceReference.canDescent | eServiceReference.isMarker):
				return False
			return not service.toString().startswith("1:7:")
		except Exception:
			return False

	def changed(self, what):
		# The Picon renderer shows its default picon for an empty reference and hides only on CHANGED_CLEAR.
		if self.mode == 'Reference' and what and what[0] != self.CHANGED_CLEAR and not self.isChannel():
			what = (self.CHANGED_CLEAR,)
		if self.mode in ('SNR', 'AGC'):
			# A Progress bar still draws its empty track, so hide the renderer itself.
			visible = self.signalValue() is not None
			for element in self.downstream_elements:
				element.visible = visible
		Converter.changed(self, what)

	def hasEvent(self):
		try:
			event = self.source.event
			return bool(event and event.getEventName())
		except Exception:
			return False

	def noGuide(self):
		"""(no current or upcoming programme?, rows of the no-guide card)"""
		if self.hasEvent():
			return False, []
		service = self.source.service
		key = (service.toString() if isinstance(service, eServiceReference) else id(service), int(time()) // 60)
		known = ObsidianChannelInfo.noGuideSnapshot
		if not known or known[0] != key:
			try:
				ref = service if isinstance(service, eServiceReference) else eServiceReference(service.info().getInfoString(iServiceInformation.sServiceref))
				empty = not guide(eEPGCache.getInstance(), ref, time())
			except Exception:
				empty = True
			known = ObsidianChannelInfo.noGuideSnapshot = (key, empty, noGuideRows(self.source) if empty else [])
		return known[1], known[2]

	def signalValue(self):
		"""Percent for the SNR*/AGC* modes; None unless the card is showing the channel that is playing."""
		try:
			if not self.isChannel() or not self.noGuide()[0]:
				return None
			from NavigationInstance import instance as nav
			service, playing = self.source.service, nav.getCurrentlyPlayingServiceReference()
			if not isinstance(service, eServiceReference) or not playing or service.toString() != playing.toString():
				return None
			return tunerSignal()[0 if self.mode.startswith('SNR') else 1]
		except Exception:
			return None

	@cached
	def getValue(self):
		return self.signalValue() or 0

	value = property(getValue)
	range = 100

	@cached
	def getText(self):
		try:
			if self.mode in ('TimeLeft', 'TimeLeftShort'):
				# Plain text, unlike RemainingToText, whose "+38 Mins" carries its own colour on OpenATV.
				# Before the channel check: session.Event_Now has an event but no service.
				event = self.source.event
				left = event.getBeginTime() + event.getDuration() - int(time()) if event else 0
				if left <= 0:
					return ''
				return ('%d min' if self.mode == 'TimeLeftShort' else '%d min left') % ((left + 59) // 60)
			if self.mode == 'SNRLive':
				# SNR of the playing tuner; empty on IPTV, recordings and media (no "N/A")
				value = tunerSignal()[0]
				return '' if value is None else '%d %%' % value
			service = self.source.service
			if not self.isChannel():
				return ''
			if self.mode.startswith('NoGuide'):
				empty, rows = self.noGuide()
				if not empty:
					return ''
				if self.mode == 'NoGuideTitle':
					return 'NO GUIDE DATA'
				index = int(self.mode[-1]) - 1
				return rows[index][0 if self.mode[7:10] == 'Key' else 1] if index < len(rows) else ''
			if self.mode in ('SNRText', 'AGCText'):
				value = self.signalValue()
				return '' if value is None else '%d%%' % value
			static = isinstance(service, eServiceReference)
			info = self.source.info if static else service.info()
			if self.mode == 'Reference':
				return service.toString() if static else info.getInfoString(iServiceInformation.sServiceref)
			if self.mode == 'Name':
				name = info.getName(service) if static else info.getName()
				for marker in ('\xc2\x86', '\xc2\x87', '\x86', '\x87'):
					name = (name or '').replace(marker, '')
				return name
			if self.mode == 'Compact':
				return channelCompact(self.source)
			if self.mode in ('Delivery', 'Transponder'):
				return channelTechnical(self.source)[0 if self.mode == 'Delivery' else 1]
			if self.mode == 'Now':
				event = self.source.event
				return event.getEventName() if event and event.getEventName() else 'No programme guide'
			if self.mode == 'Provider':
				return providerName(self.source)
			if not static:
				service = eServiceReference(info.getInfoString(iServiceInformation.sServiceref))
			now = time()
			key = (service.toString(), int(now) // 60)
			if not self.snapshot or self.snapshot[0] != key:
				rows = guide(eEPGCache.getInstance(), service, now)
				ObsidianChannelInfo.snapshot = (key, rows)
			rows = self.snapshot[1]
			if self.mode == 'Prime':
				target = primeTime(now)
				event = eEPGCache.getInstance().lookupEventTime(service, target, 0)
				title = event.getEventName().replace(chr(10), ' ') if event and event.getEventName() else ''
				return '%s   %s' % (strftime('%H:%M', localtime(target)), title) if title else ''
			if self.mode in ('Upcoming', 'Upcoming5', 'UpcomingOnly'):
				# UpcomingOnly: empty instead of the notice (Edge channel list card, which hides that part without EPG).
				# Upcoming5: five programmes (Floating channel list); the others keep three.
				text = '\n'.join('%s   %s' % (strftime('%H:%M', localtime(begin)), title.replace('\n', ' ')) for begin, title in rows[:5 if self.mode == 'Upcoming5' else 3])
				return text or ('' if self.mode == 'UpcomingOnly' else 'No upcoming programme guide')

		except Exception:
			return ''
		return ''

	text = property(getText)

	@cached
	def getBoolean(self):
		if not self.isChannel():
			return False  # no card at all on a bouquet, folder or empty list
		if self.mode == 'NoGuide':
			return self.noGuide()[0]
		if self.mode in ('SNR', 'AGC'):
			return self.signalValue() is not None
		if self.mode in ('Event', 'NoEvent'):
			# The selected channel has / has no current programme (Edge channel list: full or compact info card).
			return self.hasEvent() == (self.mode == 'Event')
		if self.mode in ('Upcoming', 'Upcoming5'):
			try:
				event = self.source.event
				return bool(event and event.getEventName())
			except Exception:
				return False
		return bool(self.getText())

	boolean = property(getBoolean)
