"""Selection position, description and translated sidebar headings; no polling or I/O."""
from Components.Converter.Converter import Converter
from Components.Element import cached


def label(key):
    from Components.Language import language
    lang = language.getLanguage()[:2]
    translations = {
        'CURRENT SELECTION': ('SÉLECTION ACTUELLE', 'التحديد الحالي'),
        'ABOUT': ('À PROPOS', 'حول'),
        'RECEIVER STATUS': ('ÉTAT DU RÉCEPTEUR', 'حالة الجهاز'),
        'Open this section to view its settings and options.': (
            'Ouvrez cette rubrique pour accéder à ses réglages et options.',
            'افتح هذا القسم لعرض الإعدادات والخيارات.'),
    }
    return translations[key][0 if lang == 'fr' else 1] if lang in ('fr', 'ar') and key in translations else key


class ObsidianMenuSelection(Converter):
    def __init__(self, mode):
        Converter.__init__(self, mode)
        self.mode = mode
        self.selectionSource = None

    def changed(self, what):
        if self.source is not self.selectionSource:
            self.detach()
            self.selectionSource = self.source
            if self.selectionSource is not None:
                self.selectionSource.onSelectionChanged.append(self.selectionChanged)
        Converter.changed(self, what)

    def selectionChanged(self):
        Converter.changed(self, (self.CHANGED_ALL,))

    def detach(self):
        if self.selectionSource is not None:
            callbacks = self.selectionSource.onSelectionChanged
            if self.selectionChanged in callbacks:
                callbacks.remove(self.selectionChanged)
        self.selectionSource = None

    def destroy(self):
        self.detach()

    @cached
    def getText(self):
        if self.mode.startswith('Label:'):
            return label(self.mode[6:])
        if self.mode == 'Position':
            count = len(self.source.list)
            return '%02d / %02d' % (self.source.index + 1, count) if count else ''
        current = self.source.current
        if self.mode == 'Description':
            description = current[4] if current and len(current) > 4 else ''
            return description if isinstance(description, str) and description.strip() else label('Open this section to view its settings and options.')
        return current[0] if current else ''

    text = property(getText)
