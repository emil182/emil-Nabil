# Obsidian FHD: labelled service information, the same on every image (only the standard iServiceInformation and
# audio-track API is used, not an image's own PliExtraInfo format).
# <convert type="ObsidianServiceInfo">Pids</convert>   "SID 1234  VPID 0512  APID 0513  PCR 0512  TSID 1  ONID 318"
# <convert type="ObsidianServiceInfo">Audio</convert>  current audio track: "FRA · AC3 · 2/3" (the count only with
#                                                      more than one track), "" when the service has no track info
from enigma import iServiceInformation

from Components.Converter.Converter import Converter
from Components.Element import cached


class ObsidianServiceInfo(Converter):
	def __init__(self, type):
		Converter.__init__(self, type)
		self.type = type.strip()

	@cached
	def getText(self):
		try:
			service = self.source.service
			if not service:
				return ""
			if self.type == "Audio":
				return self.audio(service)
			info = service.info()
			return self.pids(info) if info else ""
		except Exception:
			return ""

	text = property(getText)

	@staticmethod
	def pids(info):
		def value(what):
			v = info.getInfo(what)
			return v if v is not None and v >= 0 else None
		out = []
		for label, what, width in (("SID", iServiceInformation.sSID, 4), ("VPID", iServiceInformation.sVideoPID, 4),
				("APID", iServiceInformation.sAudioPID, 4), ("PCR", iServiceInformation.sPCRPID, 4),
				("TSID", iServiceInformation.sTSID, 0), ("ONID", iServiceInformation.sONID, 0)):
			v = value(what)
			if v is not None:
				out.append("%s %0*d" % (label, width, v))
		return "  ".join(out)

	@staticmethod
	def audio(service):
		tracks = service.audioTracks()
		if not tracks:
			return ""
		count = tracks.getNumberOfTracks()
		if count <= 0:
			return ""
		current = tracks.getCurrentTrack()
		if current is None or current < 0 or current >= count:
			current = 0
		track = tracks.getTrackInfo(current)
		if not track:
			return ""
		language = (track.getLanguage() or "").split("/")[0].strip()
		if language.lower() in ("und", "unknown", "?"):
			language = ""
		language = language.upper() if len(language) <= 3 else language[:12]
		codec = (track.getDescription() or "").strip()[:10]
		parts = [p for p in (language, codec) if p]
		if count > 1:
			parts.append("%d/%d" % (current + 1, count))
		return u" · ".join(parts)
